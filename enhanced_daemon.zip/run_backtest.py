#!/usr/bin/env python3
"""
Trading System Backtest Launcher
"""
import os
import sys
import json
import argparse
import subprocess
from pathlib import Path
from datetime import datetime

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

def main():
    parser = argparse.ArgumentParser(description="Run trading system backtest")
    parser.add_argument("--symbol", default="EURUSD", help="Trading symbol")
    parser.add_argument("--file", help="Data file name (auto-detected if not provided)")
    parser.add_argument("--server_url", default="http://127.0.0.1:8000", help="Server URL")
    parser.add_argument("--output", help="Output file (auto-generated if not provided)")
    
    args = parser.parse_args()
    
    # Load configuration
    config_path = Path(__file__).parent / "config.json"
    config = {}
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
    
    # Set paths
    data_dir = Path(__file__).parent / config.get("paths", {}).get("data_dir", "data")
    results_dir = Path(__file__).parent / config.get("paths", {}).get("results_dir", "results")
    results_dir.mkdir(exist_ok=True)
    
    # Auto-detect data file
    data_file = args.file
    if not data_file:
        possible_files = list(data_dir.glob(f"{args.symbol}*.csv"))
        if possible_files:
            data_file = possible_files[0].name
            print(f"Auto-detected data file: {data_file}")
        else:
            print(f"No data file found for {args.symbol}")
            sys.exit(1)
    
    # Set output file
    output_file = args.output
    if not output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = results_dir / f"backtest_{args.symbol}_{timestamp}.csv"
    
    # Get trading parameters from config
    trading_config = config.get("trading", {})
    
    # Build backtest command
    cmd_args = [
        sys.executable, "backtest_http_predict.py",
        "--server_url", args.server_url,
        "--data_root", str(data_dir),
        "--symbol", args.symbol,
        "--file", data_file,
        "--export_trades", str(output_file),
        "--spread_points", str(trading_config.get("spread_points", 10)),
        "--slippage_points", str(trading_config.get("slippage_points", 2)),
        "--tau_conf", str(trading_config.get("tau_conf", 0.70)),
        "--tau_unc", str(trading_config.get("tau_unc", 0.60)),
        "--atr_floor", str(trading_config.get("atr_floor", 0.25)),
        "--verbose_every", "500"
    ]
    
    print(f"Running backtest for {args.symbol}")
    print(f"Server: {args.server_url}")
    print(f"Data: {data_dir / data_file}")
    print(f"Output: {output_file}")
    
    # Run backtest
    try:
        result = subprocess.run(cmd_args, check=True)
        print(f"Backtest completed! Results saved to: {output_file}")
    except subprocess.CalledProcessError as e:
        print(f"Backtest failed with exit code {e.returncode}")
        sys.exit(1)

if __name__ == "__main__":
    main()
