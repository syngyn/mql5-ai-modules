# Institutional Trading System

This is a comprehensive machine learning trading system with ensemble models, HTTP API, and robust backtesting.

## Quick Start

1. **Installation completed automatically**
2. **Copy source files**: Copy the Python trading system files to this directory
3. **Download data**: Use `python mt5_data_download.py` or place CSV files in `data/`
4. **Train models**: `python run_training.py --symbol EURUSD`
5. **Start server**: `python run_server.py`
6. **Run backtest**: `python run_backtest.py --symbol EURUSD`

## Source Files Needed

Copy these files to this directory:
- enhanced_train_model.py
- http_server.py
- backtest_http_predict.py
- data_processing.py
- enhanced_daemon.py
- mt5_data_download.py
- enhanced_train_model_verbose.py

## Directory Structure

```
trading_system/
├── data/           # Market data files
├── models/         # Trained model artifacts
├── logs/           # System logs
├── results/        # Backtest results
├── config.json     # System configuration
└── run_*.py        # Launch scripts
```

## Configuration

Edit `config.json` to customize:
- Trading parameters (spread, slippage, gates)
- Model parameters (sequence length, hidden size)
- Server settings (host, port)

## Usage Examples

```bash
# Train ensemble model
python run_training.py --symbol EURUSD --model_type moe --epochs 20

# Start server
python run_server.py

# Run backtest
python run_backtest.py --symbol EURUSD --server_url http://localhost:8000
```

For detailed documentation, see the inline comments in each file.
