#!/usr/bin/env python3
"""
Enhanced data processing module with robust CSV reading and feature engineering.
Fixed issues with NaN handling, division by zero, and feature alignment.
"""

import pandas as pd
import numpy as np
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# ==============================
# Technical Indicator Helpers (robust)
# ==============================

def _ema(s, span):
    """Exponential Moving Average with NaN handling"""
    return s.ewm(span=span, adjust=False).mean()

def _atr(high, low, close, n=14):
    """Average True Range with robust handling"""
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.rolling(n, min_periods=1).mean()

def _rsi(close, n=14):
    """Relative Strength Index with NaN handling"""
    diff = close.diff()
    up = diff.clip(lower=0)
    dn = -diff.clip(upper=0)
    
    rs_up = up.rolling(n, min_periods=1).mean()
    rs_dn = dn.rolling(n, min_periods=1).mean()
    
    rs = rs_up / (rs_dn + 1e-12)
    return 100 - (100 / (1 + rs))

def _bollinger(close, n=20, k=2.0):
    """Bollinger Bands with robust calculations"""
    ma = close.rolling(n, min_periods=1).mean()
    sd = close.rolling(n, min_periods=1).std()
    
    upper = ma + k * sd
    lower = ma - k * sd
    width = (upper - lower) / (ma.abs() + 1e-12)
    
    return upper, lower, width, ma, sd

def _macd(close, fast=12, slow=26, signal=9):
    """MACD with exponential moving averages"""
    ema_fast = _ema(close, fast)
    ema_slow = _ema(close, slow)
    macd = ema_fast - ema_slow
    macd_signal = _ema(macd, signal)
    hist = macd - macd_signal
    return macd, macd_signal, hist

def _stoch(high, low, close, k_len=5, d_len=3):
    """Stochastic Oscillator"""
    low_min = low.rolling(k_len, min_periods=1).min()
    high_max = high.rolling(k_len, min_periods=1).max()
    
    k = 100 * (close - low_min) / (high_max - low_min + 1e-12)
    d = k.rolling(d_len, min_periods=1).mean()
    
    return k, d

def _cci(high, low, close, n=20):
    """Commodity Channel Index"""
    tp = (high + low + close) / 3.0
    ma = tp.rolling(n, min_periods=1).mean()
    md = tp.rolling(n, min_periods=1).apply(
        lambda x: np.mean(np.abs(x - x.mean())) if len(x) > 0 else 0, 
        raw=False
    )
    return (tp - ma) / (0.015 * (md + 1e-12))

def _adx(high, low, close, n=14):
    """Average Directional Index"""
    plus_dm = high.diff().clip(lower=0)
    minus_dm = (-low.diff()).clip(lower=0)
    
    # Zero out opposite movements
    plus_dm = plus_dm.where(high.diff() > low.diff(), 0)
    minus_dm = minus_dm.where(low.diff() > high.diff(), 0)

    # True range
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    atr = tr.rolling(n, min_periods=1).mean()
    plus_di = 100 * (plus_dm.rolling(n, min_periods=1).mean() / (atr + 1e-12))
    minus_di = 100 * (minus_dm.rolling(n, min_periods=1).mean() / (atr + 1e-12))
    
    dx = ((plus_di - minus_di).abs() / ((plus_di + minus_di) + 1e-12)) * 100
    adx = dx.rolling(n, min_periods=1).mean()
    
    return adx, plus_di, minus_di

def _obv(close, volume):
    """On-Balance Volume"""
    direction = np.sign(close.diff().fillna(0))
    return (direction * volume.fillna(0)).cumsum()

def _realized_vol(ret, n=20):
    """Realized volatility"""
    return ret.rolling(n, min_periods=1).std()

def _vwap(df, price_col="close", vol_col="volume"):
    """Volume Weighted Average Price"""
    pv = (df[price_col] * df[vol_col]).cumsum()
    vv = df[vol_col].cumsum().replace(0, np.nan)
    return pv / vv

def _session_encodings(idx):
    """Cyclical time encodings"""
    hour = idx.hour
    dow = idx.dayofweek
    
    h_sin = np.sin(2 * np.pi * hour / 24)
    h_cos = np.cos(2 * np.pi * hour / 24)
    d_sin = np.sin(2 * np.pi * dow / 7)
    d_cos = np.cos(2 * np.pi * dow / 7)
    
    return (
        pd.Series(h_sin, index=idx),
        pd.Series(h_cos, index=idx),
        pd.Series(d_sin, index=idx),
        pd.Series(d_cos, index=idx)
    )

def _round_dist(price, step):
    """Distance to round numbers"""
    step = np.maximum(step, 1e-8)  # Prevent division by zero
    nearest = np.round(price / step) * step
    return (price - nearest).abs()

def _swing_levels(high, low, lookback=5):
    """Swing high/low detection"""
    # Simple swing detection using rolling max/min
    swing_high_mask = (
        (high.shift(2) > high.shift(3)) & 
        (high.shift(2) > high.shift(1)) & 
        (high.shift(2) > high.shift(4)) & 
        (high.shift(2) > high)
    )
    
    swing_low_mask = (
        (low.shift(2) < low.shift(3)) & 
        (low.shift(2) < low.shift(1)) & 
        (low.shift(2) < low.shift(4)) & 
        (low.shift(2) < low)
    )
    
    sh = high.where(swing_high_mask).ffill()
    sl = low.where(swing_low_mask).ffill()
    
    return sh, sl

def _volume_nodes(price, volume, window=240):
    """Volume profile proxy using VWAP"""
    vwap_win = (price * volume).rolling(window, min_periods=1).sum() / (
        volume.rolling(window, min_periods=1).sum() + 1e-12
    )
    return (price - vwap_win).abs(), vwap_win

# ==============================
# CSV Reading with Auto-Detection
# ==============================

def _read_symbol_csv_auto(filepath: str) -> pd.DataFrame:
    """
    Robust CSV reader that handles multiple MT5/broker formats:
    1. Standard comma-delimited with headers: Date,Open,High,Low,Close,Volume
    2. Semicolon-delimited without headers: timestamp;open;high;low;close;volume
    3. Various timestamp formats and column name variations
    """
    p = Path(filepath)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    # Try reading a sample to detect format
    sample_lines = []
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for i, line in enumerate(f):
                sample_lines.append(line.strip())
                if i >= 5:  # Read first few lines
                    break
    except UnicodeDecodeError:
        try:
            with open(filepath, 'r', encoding='latin-1') as f:
                for i, line in enumerate(f):
                    sample_lines.append(line.strip())
                    if i >= 5:
                        break
        except Exception as e:
            raise ValueError(f"Could not read file {filepath}: {e}")

    if not sample_lines:
        raise ValueError(f"Empty file: {filepath}")

    # Detect delimiter
    first_line = sample_lines[0]
    if ';' in first_line and first_line.count(';') >= 4:
        delimiter = ';'
    elif ',' in first_line and first_line.count(',') >= 4:
        delimiter = ','
    elif '\t' in first_line and first_line.count('\t') >= 4:
        delimiter = '\t'
    else:
        delimiter = ','  # Default

    # Try with headers first
    try:
        df = pd.read_csv(filepath, sep=delimiter, encoding='utf-8')
        
        # Check if first row looks like data (not headers)
        if len(df.columns) >= 5:
            first_row = df.iloc[0]
            # If first row is all numeric-like, probably no headers
            if all(pd.to_numeric(str(val), errors='coerce') is not pd.NaT for val in first_row.values[:5]):
                # Retry without headers
                df = pd.read_csv(filepath, sep=delimiter, header=None, encoding='utf-8')
                df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume'][:len(df.columns)]
        
        # Normalize column names
        column_mapping = {}
        for col in df.columns:
            col_lower = str(col).lower().strip()
            if col_lower in ['date', 'time', 'timestamp', 'datetime']:
                column_mapping[col] = 'timestamp'
            elif col_lower in ['open', 'o']:
                column_mapping[col] = 'open'
            elif col_lower in ['high', 'h']:
                column_mapping[col] = 'high'
            elif col_lower in ['low', 'l']:
                column_mapping[col] = 'low'
            elif col_lower in ['close', 'c']:
                column_mapping[col] = 'close'
            elif col_lower in ['volume', 'vol', 'v', 'tickvolume', 'tick_volume']:
                column_mapping[col] = 'volume'
        
        df = df.rename(columns=column_mapping)
        
        # Ensure we have required columns
        required = ['timestamp', 'open', 'high', 'low', 'close']
        missing = [col for col in required if col not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        
        # Add volume if missing
        if 'volume' not in df.columns:
            df['volume'] = 1.0
        
        # Select and reorder columns
        df = df[['timestamp', 'open', 'high', 'low', 'close', 'volume']].copy()
        
    except Exception as e:
        print(f"Header-based reading failed: {e}")
        # Fallback: assume no headers, fixed column order
        try:
            df = pd.read_csv(filepath, sep=delimiter, header=None, encoding='utf-8')
            
            if len(df.columns) < 5:
                raise ValueError(f"Not enough columns in CSV: {len(df.columns)}")
            
            # Assume standard order: timestamp, open, high, low, close, volume
            column_names = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
            df.columns = column_names[:len(df.columns)]
            
            # Add volume if missing
            if 'volume' not in df.columns:
                df['volume'] = 1.0
                
        except Exception as e2:
            raise ValueError(f"Could not parse CSV file {filepath}. Tried with and without headers. Errors: {e}, {e2}")

    # Convert data types and handle timestamps
    try:
        # Convert timestamp
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce', infer_datetime_format=True)
        
        # Handle various date formats that pd.to_datetime might miss
        if df['timestamp'].isna().any():
            # Try common MT5 formats
            formats_to_try = [
                '%Y.%m.%d %H:%M:%S',
                '%Y-%m-%d %H:%M:%S',
                '%d.%m.%Y %H:%M:%S',
                '%Y.%m.%d %H:%M',
                '%Y-%m-%d %H:%M',
                '%Y.%m.%d',
                '%Y-%m-%d'
            ]
            
            for fmt in formats_to_try:
                try:
                    df['timestamp'] = pd.to_datetime(df['timestamp'], format=fmt, errors='coerce')
                    if not df['timestamp'].isna().all():
                        break
                except:
                    continue
        
        # Convert numeric columns
        for col in ['open', 'high', 'low', 'close', 'volume']:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Drop rows with invalid timestamps or prices
        df = df.dropna(subset=['timestamp', 'open', 'high', 'low', 'close'])
        
        # Basic validation
        if len(df) == 0:
            raise ValueError("No valid data rows after parsing")
        
        # Check for reasonable price values
        price_cols = ['open', 'high', 'low', 'close']
        for col in price_cols:
            if (df[col] <= 0).any():
                print(f"Warning: Found non-positive values in {col}")
                df = df[df[col] > 0]
        
        # Check OHLC validity
        invalid_ohlc = (
            (df['high'] < df['low']) |
            (df['high'] < df['open']) |
            (df['high'] < df['close']) |
            (df['low'] > df['open']) |
            (df['low'] > df['close'])
        )
        
        if invalid_ohlc.any():
            print(f"Warning: Found {invalid_ohlc.sum()} rows with invalid OHLC data, removing them")
            df = df[~invalid_ohlc]
        
        # Ensure volume is positive
        df['volume'] = df['volume'].fillna(1.0).abs()
        
        if len(df) == 0:
            raise ValueError("No valid data rows after validation")
        
        return df[['timestamp', 'open', 'high', 'low', 'close', 'volume']]
        
    except Exception as e:
        raise ValueError(f"Data type conversion failed for {filepath}: {e}")

# ==============================
# Main Data Loading and Processing
# ==============================

def load_and_align_data(file_dict, base_path):
    """
    Load multiple symbol CSVs and align them on timestamp.
    
    Args:
        file_dict: Dictionary mapping symbol names to filenames
        base_path: Base directory path
        
    Returns:
        Merged DataFrame with aligned timestamps
    """
    dfs = []
    
    for symbol, filename in file_dict.items():
        filepath = Path(base_path) / filename
        
        try:
            df = _read_symbol_csv_auto(str(filepath))
            
            # Set timestamp as index and sort
            df = df.set_index('timestamp').sort_index()
            
            # Remove duplicates
            df = df[~df.index.duplicated(keep='first')]
            
            # Prefix columns with symbol
            df.columns = [f"{symbol.lower()}_{col}" for col in df.columns]
            
            dfs.append(df)
            print(f"Loaded {len(df)} rows for {symbol} from {filename}")
            
        except Exception as e:
            print(f"Error loading {symbol} from {filename}: {e}")
            raise
    
    if not dfs:
        raise ValueError("No data files successfully loaded")
    
    # Merge all dataframes
    merged = pd.concat(dfs, axis=1, sort=True)
    merged = merged.sort_index()
    
    # Forward fill missing values within reasonable limits
    merged = merged.fillna(method='ffill', limit=5)
    
    # Drop rows where all symbols are missing
    merged = merged.dropna(how='all')
    
    print(f"Merged dataset: {len(merged)} rows, {len(merged.columns)} columns")
    
    return merged

def build_features(df, primary_symbol=None):
    """
    Build comprehensive feature set for trading model.
    
    Args:
        df: Merged OHLCV dataframe
        primary_symbol: Primary symbol for feature engineering (uses first if None)
        
    Returns:
        (DataFrame with features, list of feature column names)
    """
    if primary_symbol is None:
        first_col = df.columns[0]
        primary_symbol = first_col.split('_')[0]
    
    print(f"Building features for primary symbol: {primary_symbol}")
    
    pfx = primary_symbol.lower() + "_"
    
    # Extract OHLCV for primary symbol
    try:
        close = df[pfx + "close"].astype(float)
        high = df[pfx + "high"].astype(float)
        low = df[pfx + "low"].astype(float)
        open_ = df[pfx + "open"].astype(float)
        vol = df.get(pfx + "volume", pd.Series(index=df.index, dtype=float)).astype(float).fillna(1.0)
    except KeyError as e:
        available_cols = [col for col in df.columns if col.startswith(pfx)]
        raise KeyError(f"Missing column {e}. Available columns for {primary_symbol}: {available_cols}")
    
    # Basic validation
    if len(close) == 0:
        raise ValueError(f"No data for symbol {primary_symbol}")
    
    # Core features
    ret1 = close.pct_change().fillna(0.0)
    atr = _atr(high, low, close, n=14)
    
    df["ret1"] = ret1
    df["atr14"] = atr

    # === Technical Indicators ===
    
    # Bollinger Bands
    bb_up, bb_dn, bb_w, bb_ma, bb_sd = _bollinger(close)
    df["bb_upper"] = bb_up
    df["bb_lower"] = bb_dn
    df["bb_width"] = bb_w
    df["bb_ma"] = bb_ma
    df["bb_sd"] = bb_sd
    
    # RSI
    df["rsi14"] = _rsi(close, 14)
    
    # MACD
    macd, macd_sig, macd_hist = _macd(close)
    df["macd"] = macd
    df["macd_signal"] = macd_sig
    df["macd_hist"] = macd_hist
    
    # Stochastic
    st_k, st_d = _stoch(high, low, close)
    df["stoch_k"] = st_k
    df["stoch_d"] = st_d
    
    # CCI
    df["cci20"] = _cci(high, low, close, 20)
    
    # ADX
    adx, plus_di, minus_di = _adx(high, low, close)
    df["adx14"] = adx
    df["plus_di"] = plus_di
    df["minus_di"] = minus_di

    # === MACD Derivatives ===
    df["macd_d"] = macd.diff()
    df["macd_hist_d"] = macd_hist.diff()
    df["macd_cross_up"] = ((macd.shift(1) <= macd_sig.shift(1)) & (macd > macd_sig)).astype(int)
    df["macd_cross_dn"] = ((macd.shift(1) >= macd_sig.shift(1)) & (macd < macd_sig)).astype(int)
    df["macd_above_zero"] = (macd > 0).astype(int)
    df["macd_gap"] = (macd - macd_sig).abs()

    # === Volume Features ===
    vol_roll = vol.rolling(252, min_periods=20)
    vol_mean = vol_roll.mean()
    vol_std = vol_roll.std()
    
    df["vol_z"] = (vol - vol_mean) / (vol_std + 1e-12)
    df["vol_pct"] = vol_roll.rank(pct=True)
    df["vol_spike"] = (df["vol_z"] > 2.5).astype(int)
    df["vol_mom"] = vol / (vol.rolling(20, min_periods=1).mean() + 1e-12)
    df["vol_slope"] = vol.rolling(20, min_periods=1).mean().diff()
    df["vol_atr_ratio"] = vol / (atr.rolling(20, min_periods=1).mean() + 1e-12)

    # On-Balance Volume
    obv = _obv(close, vol)
    df["obv"] = obv
    
    # Accumulation/Distribution Line
    ad_line = (((close - low) - (high - close)) / ((high - low) + 1e-12)) * vol
    ad_line = ad_line.cumsum()
    df["ad_line"] = ad_line
    
    # Volume Z-score
    obv_roll = obv.rolling(252, min_periods=20)
    df["obv_z"] = (obv - obv_roll.mean()) / (obv_roll.std() + 1e-12)
    
    # Return-Volume interaction
    df["ret_vol"] = ret1 * df["vol_z"].fillna(0.0)
    
    # Realized volatility
    df["rv20"] = _realized_vol(ret1, 20)

    # === VWAP and Price Levels ===
    
    # Volume-weighted average price
    tmp_df = pd.DataFrame({"close": close, "volume": vol}, index=df.index)
    vwap = _vwap(tmp_df)
    df["vwap_run"] = vwap
    df["dev_vwap_pct"] = (close - vwap) / (atr + 1e-12)

    # === Time-based Features ===
    
    # Previous period levels
    ohlc = pd.DataFrame({
        "open": open_, "high": high, "low": low, "close": close, "volume": vol
    }, index=df.index)
    
    try:
        daily = ohlc.resample("1D").agg({
            "open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"
        })
        weekly = ohlc.resample("1W-MON").agg({
            "open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"
        })
        
        d_prev = daily.shift(1).reindex(df.index, method="ffill")
        w_prev = weekly.shift(1).reindex(df.index, method="ffill")
        
        df["dist_to_dhigh"] = (close - d_prev["high"]).abs() / (atr + 1e-12)
        df["dist_to_dlow"] = (close - d_prev["low"]).abs() / (atr + 1e-12)
        df["dist_to_dclose"] = (close - d_prev["close"]).abs() / (atr + 1e-12)
        df["near_d_high"] = (df["dist_to_dhigh"] < 0.5).astype(int)
        df["near_d_low"] = (df["dist_to_dlow"] < 0.5).astype(int)
        
        df["dist_to_whigh"] = (close - w_prev["high"]).abs() / (atr + 1e-12)
        df["dist_to_wlow"] = (close - w_prev["low"]).abs() / (atr + 1e-12)
        
    except Exception as e:
        print(f"Warning: Could not compute daily/weekly levels: {e}")
        # Fallback values
        for col in ["dist_to_dhigh", "dist_to_dlow", "dist_to_dclose", "dist_to_whigh", "dist_to_wlow"]:
            df[col] = 0.0
        for col in ["near_d_high", "near_d_low"]:
            df[col] = 0

    # === Round Numbers and Support/Resistance ===
    
    # Round number distances
    med_price = close.rolling(240, min_periods=20).median()
    step = (0.005 * med_price).clip(lower=1e-8)
    df["dist_to_round"] = _round_dist(close, step) / (atr + 1e-12)
    df["near_round"] = (df["dist_to_round"] < 0.2).astype(int)

    # Swing levels
    try:
        sh, sl = _swing_levels(high, low)
        df["dist_to_swing_high"] = (close - sh).abs() / (atr + 1e-12)
        df["dist_to_swing_low"] = (close - sl).abs() / (atr + 1e-12)
        df["touch_swing"] = ((df["dist_to_swing_high"] < 0.2) | (df["dist_to_swing_low"] < 0.2)).astype(int)
        df["break_prev_swing_high"] = (close > sh.shift(1)).astype(int)
        df["break_prev_swing_low"] = (close < sl.shift(1)).astype(int)
    except Exception as e:
        print(f"Warning: Could not compute swing levels: {e}")
        for col in ["dist_to_swing_high", "dist_to_swing_low", "touch_swing", "break_prev_swing_high", "break_prev_swing_low"]:
            df[col] = 0.0

    # Volume nodes (market profile proxy)
    try:
        node_dist, node_vwap = _volume_nodes(close, vol)
        df["dist_to_vol_node"] = node_dist / (atr + 1e-12)
    except Exception as e:
        print(f"Warning: Could not compute volume nodes: {e}")
        df["dist_to_vol_node"] = 0.0

    # === Session Encodings ===
    try:
        hsin, hcos, dsin, dcos = _session_encodings(df.index)
        df["hour_sin"] = hsin
        df["hour_cos"] = hcos
        df["dow_sin"] = dsin
        df["dow_cos"] = dcos
    except Exception as e:
        print(f"Warning: Could not compute session encodings: {e}")
        df["hour_sin"] = 0.0
        df["hour_cos"] = 1.0
        df["dow_sin"] = 0.0
        df["dow_cos"] = 1.0

    # === Post-processing ===
    
    # Clip extreme distance values to prevent outliers
    distance_cols = [
        "dist_to_dhigh", "dist_to_dlow", "dist_to_dclose", 
        "dist_to_whigh", "dist_to_wlow", "dist_to_round",
        "dist_to_swing_high", "dist_to_swing_low", "dist_to_vol_node"
    ]
    
    for col in distance_cols:
        if col in df.columns:
            df[col] = df[col].clip(upper=5.0)

    # Forward-fill all engineered features (not raw OHLCV)
    df = df.sort_index()
    
    # Identify engineered vs raw columns
    raw_ohlcv_cols = [col for col in df.columns if 
                      any(suffix in col for suffix in ["_open", "_high", "_low", "_close", "_volume"]) and 
                      col.startswith(pfx)]
    
    engineered_cols = [col for col in df.columns if col not in raw_ohlcv_cols]
    
    # Forward fill engineered features with limit
    df[engineered_cols] = df[engineered_cols].fillna(method='ffill', limit=10)
    
    # Final cleanup - drop rows with too many NaN values
    df = df.dropna(thresh=len(df.columns) * 0.8)  # Keep rows with at least 80% non-NaN values
    
    # Replace remaining NaN with appropriate defaults
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    df[numeric_cols] = df[numeric_cols].fillna(0.0)

    # === Build feature column list ===
    
    # Start with raw OHLCV columns that exist
    base_cols = [pfx + "open", pfx + "high", pfx + "low", pfx + "close", pfx + "volume"]
    feature_cols = [col for col in base_cols if col in df.columns]
    
    # Add all engineered features
    engineered_features = [col for col in df.columns if col not in base_cols]
    feature_cols.extend(engineered_features)
    
    print(f"Built {len(feature_cols)} features for {len(df)} rows")
    print(f"Feature categories: OHLCV={len([c for c in feature_cols if any(s in c for s in ['open','high','low','close','volume'])])}, "
          f"Technical={len([c for c in feature_cols if any(s in c for s in ['rsi','macd','bb_','stoch','cci','adx'])])}, "
          f"Volume={len([c for c in feature_cols if any(s in c for s in ['vol_','obv','ad_line'])])}, "
          f"Other={len(feature_cols) - len([c for c in feature_cols if any(s in c for s in ['open','high','low','close','volume','rsi','macd','bb_','stoch','cci','adx','vol_','obv','ad_line'])])}")
    
    return df, feature_cols

# ==============================
# Utility Functions
# ==============================

def validate_features(df, feature_cols):
    """Validate feature dataframe before training"""
    issues = []
    
    # Check for missing columns
    missing_cols = [col for col in feature_cols if col not in df.columns]
    if missing_cols:
        issues.append(f"Missing columns: {missing_cols}")
    
    # Check for infinite values
    inf_cols = []
    for col in feature_cols:
        if col in df.columns and np.isinf(df[col]).any():
            inf_cols.append(col)
    if inf_cols:
        issues.append(f"Infinite values in: {inf_cols}")
    
    # Check for excessive NaN
    nan_cols = []
    for col in feature_cols:
        if col in df.columns:
            nan_pct = df[col].isna().mean()
            if nan_pct > 0.1:  # More than 10% NaN
                nan_cols.append(f"{col}({nan_pct:.1%})")
    if nan_cols:
        issues.append(f"High NaN percentage: {nan_cols}")
    
    # Check data types
    non_numeric = []
    for col in feature_cols:
        if col in df.columns and not pd.api.types.is_numeric_dtype(df[col]):
            non_numeric.append(col)
    if non_numeric:
        issues.append(f"Non-numeric columns: {non_numeric}")
    
    if issues:
        print("Feature validation issues:")
        for issue in issues:
            print(f"  - {issue}")
        return False
    
    print("Feature validation passed")
    return True

if __name__ == "__main__":
    # Simple test
    print("Data processing module loaded successfully")
    print("Available functions:", [name for name in globals() if callable(globals()[name]) and not name.startswith('_')])
