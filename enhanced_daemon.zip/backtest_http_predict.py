#!/usr/bin/env python3
"""
Enhanced HTTP backtesting client with robust error handling and comprehensive diagnostics.
Fixed issues with feature alignment, trading logic, and performance calculations.
"""

import argparse
import sys
import time
from pathlib import Path
import pandas as pd
import numpy as np
import requests
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

from data_processing import load_and_align_data, build_features, validate_features

WARMUP_MESSAGE = "Not enough rows for seq_len"
REQUEST_TIMEOUT = 30
MAX_RETRIES = 3
RETRY_DELAY = 1.0

class BacktestError(Exception):
    """Custom exception for backtest errors"""
    pass

def robust_request(url: str, json_data: dict, timeout: int = REQUEST_TIMEOUT, 
                  max_retries: int = MAX_RETRIES) -> requests.Response:
    """Make HTTP request with retries and proper error handling"""
    last_error = None
    
    for attempt in range(max_retries):
        try:
            response = requests.post(url, json=json_data, timeout=timeout)
            
            if response.status_code == 200:
                return response
            elif response.status_code == 500 and WARMUP_MESSAGE in response.text:
                # This is expected during warmup period
                return response
            else:
                raise requests.HTTPError(f"HTTP {response.status_code}: {response.text[:200]}")
                
        except (requests.RequestException, requests.HTTPError) as e:
            last_error = e
            if attempt < max_retries - 1:
                print(f"Request failed (attempt {attempt + 1}/{max_retries}): {e}")
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                raise BacktestError(f"Request failed after {max_retries} attempts: {e}")
    
    raise BacktestError(f"All retry attempts failed. Last error: {last_error}")

def fetch_server_schema(server_url: str) -> Tuple[int, List[str]]:
    """Fetch server schema with comprehensive error handling"""
    try:
        response = requests.get(f"{server_url}/features", timeout=10)
        response.raise_for_status()
        data = response.json()
        
        seq_len = None
        features = None
        
        if isinstance(data, dict):
            # Extract sequence length
            if "seq_len" in data:
                try:
                    seq_len = int(data["seq_len"])
                except (ValueError, TypeError):
                    print("Warning: Could not parse seq_len from server")
            
            # Extract feature list
            features = data.get("feature_cols") or data.get("features") or data.get("feature_names")
            
        elif isinstance(data, list):
            features = data
        
        if not features or not all(isinstance(x, str) for x in features):
            raise BacktestError(f"Invalid features payload from server: {data}")
        
        seq_len = seq_len or 128  # Default fallback
        
        print(f"Server schema: {len(features)} features, seq_len={seq_len}")
        return seq_len, features
        
    except requests.RequestException as e:
        raise BacktestError(f"Failed to fetch server schema: {e}")

def check_feature_alignment(local_features: List[str], server_features: List[str]) -> Dict[str, List[str]]:
    """Check alignment between local and server features"""
    server_set = set(server_features)
    local_set = set(local_features)
    
    missing_on_client = [f for f in server_features if f not in local_set]
    extra_on_client = [f for f in local_features if f not in server_set]
    common_features = [f for f in server_features if f in local_set]
    
    alignment_info = {
        "missing_on_client": missing_on_client,
        "extra_on_client": extra_on_client,
        "common_features": common_features,
        "coverage": len(common_features) / len(server_features) if server_features else 0
    }
    
    print(f"Feature alignment:")
    print(f"  Server expects: {len(server_features)} features")
    print(f"  Client has: {len(local_features)} features")
    print(f"  Common: {len(common_features)} features ({alignment_info['coverage']:.1%} coverage)")
    
    if missing_on_client:
        print(f"  Missing on client: {len(missing_on_client)} features")
        if len(missing_on_client) <= 10:
            print(f"    Examples: {missing_on_client}")
        else:
            print(f"    Examples: {missing_on_client[:10]}... (showing first 10)")
    
    if extra_on_client:
        print(f"  Extra on client: {len(extra_on_client)} features (will be ignored)")
        if len(extra_on_client) <= 5:
            print(f"    Examples: {extra_on_client}")
    
    return alignment_info

def validate_ohlc_columns(df: pd.DataFrame, symbol: str) -> Tuple[str, str, str, str]:
    """Validate and return OHLC column names"""
    pfx = symbol.lower() + "_"
    
    required_cols = {
        "open": pfx + "open",
        "high": pfx + "high", 
        "low": pfx + "low",
        "close": pfx + "close"
    }
    
    missing_cols = []
    for name, col in required_cols.items():
        if col not in df.columns:
            missing_cols.append(col)
    
    if missing_cols:
        available = [col for col in df.columns if pfx in col]
        raise BacktestError(f"Missing OHLC columns: {missing_cols}. Available columns: {available}")
    
    return required_cols["open"], required_cols["high"], required_cols["low"], required_cols["close"]

def trading_gates(conf: float, unc: float, exp_ret_abs: float, atr: float,
                 tau_conf: float, tau_unc: float, atr_floor: float) -> Tuple[bool, Dict[str, bool]]:
    """Enhanced trading gates with detailed diagnostics"""
    gates = {
        "confidence": conf >= tau_conf,
        "uncertainty": unc <= tau_unc,
        "magnitude": exp_ret_abs >= atr_floor,
        "atr_valid": atr > 0.0
    }
    
    all_pass = all(gates.values())
    return all_pass, gates

def calculate_stop_take_levels(current_price: float, exp_ret: float, q10: float, q90: float, 
                              atr: float, direction: int) -> Tuple[float, float]:
    """Calculate stop loss and take profit levels"""
    atr_safe = max(atr, 1e-8)
    
    if direction > 0:  # Long position
        # Use quantiles to set asymmetric levels
        tp = current_price + abs(q90) * atr_safe
        sl = current_price - abs(q10) * atr_safe
    else:  # Short position
        tp = current_price - abs(q90) * atr_safe
        sl = current_price + abs(q10) * atr_safe
    
    return sl, tp

def check_exit_conditions(current_bar: pd.Series, position: int, stop_loss: float, 
                         take_profit: float, spread: float, slippage: float) -> Tuple[bool, float, str]:
    """Check if position should be exited and return exit price and reason"""
    high = float(current_bar["high"])
    low = float(current_bar["low"])
    
    if position > 0:  # Long position
        stop_hit = low <= stop_loss
        take_hit = high >= take_profit
        
        if stop_hit and take_hit:
            # Both hit in same bar - assume stop hit first (pessimistic)
            exit_price = stop_loss - spread - slippage
            return True, exit_price, "SL"
        elif stop_hit:
            exit_price = stop_loss - spread - slippage
            return True, exit_price, "SL"
        elif take_hit:
            exit_price = take_profit - spread - slippage
            return True, exit_price, "TP"
    
    else:  # Short position
        stop_hit = high >= stop_loss
        take_hit = low <= take_profit
        
        if stop_hit and take_hit:
            # Both hit in same bar - assume stop hit first (pessimistic)
            exit_price = stop_loss + spread + slippage
            return True, exit_price, "SL"
        elif stop_hit:
            exit_price = stop_loss + spread + slippage
            return True, exit_price, "SL"
        elif take_hit:
            exit_price = take_profit + spread + slippage
            return True, exit_price, "TP"
    
    return False, 0.0, ""

def simulate_backtest(df_feat: pd.DataFrame, local_feature_cols: List[str], 
                     server_url: str, symbol: str, spread_points: int, 
                     slippage_points: int, verbose_every: int,
                     tau_conf: float, tau_unc: float, atr_floor: float, 
                     debug_sample: int) -> pd.DataFrame:
    """Main backtesting simulation with enhanced error handling"""
    
    print(f"Starting backtest simulation...")
    print(f"Data shape: {df_feat.shape}")
    print(f"Symbol: {symbol}")
    print(f"Trading costs: spread={spread_points}pts, slippage={slippage_points}pts")
    print(f"Gates: conf>={tau_conf}, unc<={tau_unc}, magnitude>={atr_floor}")
    
    # Fetch server schema
    seq_len, server_features = fetch_server_schema(server_url)
    
    # Check feature alignment
    alignment = check_feature_alignment(local_feature_cols, server_features)
    if alignment["coverage"] < 0.8:
        print(f"Warning: Low feature coverage ({alignment['coverage']:.1%}). This may affect model performance.")
    
    # Validate OHLC columns
    ocol, hcol, lcol, ccol = validate_ohlc_columns(df_feat, symbol)
    
    # Trading parameters
    point = 0.0001  # Standard forex point size
    spread = spread_points * point
    slippage = slippage_points * point
    
    # Trading state
    position = 0  # 0=flat, +1=long, -1=short
    entry_price = None
    entry_time = None
    stop_loss = None
    take_profit = None
    
    # Diagnostics
    diagnostics = {
        "total_bars": 0,
        "warmup_skip": 0,
        "gate_passed": 0,
        "gate_failed": {
            "confidence": 0,
            "uncertainty": 0,
            "magnitude": 0,
            "atr_invalid": 0
        }
    }
    
    # Metrics tracking
    metrics = {
        "confidence": [],
        "uncertainty": [],
        "expected_return": [],
        "atr": []
    }
    
    # Trade list
    trades_list = []
    past_warmup = False
    
    # Progress tracking
    total_rows = len(df_feat)
    rows_processed = 0
    
    print(f"Processing {total_rows} rows...")
    
    for idx, (timestamp, row) in enumerate(df_feat.iterrows()):
        try:
            # Prepare server payload
            payload = {name: float(row.get(name, 0.0)) for name in server_features}
            
            # Make prediction request
            response = robust_request(f"{server_url}/predict", {"features": payload})
            
            # Handle warmup period
            if response.status_code != 200:
                if WARMUP_MESSAGE in response.text:
                    diagnostics["warmup_skip"] += 1
                    if verbose_every > 0 and idx % verbose_every == 0:
                        sys.stdout.write(f"\r[Warmup {idx+1}/{total_rows}] {timestamp}")
                        sys.stdout.flush()
                    continue
                else:
                    raise BacktestError(f"HTTP {response.status_code} at {timestamp}: {response.text[:200]}")
            
            past_warmup = True
            diagnostics["total_bars"] += 1
            rows_processed += 1
            
            # Parse response
            try:
                result = response.json()["result"]["ensemble"]
                exp_ret = float(result["expected_return"])
                conf = float(result["confidence"])
                unc = float(result["uncertainty"])
                quantiles = result.get("quantiles", {})
                q10 = float(quantiles.get("p10", 0.0))
                q90 = float(quantiles.get("p90", 0.0))
            except (KeyError, ValueError, TypeError) as e:
                raise BacktestError(f"Failed to parse prediction response at {timestamp}: {e}")
            
            # Extract market data
            try:
                open_price = float(row[ocol])
                high_price = float(row[hcol])
                low_price = float(row[lcol])
                close_price = float(row[ccol])
                atr = float(row.get("atr14", 0.0))
            except (KeyError, ValueError, TypeError) as e:
                raise BacktestError(f"Failed to extract OHLC data at {timestamp}: {e}")
            
            # Store metrics
            metrics["confidence"].append(conf)
            metrics["uncertainty"].append(unc)
            metrics["expected_return"].append(exp_ret)
            metrics["atr"].append(atr)
            
            # Check trading gates
            gates_pass, gate_details = trading_gates(
                conf, unc, abs(exp_ret), atr, tau_conf, tau_unc, atr_floor
            )
            
            if gates_pass:
                diagnostics["gate_passed"] += 1
            else:
                # Track specific gate failures
                if not gate_details["confidence"]:
                    diagnostics["gate_failed"]["confidence"] += 1
                if not gate_details["uncertainty"]:
                    diagnostics["gate_failed"]["uncertainty"] += 1
                if not gate_details["magnitude"]:
                    diagnostics["gate_failed"]["magnitude"] += 1
                if not gate_details["atr_valid"]:
                    diagnostics["gate_failed"]["atr_invalid"] += 1
            
            # Exit logic (check first)
            if position != 0:
                should_exit, exit_price, exit_reason = check_exit_conditions(
                    {"high": high_price, "low": low_price}, 
                    position, stop_loss, take_profit, spread, slippage
                )
                
                if should_exit:
                    # Calculate P&L
                    if position > 0:
                        pnl = exit_price - entry_price
                    else:
                        pnl = entry_price - exit_price
                    
                    # Record trade
                    trades_list.append([
                        entry_time, timestamp, 
                        "LONG" if position > 0 else "SHORT",
                        entry_price, exit_price, exit_reason, pnl,
                        conf, unc, exp_ret
                    ])
                    
                    # Reset position
                    position = 0
                    entry_price = None
                    entry_time = None
                    stop_loss = None
                    take_profit = None
            
            # Entry logic
            if position == 0 and gates_pass:
                if exp_ret > 0:
                    # Enter long
                    position = 1
                    entry_price = close_price + spread + slippage
                    entry_time = timestamp
                    stop_loss, take_profit = calculate_stop_take_levels(
                        close_price, exp_ret, q10, q90, atr, 1
                    )
                    
                elif exp_ret < 0:
                    # Enter short
                    position = -1
                    entry_price = close_price - spread - slippage
                    entry_time = timestamp
                    stop_loss, take_profit = calculate_stop_take_levels(
                        close_price, exp_ret, q10, q90, atr, -1
                    )
            
            # Progress reporting
            if verbose_every > 0 and past_warmup and idx % verbose_every == 0:
                pos_str = f"pos={position:+d}" if position != 0 else "pos=flat"
                sys.stdout.write(
                    f"\r[{idx+1}/{total_rows}] {timestamp} {pos_str} "
                    f"exp={exp_ret:+.3f} conf={conf:.2f} unc={unc:.2f} atr={atr:.4f}"
                )
                sys.stdout.flush()
            
            # Debug sample output
            if debug_sample > 0 and diagnostics["total_bars"] <= debug_sample:
                gate_status = "PASS" if gates_pass else "FAIL"
                failed_gates = [k for k, v in gate_details.items() if not v]
                print(f"\nDEBUG [{diagnostics['total_bars']}] {timestamp}")
                print(f"  Prediction: exp={exp_ret:.4f} conf={conf:.3f} unc={unc:.3f}")
                print(f"  Market: atr={atr:.5f} close={close_price:.5f}")
                print(f"  Gates: {gate_status} (failed: {failed_gates})")
                print(f"  Position: {position}")
                
        except Exception as e:
            print(f"\nError processing row {idx} at {timestamp}: {e}")
            if isinstance(e, BacktestError):
                raise
            else:
                raise BacktestError(f"Unexpected error at row {idx}: {e}")
    
    # Close any remaining position
    if position != 0 and entry_price is not None:
        final_timestamp = df_feat.index[-1]
        final_price = float(df_feat.iloc[-1][ccol])
        
        if position > 0:
            pnl = final_price - entry_price
        else:
            pnl = entry_price - final_price
        
        trades_list.append([
            entry_time, final_timestamp,
            "LONG" if position > 0 else "SHORT",
            entry_price, final_price, "EOD", pnl,
            0.0, 0.0, 0.0  # No prediction data for final close
        ])
    
    # Create trades DataFrame
    trades = pd.DataFrame(trades_list, columns=[
        "entry_time", "exit_time", "side", "entry_price", "exit_price", 
        "exit_reason", "pnl", "conf", "unc", "exp_ret"
    ])
    
    # Print comprehensive diagnostics
    print_diagnostics(diagnostics, metrics, rows_processed, tau_conf, tau_unc, atr_floor)
    
    return trades

def print_diagnostics(diagnostics: dict, metrics: dict, total_processed: int,
                     tau_conf: float, tau_unc: float, atr_floor: float):
    """Print comprehensive diagnostic information"""
    
    def pct(count: int, total: int) -> str:
        return f"{100.0 * count / max(1, total):5.1f}%"
    
    print("\n\n" + "="*50)
    print("BACKTEST DIAGNOSTICS")
    print("="*50)
    
    total_bars = diagnostics["total_bars"]
    
    print(f"Data Processing:")
    print(f"  Total rows processed: {total_processed}")
    print(f"  Warmup skipped: {diagnostics['warmup_skip']}")
    print(f"  Post-warmup bars: {total_bars}")
    
    print(f"\nTrading Gates Analysis:")
    print(f"  Gate thresholds: conf≥{tau_conf}, unc≤{tau_unc}, |exp|≥{atr_floor}")
    print(f"  Gates passed: {diagnostics['gate_passed']} ({pct(diagnostics['gate_passed'], total_bars)})")
    
    print(f"  Gate failures:")
    for gate_type, count in diagnostics["gate_failed"].items():
        print(f"    {gate_type}: {count} ({pct(count, total_bars)})")
    
    # Metrics statistics
    if metrics["confidence"]:
        conf_arr = np.array(metrics["confidence"])
        unc_arr = np.array(metrics["uncertainty"])
        exp_arr = np.array(metrics["expected_return"])
        atr_arr = np.array(metrics["atr"])
        
        print(f"\nPrediction Metrics Distribution:")
        print(f"  Confidence - mean: {conf_arr.mean():.3f}, "
              f"median: {np.median(conf_arr):.3f}, "
              f"p90: {np.percentile(conf_arr, 90):.3f}")
        
        print(f"  Uncertainty - mean: {unc_arr.mean():.3f}, "
              f"median: {np.median(unc_arr):.3f}, "
              f"p90: {np.percentile(unc_arr, 90):.3f}")
        
        print(f"  |Expected Return| - mean: {np.abs(exp_arr).mean():.4f}, "
              f"median: {np.median(np.abs(exp_arr)):.4f}, "
              f"p90: {np.percentile(np.abs(exp_arr), 90):.4f}")
        
        print(f"  ATR - mean: {atr_arr.mean():.6f}, "
              f"median: {np.median(atr_arr):.6f}")

def calculate_performance_metrics(trades: pd.DataFrame) -> Dict[str, float]:
    """Calculate comprehensive performance metrics"""
    if trades.empty:
        return {
            "total_trades": 0,
            "profit_factor": 0.0,
            "win_rate": 0.0,
            "avg_pnl": 0.0,
            "total_pnl": 0.0,
            "max_drawdown": 0.0,
            "sharpe_ratio": 0.0,
            "sortino_ratio": 0.0,
            "calmar_ratio": 0.0,
            "avg_win": 0.0,
            "avg_loss": 0.0,
            "largest_win": 0.0,
            "largest_loss": 0.0,
            "consecutive_wins": 0,
            "consecutive_losses": 0
        }
    
    pnl = trades["pnl"].values
    
    # Basic metrics
    total_trades = len(trades)
    total_pnl = float(pnl.sum())
    avg_pnl = float(pnl.mean())
    
    # Win/loss analysis
    wins = pnl[pnl > 0]
    losses = pnl[pnl < 0]
    
    win_rate = len(wins) / total_trades if total_trades > 0 else 0.0
    gross_profit = wins.sum() if len(wins) > 0 else 0.0
    gross_loss = abs(losses.sum()) if len(losses) > 0 else 0.0
    
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
    
    avg_win = float(wins.mean()) if len(wins) > 0 else 0.0
    avg_loss = float(losses.mean()) if len(losses) > 0 else 0.0
    largest_win = float(wins.max()) if len(wins) > 0 else 0.0
    largest_loss = float(losses.min()) if len(losses) > 0 else 0.0
    
    # Drawdown calculation
    cumulative = np.cumsum(pnl)
    running_max = np.maximum.accumulate(cumulative)
    drawdown = cumulative - running_max
    max_drawdown = float(drawdown.min()) if len(drawdown) > 0 else 0.0
    
    # Risk-adjusted returns (assuming daily frequency approximation)
    pnl_std = float(pnl.std()) if len(pnl) > 1 else 0.0
    downside_std = float(pnl[pnl < 0].std()) if len(pnl[pnl < 0]) > 1 else 0.0
    
    # Annualization factor (approximate for hourly data)
    ann_factor = np.sqrt(252 * 24)  # 252 trading days * 24 hours
    
    sharpe_ratio = (avg_pnl / pnl_std * ann_factor) if pnl_std > 0 else 0.0
    sortino_ratio = (avg_pnl / downside_std * ann_factor) if downside_std > 0 else 0.0
    calmar_ratio = (total_pnl / abs(max_drawdown)) if max_drawdown < 0 else 0.0
    
    # Consecutive wins/losses
    consecutive_wins = 0
    consecutive_losses = 0
    current_wins = 0
    current_losses = 0
    
    for p in pnl:
        if p > 0:
            current_wins += 1
            current_losses = 0
            consecutive_wins = max(consecutive_wins, current_wins)
        elif p < 0:
            current_losses += 1
            current_wins = 0
            consecutive_losses = max(consecutive_losses, current_losses)
        else:
            current_wins = 0
            current_losses = 0
    
    return {
        "total_trades": total_trades,
        "profit_factor": profit_factor,
        "win_rate": win_rate,
        "avg_pnl": avg_pnl,
        "total_pnl": total_pnl,
        "max_drawdown": max_drawdown,
        "sharpe_ratio": sharpe_ratio,
        "sortino_ratio": sortino_ratio,
        "calmar_ratio": calmar_ratio,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "largest_win": largest_win,
        "largest_loss": largest_loss,
        "consecutive_wins": consecutive_wins,
        "consecutive_losses": consecutive_losses,
        "gross_profit": gross_profit,
        "gross_loss": gross_loss
    }

def print_performance_summary(metrics: Dict[str, float]):
    """Print formatted performance summary"""
    print("\n" + "="*50)
    print("BACKTEST PERFORMANCE SUMMARY")
    print("="*50)
    
    print(f"Trade Statistics:")
    print(f"  Total trades: {metrics['total_trades']}")
    print(f"  Win rate: {metrics['win_rate']:.1%}")
    print(f"  Profit factor: {metrics['profit_factor']:.2f}")
    
    print(f"\nP&L Analysis:")
    print(f"  Total P&L: {metrics['total_pnl']:+.4f}")
    print(f"  Average P&L per trade: {metrics['avg_pnl']:+.4f}")
    print(f"  Gross profit: {metrics['gross_profit']:+.4f}")
    print(f"  Gross loss: {metrics['gross_loss']:+.4f}")
    
    print(f"\nWin/Loss Details:")
    print(f"  Average win: {metrics['avg_win']:+.4f}")
    print(f"  Average loss: {metrics['avg_loss']:+.4f}")
    print(f"  Largest win: {metrics['largest_win']:+.4f}")
    print(f"  Largest loss: {metrics['largest_loss']:+.4f}")
    
    print(f"\nRisk Metrics:")
    print(f"  Maximum drawdown: {metrics['max_drawdown']:+.4f}")
    print(f"  Sharpe ratio: {metrics['sharpe_ratio']:.2f}")
    print(f"  Sortino ratio: {metrics['sortino_ratio']:.2f}")
    print(f"  Calmar ratio: {metrics['calmar_ratio']:.2f}")
    
    print(f"\nStreak Analysis:")
    print(f"  Max consecutive wins: {metrics['consecutive_wins']}")
    print(f"  Max consecutive losses: {metrics['consecutive_losses']}")

def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(description="Enhanced HTTP Backtesting Client")
    
    # Required arguments
    parser.add_argument("--server_url", default="http://127.0.0.1:8000",
                       help="ML server URL")
    parser.add_argument("--data_root", required=True,
                       help="Root directory for data files")
    parser.add_argument("--symbol", required=True,
                       help="Primary trading symbol")
    parser.add_argument("--file", required=True,
                       help="Data filename")
    
    # Trading parameters
    parser.add_argument("--spread_points", type=int, default=10,
                       help="Bid-ask spread in points")
    parser.add_argument("--slippage_points", type=int, default=2,
                       help="Slippage in points")
    
    # Gate parameters
    parser.add_argument("--tau_conf", type=float, default=0.70,
                       help="Minimum confidence threshold")
    parser.add_argument("--tau_unc", type=float, default=0.60,
                       help="Maximum uncertainty threshold")
    parser.add_argument("--atr_floor", type=float, default=0.25,
                       help="Minimum expected return magnitude (in ATR units)")
    
    # Output and debugging
    parser.add_argument("--export_trades", default="./backtest_trades.csv",
                       help="Export trades to CSV file")
    parser.add_argument("--verbose_every", type=int, default=0,
                       help="Print progress every N bars (0=disable)")
    parser.add_argument("--debug_sample", type=int, default=5,
                       help="Print debug info for first N post-warmup bars")
    
    args = parser.parse_args()
    
    try:
        # Load and process data
        print("Loading and processing data...")
        file_dict = {args.symbol: args.file}
        merged = load_and_align_data(file_dict, args.data_root)
        df_feat, feature_cols = build_features(merged, primary_symbol=args.symbol)
        
        # Validate features
        if not validate_features(df_feat, feature_cols):
            raise BacktestError("Feature validation failed")
        
        print(f"Data loaded: {len(df_feat)} rows, {len(feature_cols)} features")
        
        # Run backtest
        trades = simulate_backtest(
            df_feat, feature_cols, args.server_url, args.symbol,
            args.spread_points, args.slippage_points, args.verbose_every,
            args.tau_conf, args.tau_unc, args.atr_floor, args.debug_sample
        )
        
        # Calculate and display performance
        performance = calculate_performance_metrics(trades)
        print_performance_summary(performance)
        
        # Export trades
        if args.export_trades:
            output_path = Path(args.export_trades)
            trades.to_csv(output_path, index=False)
            print(f"\nTrades exported to: {output_path.resolve()}")
            
            # Export summary metrics
            summary_path = output_path.with_suffix('.summary.json')
            import json
            with open(summary_path, 'w') as f:
                json.dump(performance, f, indent=2)
            print(f"Performance summary exported to: {summary_path.resolve()}")
        
    except BacktestError as e:
        print(f"Backtest error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
