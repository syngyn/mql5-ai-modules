#!/usr/bin/env python3
"""
Enhanced daemon: loads trained artifacts and provides a Predictor API
for batch or single-row inference. Supports MODEL_TYPE={lstm,transformer,tcn,moe}
with MoE weighting w = conf / (eps + unc). Includes regime bias hooks.

Fixed version with proper error handling and compatibility.
"""

import os
import json
import argparse
import warnings
from pathlib import Path
from typing import Dict, List, Any, Optional, Union

import numpy as np
import torch
from torch import nn
import joblib
import pandas as pd

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Import model classes with fallback
try:
    from enhanced_train_model import AttentionLSTM, PriceTransformer, TCNExpert, AttentionPooling
    print("[INFO] Using enhanced_train_model")
except ImportError:
    try:
        from enhanced_train_model_verbose import AttentionLSTM, PriceTransformer, TCNExpert, AttentionPooling
        print("[INFO] Using enhanced_train_model_verbose")
    except ImportError:
        raise ImportError("Could not import model classes from either enhanced_train_model or enhanced_train_model_verbose")

EPS = 1e-8

def softmax(x: np.ndarray) -> np.ndarray:
    """Stable softmax implementation"""
    x = np.asarray(x)
    e = np.exp(x - x.max(axis=-1, keepdims=True))
    return e / (e.sum(axis=-1, keepdims=True) + EPS)

class ModelLoadError(Exception):
    """Custom exception for model loading errors"""
    pass

class PredictionError(Exception):
    """Custom exception for prediction errors"""
    pass

class Predictor:
    """
    Enhanced prediction engine with robust error handling and multiple model support.
    """
    
    def __init__(self, model_dir: Union[str, Path], device: Optional[str] = None, 
                 regime_bias: bool = True, validate_models: bool = True):
        """
        Initialize the predictor with trained models and artifacts.
        
        Args:
            model_dir: Directory containing model artifacts
            device: Target device ('cpu', 'cuda', or None for auto)
            regime_bias: Whether to apply regime-based weighting
            validate_models: Whether to validate model loading
        """
        self.model_dir = Path(model_dir)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.regime_bias = regime_bias
        
        print(f"[INFO] Initializing predictor on device: {self.device}")
        print(f"[INFO] Model directory: {self.model_dir.resolve()}")
        
        if not self.model_dir.exists():
            raise ModelLoadError(f"Model directory not found: {self.model_dir}")
        
        # Load artifacts
        self._load_scaler()
        self._load_model_card()
        self._load_temperatures()
        self._load_models()
        
        if validate_models:
            self._validate_setup()
        
        print(f"[INFO] Predictor initialized with {len(self.models)} models")
    
    def _load_scaler(self):
        """Load feature scaler"""
        scaler_path = self.model_dir / "scaler.joblib"
        if not scaler_path.exists():
            raise ModelLoadError(f"Scaler not found: {scaler_path}")
        
        try:
            self.scaler = joblib.load(scaler_path)
            print(f"[INFO] Loaded scaler from {scaler_path}")
        except Exception as e:
            raise ModelLoadError(f"Failed to load scaler: {e}")
    
    def _load_model_card(self):
        """Load model configuration"""
        card_path = self.model_dir / "model_card.json"
        if not card_path.exists():
            raise ModelLoadError(f"Model card not found: {card_path}")
        
        try:
            with open(card_path, 'r') as f:
                self.card = json.load(f)
            
            # Extract key parameters
            self.feature_cols = self.card.get("feature_cols", [])
            self.model_type = self.card.get("model_type", "moe").lower()
            self.seq_len = int(self.card.get("seq_len", 128))
            self.experts = self.card.get("experts", [])
            
            if not self.feature_cols:
                raise ModelLoadError("No feature columns found in model card")
            
            print(f"[INFO] Model card loaded: {self.model_type} with {len(self.feature_cols)} features")
            
        except Exception as e:
            raise ModelLoadError(f"Failed to load model card: {e}")
    
    def _load_temperatures(self):
        """Load temperature scaling parameters"""
        temps_path = self.model_dir / "temps.json"
        self.temps = {}
        
        if temps_path.exists():
            try:
                with open(temps_path, 'r') as f:
                    temp_data = json.load(f)
                
                for name, temp_info in temp_data.items():
                    if isinstance(temp_info, dict):
                        self.temps[name] = float(temp_info.get("temp", 1.0))
                    else:
                        self.temps[name] = float(temp_info)
                
                print(f"[INFO] Loaded temperature scaling for: {list(self.temps.keys())}")
                
            except Exception as e:
                print(f"[WARN] Failed to load temperatures: {e}")
                self.temps = {}
        else:
            print(f"[INFO] No temperature scaling file found")
    
    def _load_models(self):
        """Load neural network models"""
        self.models = {}
        
        if not self.experts:
            # Fallback: try to infer from available files
            self.experts = []
            for model_file in self.model_dir.glob("*.pt"):
                if model_file.stem in ["lstm", "transformer", "tcn"]:
                    self.experts.append(model_file.stem)
        
        if not self.experts:
            raise ModelLoadError("No expert models specified or found")
        
        # Model parameters
        input_features = len(self.feature_cols)
        num_classes = 3
        out_steps = 1
        hidden = 256
        layers = 2
        
        for expert_name in self.experts:
            try:
                model = self._create_model(
                    expert_name, input_features, hidden, layers, num_classes, out_steps
                )
                self._load_model_weights(model, expert_name)
                model.to(self.device).eval()
                self.models[expert_name] = model
                
                print(f"[INFO] Loaded {expert_name} model")
                
            except Exception as e:
                print(f"[WARN] Failed to load {expert_name}: {e}")
                continue
        
        if not self.models:
            raise ModelLoadError("No models successfully loaded")
    
    def _create_model(self, name: str, input_features: int, hidden: int, 
                     layers: int, num_classes: int, out_steps: int) -> nn.Module:
        """Create model instance"""
        name = name.lower()
        
        if name == "lstm":
            return AttentionLSTM(
                input_size=input_features,
                hidden_size=hidden,
                num_layers=layers,
                num_classes=num_classes,
                out_steps=out_steps
            )
        elif name == "transformer":
            return PriceTransformer(
                input_size=input_features,
                d_model=hidden,
                n_heads=8,
                num_layers=layers,
                num_classes=num_classes,
                out_steps=out_steps
            )
        elif name == "tcn":
            return TCNExpert(
                input_size=input_features,
                hidden_size=hidden,
                num_layers=layers,
                num_classes=num_classes,
                out_steps=out_steps
            )
        else:
            raise ModelLoadError(f"Unknown model type: {name}")
    
    def _load_model_weights(self, model: nn.Module, name: str):
        """Load model weights from checkpoint"""
        ckpt_path = self.model_dir / f"{name}.pt"
        if not ckpt_path.exists():
            raise ModelLoadError(f"Model checkpoint not found: {ckpt_path}")
        
        try:
            state_dict = torch.load(ckpt_path, map_location=self.device)
            model.load_state_dict(state_dict, strict=False)
        except Exception as e:
            raise ModelLoadError(f"Failed to load weights for {name}: {e}")
    
    def _validate_setup(self):
        """Validate predictor setup"""
        if not self.models:
            raise ModelLoadError("No models loaded")
        
        if not self.feature_cols:
            raise ModelLoadError("No feature columns defined")
        
        if self.seq_len <= 0:
            raise ModelLoadError(f"Invalid sequence length: {self.seq_len}")
        
        # Test with dummy data
        try:
            dummy_data = np.random.randn(self.seq_len, len(self.feature_cols)).astype(np.float32)
            _ = self._predict_seq(dummy_data)
            print("[INFO] Model validation passed")
        except Exception as e:
            raise ModelLoadError(f"Model validation failed: {e}")
    
    def _regime_bias(self, weights: Dict[str, float], features_row: np.ndarray) -> Dict[str, float]:
        """
        Apply regime-based bias to expert weights.
        
        Args:
            weights: Current expert weights
            features_row: Latest feature vector
            
        Returns:
            Adjusted weights
        """
        if not self.regime_bias or len(weights) <= 1:
            return weights
        
        try:
            # Find regime indicators in feature vector
            adx_idx = None
            rv_idx = None
            
            for i, col in enumerate(self.feature_cols):
                if "adx14" in col.lower():
                    adx_idx = i
                if "rv20" in col.lower():
                    rv_idx = i
            
            if adx_idx is None or rv_idx is None:
                return weights  # No regime indicators available
            
            adx = features_row[adx_idx]
            rv = features_row[rv_idx]
            
            # Simple regime detection
            bias_transformer = 0.0
            
            # High volatility + trending market
            if adx > 20 and rv > np.median([rv, 0.01]):
                bias_transformer += 0.15
            
            # Apply bias
            adjusted_weights = weights.copy()
            if "transformer" in adjusted_weights:
                adjusted_weights["transformer"] = min(1.0, adjusted_weights["transformer"] + bias_transformer)
            
            # Renormalize
            total_weight = sum(adjusted_weights.values()) + EPS
            for key in adjusted_weights:
                adjusted_weights[key] /= total_weight
            
            return adjusted_weights
            
        except Exception as e:
            print(f"[WARN] Regime bias calculation failed: {e}")
            return weights
    
    def _apply_temperature(self, name: str, logits: np.ndarray) -> np.ndarray:
        """Apply temperature scaling to logits"""
        temp = self.temps.get(name, 1.0)
        return logits / max(temp, 1e-3)
    
    def predict_batch(self, X: np.ndarray) -> List[Dict[str, Any]]:
        """
        Predict on batch of data.
        
        Args:
            X: Input features [N, F] - unscaled
            
        Returns:
            List of prediction dictionaries
        """
        if not isinstance(X, np.ndarray):
            X = np.array(X, dtype=np.float32)
        
        if X.ndim != 2:
            raise PredictionError(f"Expected 2D input, got {X.ndim}D")
        
        if X.shape[1] != len(self.feature_cols):
            raise PredictionError(
                f"Feature count mismatch: expected {len(self.feature_cols)}, got {X.shape[1]}"
            )
        
        # Scale features
        try:
            X_scaled = self.scaler.transform(X.astype(np.float32))
        except Exception as e:
            raise PredictionError(f"Feature scaling failed: {e}")
        
        # Create sequences
        N, F = X_scaled.shape
        T = self.seq_len
        
        if N < T:
            raise PredictionError(f"Not enough rows for seq_len={T}. Got {N} rows.")
        
        predictions = []
        
        for i in range(T - 1, N):
            seq = X_scaled[i - T + 1:i + 1]  # [T, F]
            try:
                pred = self._predict_seq(seq)
                predictions.append(pred)
            except Exception as e:
                raise PredictionError(f"Prediction failed at sequence {i}: {e}")
        
        return predictions
    
    def predict_single(self, features: Union[Dict[str, float], List[float], np.ndarray]) -> Dict[str, Any]:
        """
        Predict on single feature vector (requires maintaining history).
        
        Args:
            features: Single feature vector
            
        Returns:
            Prediction dictionary
        """
        # Convert to standard format
        if isinstance(features, dict):
            feature_vector = np.array([features.get(col, 0.0) for col in self.feature_cols])
        elif isinstance(features, (list, np.ndarray)):
            feature_vector = np.array(features)
        else:
            raise PredictionError(f"Unsupported feature format: {type(features)}")
        
        # For single prediction, we need a full sequence
        # This is a simplified version - in practice you'd maintain a rolling buffer
        if not hasattr(self, '_feature_buffer'):
            self._feature_buffer = []
        
        self._feature_buffer.append(feature_vector)
        
        if len(self._feature_buffer) < self.seq_len:
            raise PredictionError(f"Not enough history: need {self.seq_len}, have {len(self._feature_buffer)}")
        
        # Keep only the last seq_len items
        if len(self._feature_buffer) > self.seq_len:
            self._feature_buffer = self._feature_buffer[-self.seq_len:]
        
        # Create batch with single sequence
        X = np.array(self._feature_buffer)
        return self.predict_batch(X[None, ...])[0]  # Add batch dim and get first result
    
    def _predict_seq(self, seq: np.ndarray) -> Dict[str, Any]:
        """
        Predict on single sequence.
        
        Args:
            seq: Sequence of features [T, F] - scaled
            
        Returns:
            Prediction dictionary
        """
        if seq.shape != (self.seq_len, len(self.feature_cols)):
            raise PredictionError(f"Invalid sequence shape: {seq.shape}")
        
        # Convert to tensor
        xb = torch.from_numpy(seq[None, ...]).float().to(self.device)  # [1, T, F]
        
        expert_outputs = {}
        weights = {}
        
        # Get predictions from all experts
        for name, model in self.models.items():
            try:
                with torch.no_grad():
                    outputs = model(xb)
                    
                if len(outputs) != 5:
                    raise PredictionError(f"Invalid model output format from {name}")
                
                reg, cls, unc, conf, quantiles = outputs
                
                # Extract quantiles
                if isinstance(quantiles, (list, tuple)) and len(quantiles) == 3:
                    q10, q50, q90 = quantiles
                else:
                    q10 = q50 = q90 = torch.zeros_like(reg)
                
                # Convert to numpy
                reg_np = reg.cpu().numpy()[0]
                cls_np = cls.cpu().numpy()[0]
                unc_np = np.maximum(unc.cpu().numpy()[0], EPS)
                conf_np = float(conf.cpu().numpy()[0])
                q10_np = float(q10.cpu().numpy()[0])
                q50_np = float(q50.cpu().numpy()[0])
                q90_np = float(q90.cpu().numpy()[0])
                
                # Apply temperature scaling
                cls_scaled = self._apply_temperature(name, cls_np)
                probs = softmax(cls_scaled)
                
                expert_outputs[name] = {
                    "regression": reg_np.tolist() if reg_np.ndim > 0 else [float(reg_np)],
                    "class_logits": cls_scaled.tolist(),
                    "class_probs": probs.tolist(),
                    "uncertainty": unc_np.tolist() if unc_np.ndim > 0 else [float(unc_np)],
                    "confidence": conf_np,
                    "quantiles": {"p10": q10_np, "p50": q50_np, "p90": q90_np}
                }
                
                # Calculate ensemble weight
                unc_val = float(unc_np[0]) if hasattr(unc_np, '__len__') else float(unc_np)
                weights[name] = conf_np / (EPS + unc_val)
                
            except Exception as e:
                print(f"[WARN] Expert {name} prediction failed: {e}")
                continue
        
        if not expert_outputs:
            raise PredictionError("All expert predictions failed")
        
        # Normalize weights
        total_weight = sum(weights.values()) + EPS
        for name in weights:
            weights[name] /= total_weight
        
        # Apply regime bias
        if len(weights) > 1:
            last_row = seq[-1]
            weights = self._regime_bias(weights, last_row)
        
        # Ensemble predictions
        reg_ensemble = 0.0
        conf_ensemble = 0.0
        unc_ensemble = 0.0
        q10_ensemble = 0.0
        q50_ensemble = 0.0
        q90_ensemble = 0.0
        
        for name, weight in weights.items():
            output = expert_outputs[name]
            reg_ensemble += weight * output["regression"][0]
            conf_ensemble += weight * output["confidence"]
            unc_ensemble += weight * output["uncertainty"][0]
            q10_ensemble += weight * output["quantiles"]["p10"]
            q50_ensemble += weight * output["quantiles"]["p50"]
            q90_ensemble += weight * output["quantiles"]["p90"]
        
        return {
            "experts": expert_outputs,
            "weights": weights,
            "ensemble": {
                "expected_return": reg_ensemble,
                "confidence": conf_ensemble,
                "uncertainty": max(unc_ensemble, EPS),
                "quantiles": {
                    "p10": q10_ensemble,
                    "p50": q50_ensemble,
                    "p90": q90_ensemble
                }
            }
        }
    
    def get_info(self) -> Dict[str, Any]:
        """Get predictor information"""
        return {
            "model_type": self.model_type,
            "experts": list(self.models.keys()),
            "feature_count": len(self.feature_cols),
            "sequence_length": self.seq_len,
            "device": self.device,
            "regime_bias": self.regime_bias,
            "temperature_scaling": list(self.temps.keys()),
            "model_dir": str(self.model_dir)
        }

def main():
    """CLI interface for testing the predictor"""
    parser = argparse.ArgumentParser(description="Enhanced ML Predictor Daemon")
    parser.add_argument("--model_dir", required=True, help="Directory with model artifacts")
    parser.add_argument("--csv", help="CSV file for batch testing")
    parser.add_argument("--device", help="Device to use (cpu/cuda)")
    parser.add_argument("--no_regime_bias", action="store_true", help="Disable regime bias")
    parser.add_argument("--validate", action="store_true", default=True, help="Validate models on startup")
    
    args = parser.parse_args()
    
    try:
        # Initialize predictor
        predictor = Predictor(
            model_dir=args.model_dir,
            device=args.device,
            regime_bias=not args.no_regime_bias,
            validate_models=args.validate
        )
        
        # Print info
        info = predictor.get_info()
        print("\nPredictor Information:")
        for key, value in info.items():
            print(f"  {key}: {value}")
        
        # Test with CSV if provided
        if args.csv:
            print(f"\nTesting with CSV: {args.csv}")
            
            try:
                df = pd.read_csv(args.csv)
                
                # Try to use the predictor's feature columns
                available_features = [col for col in predictor.feature_cols if col in df.columns]
                missing_features = [col for col in predictor.feature_cols if col not in df.columns]
                
                print(f"Available features: {len(available_features)}/{len(predictor.feature_cols)}")
                
                if missing_features:
                    print(f"Missing features (will be set to 0): {missing_features[:10]}...")
                
                # Prepare feature matrix
                X = np.zeros((len(df), len(predictor.feature_cols)), dtype=np.float32)
                for i, col in enumerate(predictor.feature_cols):
                    if col in df.columns:
                        X[:, i] = df[col].values
                
                # Run prediction on last window
                if len(X) >= predictor.seq_len:
                    predictions = predictor.predict_batch(X[-predictor.seq_len:])
                    
                    print(f"\nSample prediction (last window):")
                    print(json.dumps(predictions[-1], indent=2))
                else:
                    print(f"Not enough data for prediction (need {predictor.seq_len}, have {len(X)})")
                    
            except Exception as e:
                print(f"CSV testing failed: {e}")
        
        print("\nPredictor ready for use!")
        
    except Exception as e:
        print(f"Failed to initialize predictor: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    import sys
    sys.exit(main())
