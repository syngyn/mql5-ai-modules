#!/usr/bin/env python3
"""
Trading System Server Launcher
"""
import os
import sys
import json
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

def main():
    # Load configuration
    config_path = Path(__file__).parent / "config.json"
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
        
        host = config["server"]["host"]
        port = config["server"]["port"]
        workers = config["server"]["workers"]
    else:
        host, port, workers = "127.0.0.1", 8000, 1
    
    # Set model directory
    models_dir = Path(__file__).parent / "models"
    os.environ["MODEL_DIR"] = str(models_dir)
    
    print(f"Starting trading system server...")
    print(f"Server: http://{host}:{port}")
    print(f"Model directory: {models_dir}")
    print(f"Workers: {workers}")
    
    # Import and run server
    try:
        from http_server import app
        import uvicorn
        uvicorn.run(app, host=host, port=port, workers=workers)
    except ImportError as e:
        print(f"Error importing server components: {e}")
        print("Please ensure all dependencies are installed and source files are copied")
        sys.exit(1)

if __name__ == "__main__":
    main()
