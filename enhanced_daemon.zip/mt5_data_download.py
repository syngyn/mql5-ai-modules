#!/usr/bin/env python3
"""
MT5 Data Downloader for LSTM Trading System
==========================================
Downloads historical data directly from MetaTrader5 for training and backtesting.

Features:
- Direct MT5 connection and data download
- Automatic timezone handling
- Data validation and cleaning
- Multiple timeframe support
- Robust error handling

Requirements:
- MetaTrader5 package: pip install MetaTrader5
- MT5 terminal must be installed and running
"""

import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
import os
import warnings
warnings.filterwarnings('ignore')

class MT5DataDownloader:
    def __init__(self):
        self.connected = False
        self.account_info = None
        
    def connect(self):
        """Connect to MT5 terminal"""
        print("Connecting to MetaTrader5...")
        
        if not mt5.initialize():
            print("Failed to initialize MT5, error code:", mt5.last_error())
            return False
            
        # Get account info
        self.account_info = mt5.account_info()
        if self.account_info is None:
            print("Failed to get account info, error code:", mt5.last_error())
            return False
            
        print(f"Connected successfully to account {self.account_info.login}")
        print(f"Server: {self.account_info.server}")
        print(f"Company: {self.account_info.company}")
        
        self.connected = True
        return True
        
    def disconnect(self):
        """Disconnect from MT5"""
        if self.connected:
            mt5.shutdown()
            self.connected = False
            print("Disconnected from MT5")
            
    def get_available_symbols(self):
        """Get list of available symbols"""
        if not self.connected:
            print("Not connected to MT5")
            return []
            
        symbols = mt5.symbols_get()
        if symbols is None:
            print("No symbols found")
            return []
            
        return [symbol.name for symbol in symbols if symbol.visible]
        
    def download_historical_data(self, symbol="EURUSD", timeframe=mt5.TIMEFRAME_H1, 
                                num_bars=10000, save_to_csv=True):
        """
        Download historical data from MT5
        
        Parameters:
        - symbol: Trading symbol (default: EURUSD)
        - timeframe: MT5 timeframe constant (default: H1)
        - num_bars: Number of bars to download (default: 10000)
        - save_to_csv: Whether to save data to CSV file
        
        Returns:
        - pandas DataFrame with OHLCV data
        """
        if not self.connected:
            print("Not connected to MT5")
            return None
            
        print(f"Downloading {num_bars} bars of {symbol} data...")
        
        # Get historical data
        rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, num_bars)
        
        if rates is None:
            print(f"Failed to get data for {symbol}, error code:", mt5.last_error())
            return None
            
        if len(rates) == 0:
            print(f"No data received for {symbol}")
            return None
            
        # Convert to DataFrame
        df = pd.DataFrame(rates)
        
        # Convert time to datetime
        df['time'] = pd.to_datetime(df['time'], unit='s')
        
        # Set time as index
        df.set_index('time', inplace=True)
        
        # Rename columns to match expected format
        df.rename(columns={
            'open': 'Open',
            'high': 'High', 
            'low': 'Low',
            'close': 'Close',
            'tick_volume': 'Volume'
        }, inplace=True)
        
        # Remove spread column if present
        if 'spread' in df.columns:
            df.drop('spread', axis=1, inplace=True)
            
        # Sort by time
        df.sort_index(inplace=True)
        
        # Data validation
        self._validate_data(df, symbol)
        
        print(f"Downloaded {len(df)} bars from {df.index[0]} to {df.index[-1]}")
        print(f"Price range: {df['Close'].min():.5f} - {df['Close'].max():.5f}")
        
        # Save to CSV if requested
        if save_to_csv:
            self._save_to_csv(df, symbol, timeframe)
            
        return df
        
    def _validate_data(self, df, symbol):
        """Validate downloaded data"""
        
        # Check for missing values
        missing_count = df.isnull().sum().sum()
        if missing_count > 0:
            print(f"Warning: {missing_count} missing values found")
            
        # Check for duplicate timestamps
        duplicate_count = df.index.duplicated().sum()
        if duplicate_count > 0:
            print(f"Warning: {duplicate_count} duplicate timestamps found")
            df = df[~df.index.duplicated(keep='first')]
            
        # Check OHLC validity
        invalid_ohlc = (
            (df['High'] < df['Low']) |
            (df['High'] < df['Open']) |
            (df['High'] < df['Close']) |
            (df['Low'] > df['Open']) |
            (df['Low'] > df['Close'])
        ).sum()
        
        if invalid_ohlc > 0:
            print(f"Warning: {invalid_ohlc} bars with invalid OHLC data")
            
        # Check for reasonable forex price ranges (specific to EURUSD)
        if symbol == "EURUSD":
            if df['Close'].min() < 0.5 or df['Close'].max() > 3.0:
                print(f"Warning: Unusual price range for {symbol}")
                
        # Check for zero volume
        zero_volume = (df['Volume'] == 0).sum()
        if zero_volume > 0:
            print(f"Info: {zero_volume} bars with zero volume (normal for some brokers)")
            
    def _save_to_csv(self, df, symbol, timeframe):
        """Save data to CSV file"""
        
        # Create filename
        timeframe_map = {
            mt5.TIMEFRAME_M1: "M1",
            mt5.TIMEFRAME_M5: "M5",
            mt5.TIMEFRAME_M15: "M15",
            mt5.TIMEFRAME_M30: "M30",
            mt5.TIMEFRAME_H1: "H1",
            mt5.TIMEFRAME_H4: "H4",
            mt5.TIMEFRAME_D1: "D1"
        }
        
        tf_str = timeframe_map.get(timeframe, "UNK")
        filename = f"{symbol}_{tf_str}.csv"
        
        # Prepare data for saving
        df_save = df.copy()
        df_save.reset_index(inplace=True)
        
        # Format datetime for MT5 compatibility
        df_save['Date'] = df_save['time'].dt.strftime('%Y.%m.%d %H:%M:%S')
        df_save.drop('time', axis=1, inplace=True)
        
        # Reorder columns
        columns_order = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume']
        df_save = df_save[columns_order]
        
        # Save to CSV
        df_save.to_csv(filename, index=False)
        print(f"Data saved to {filename}")
        
    def download_multiple_symbols(self, symbols_list, timeframe=mt5.TIMEFRAME_H1, 
                                 num_bars=10000):
        """Download data for multiple symbols"""
        
        if not self.connected:
            print("Not connected to MT5")
            return {}
            
        data_dict = {}
        
        for symbol in symbols_list:
            print(f"\nDownloading {symbol}...")
            df = self.download_historical_data(symbol, timeframe, num_bars)
            if df is not None:
                data_dict[symbol] = df
            else:
                print(f"Failed to download {symbol}")
                
        return data_dict
        
    def get_current_rates(self, symbols_list):
        """Get current market rates for symbols"""
        
        if not self.connected:
            print("Not connected to MT5")
            return {}
            
        current_rates = {}
        
        for symbol in symbols_list:
            tick = mt5.symbol_info_tick(symbol)
            if tick is not None:
                current_rates[symbol] = {
                    'bid': tick.bid,
                    'ask': tick.ask,
                    'last': tick.last,
                    'time': datetime.fromtimestamp(tick.time)
                }
            else:
                print(f"Failed to get current rate for {symbol}")
                
        return current_rates
        
    def get_market_hours_info(self):
        """Get market trading hours information"""
        
        if not self.connected:
            print("Not connected to MT5")
            return None
            
        # Get terminal info
        terminal_info = mt5.terminal_info()
        if terminal_info is None:
            return None
            
        # Some MT5 versions don't have timezone attribute
        timezone_info = getattr(terminal_info, 'timezone', 'Unknown')
        
        return {
            'timezone': timezone_info,
            'server_time': datetime.now(),
            'local_time': datetime.now(),
            'is_trade_allowed': terminal_info.trade_allowed,
            'is_connected': terminal_info.connected
        }

def main():
    """Example usage"""
    
    downloader = MT5DataDownloader()
    
    try:
        # Connect to MT5
        if not downloader.connect():
            print("Failed to connect to MT5")
            return
            
        # Get available symbols (optional)
        print("\nAvailable forex symbols:")
        symbols = downloader.get_available_symbols()
        forex_symbols = [s for s in symbols if any(pair in s for pair in ['EUR', 'USD', 'GBP', 'JPY'])]
        print(forex_symbols[:10])  # Show first 10
        
        # Download EURUSD H1 data
        print("\nDownloading EURUSD data...")
        df = downloader.download_historical_data(
            symbol="EURUSD",
            timeframe=mt5.TIMEFRAME_H1,
            num_bars=10000,
            save_to_csv=True
        )
        
        if df is not None:
            print(f"Successfully downloaded {len(df)} bars")
            print(f"Data shape: {df.shape}")
            print(f"Columns: {list(df.columns)}")
            print("\nFirst 5 rows:")
            print(df.head())
            print("\nLast 5 rows:")
            print(df.tail())
            
            # Basic statistics
            print(f"\nPrice Statistics:")
            print(f"Close price mean: {df['Close'].mean():.5f}")
            print(f"Close price std: {df['Close'].std():.5f}")
            print(f"Daily return mean: {df['Close'].pct_change().mean()*100:.4f}%")
            print(f"Daily return std: {df['Close'].pct_change().std()*100:.4f}%")
            
        # Get current market rates
        print("\nCurrent market rates:")
        current_rates = downloader.get_current_rates(['EURUSD', 'GBPUSD', 'USDJPY'])
        for symbol, rates in current_rates.items():
            print(f"{symbol}: Bid={rates['bid']:.5f}, Ask={rates['ask']:.5f}")
            
        # Get market hours info
        market_info = downloader.get_market_hours_info()
        if market_info:
            print(f"\nMarket Info:")
            print(f"Timezone: {market_info['timezone']}")
            print(f"Trade allowed: {market_info['is_trade_allowed']}")
            print(f"Connected: {market_info['is_connected']}")
            
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        # Always disconnect
        downloader.disconnect()

if __name__ == "__main__":
    main()