#!/usr/bin/env python3
"""
Trading System Training Launcher
"""
import os
import sys
import json
import argparse
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

def main():
    parser = argparse.ArgumentParser(description="Train trading models")
    parser.add_argument("--symbol", default="EURUSD", help="Trading symbol")
    parser.add_argument("--file", help="Data file name (auto-detected if not provided)")
    parser.add_argument("--model_type", default="moe", choices=["lstm", "transformer", "tcn", "moe"])
    parser.add_argument("--epochs", type=int, help="Training epochs (from config if not provided)")
    
    args = parser.parse_args()
    
    # Load configuration
    config_path = Path(__file__).parent / "config.json"
    config = {}
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
    
    # Set defaults from config
    data_dir = Path(__file__).parent / config.get("paths", {}).get("data_dir", "data")
    models_dir = Path(__file__).parent / config.get("paths", {}).get("models_dir", "models")
    epochs = args.epochs or config.get("model", {}).get("epochs", 10)
    
    # Auto-detect data file if not provided
    data_file = args.file
    if not data_file:
        # Look for files matching the symbol
        possible_files = list(data_dir.glob(f"{args.symbol}*.csv"))
        if possible_files:
            data_file = possible_files[0].name
            print(f"Auto-detected data file: {data_file}")
        else:
            print(f"No data file found for {args.symbol} in {data_dir}")
            print("Available files:")
            for f in data_dir.glob("*.csv"):
                print(f"  {f.name}")
            sys.exit(1)
    
    # Build training command
    cmd_args = [
        sys.executable, "enhanced_train_model.py",
        "--data_root", str(data_dir),
        "--symbol", args.symbol,
        "--file", data_file,
        "--out_dir", str(models_dir),
        "--model_type", args.model_type,
        "--epochs", str(epochs)
    ]
    
    print(f"Training {args.model_type} model for {args.symbol}")
    print(f"Data: {data_dir / data_file}")
    print(f"Output: {models_dir}")
    print(f"Command: {' '.join(cmd_args)}")
    
    # Run training
    try:
        import subprocess
        result = subprocess.run(cmd_args, check=True)
        print("Training completed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"Training failed with exit code {e.returncode}")
        sys.exit(1)
    except FileNotFoundError:
        print("Training script not found. Please check that enhanced_train_model.py is in this directory.")
        sys.exit(1)

if __name__ == "__main__":
    main()
