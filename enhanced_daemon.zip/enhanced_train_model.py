#!/usr/bin/env python3
"""
Enhanced training model - corrected version that matches the verbose implementation
but with cleaner structure for production use.
"""

import os, json, argparse, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime

import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
import joblib

from data_processing import load_and_align_data, build_features

print("[enhanced_train_model v1.2.0] loaded")

# ====== Core Modules ======

class SE(nn.Module):
    """Squeeze-and-Excitation block"""
    def __init__(self, c, r=8):
        super().__init__()
        hidden = max(1, c // r)
        self.fc = nn.Sequential(
            nn.Linear(c, hidden),
            nn.ReLU(),
            nn.Linear(hidden, c),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        if x.dim() == 3:
            w = self.fc(x.mean(1))
            return x * w.unsqueeze(1)
        return x * self.fc(x)

class ConvStem1D(nn.Module):
    """1D Convolutional stem with depthwise separable convolution"""
    def __init__(self, in_ch, out_ch, k=5, dropout=0.05):
        super().__init__()
        pad = (k - 1) // 2
        self.dw = nn.Conv1d(in_ch, in_ch, k, padding=pad, groups=in_ch)
        self.pw = nn.Conv1d(in_ch, out_ch, 1)
        self.bn = nn.BatchNorm1d(out_ch)
        self.act = nn.GELU()
        self.se = SE(out_ch)
        self.do = nn.Dropout(dropout)
    
    def forward(self, x):
        # x: [B, T, F] -> [B, F, T] for conv1d
        z = x.transpose(1, 2)
        z = self.pw(self.dw(z))
        z = self.act(self.bn(z))
        # Back to [B, T, F]
        z = z.transpose(1, 2)
        z = self.se(z)
        return self.do(z)

class GLU(nn.Module):
    """Gated Linear Unit"""
    def __init__(self, d):
        super().__init__()
        self.lin = nn.Linear(d, 2 * d)
    
    def forward(self, x):
        a, b = self.lin(x).chunk(2, -1)
        return a * torch.sigmoid(b)

class GRN(nn.Module):
    """Gated Residual Network"""
    def __init__(self, d, c=4):
        super().__init__()
        self.ff = nn.Sequential(
            nn.LayerNorm(d),
            nn.Linear(d, c * d),
            nn.GELU(),
            nn.Linear(c * d, d)
        )
        self.glu = GLU(d)
    
    def forward(self, x, ctx=None):
        z = x if ctx is None else x + ctx
        return x + self.glu(self.ff(z))

class VariableSelection(nn.Module):
    """Variable selection network"""
    def __init__(self, num_vars, d):
        super().__init__()
        self.proj = nn.ModuleList([nn.Linear(1, d) for _ in range(num_vars)])
        self.attn = nn.Linear(d, 1)
        self.grn = GRN(d)
    
    def forward(self, x):
        feats = [p(x[..., i:i+1]) for i, p in enumerate(self.proj)]
        S = torch.stack(feats, 2)
        w = torch.softmax(self.attn(torch.tanh(S)).squeeze(-1), -1)
        h = (S * w.unsqueeze(-1)).sum(2)
        return self.grn(h), w

class AttentionPooling(nn.Module):
    """Attention-based pooling"""
    def __init__(self, d):
        super().__init__()
        self.q = nn.Linear(d, d)
        self.k = nn.Linear(d, d)
        self.v = nn.Linear(d, d)
    
    def forward(self, x):
        # x: [B, T, D]
        q = self.q(x.mean(1, True))  # [B, 1, D]
        k = self.k(x)  # [B, T, D]
        v = self.v(x)  # [B, T, D]
        
        # Attention scores
        scores = torch.matmul(q, k.transpose(1, 2)) / (x.size(-1) ** 0.5)  # [B, 1, T]
        a = torch.softmax(scores, -1)
        
        # Weighted sum
        out = torch.matmul(a, v)  # [B, 1, D]
        return out.squeeze(1)  # [B, D]

class TCNBlock(nn.Module):
    """Temporal Convolutional Network block with proper padding"""
    def __init__(self, c, k=5, d=1, dropout=0.1):
        super().__init__()
        self.dilation = d
        self.kernel_size = k
        # Calculate padding to maintain sequence length
        self.padding = (k - 1) * d
        
        self.net = nn.Sequential(
            nn.Conv1d(c, c, k, padding=0, dilation=d),  # No padding, we'll handle manually
            nn.GELU(),
            nn.Conv1d(c, c, 1),
            nn.Dropout(dropout),
            nn.BatchNorm1d(c),
        )
    
    def forward(self, x):  # x: [B, C, T]
        # Apply manual padding to maintain sequence length
        x_padded = F.pad(x, (self.padding, 0))  # Pad left side only (causal)
        y = self.net(x_padded)
        
        # Ensure output length matches input length
        if y.size(-1) != x.size(-1):
            y = y[..., :x.size(-1)]
        
        return x + y

class TCNStack(nn.Module):
    """Stack of TCN blocks with exponentially increasing dilation"""
    def __init__(self, in_ch, hidden, layers=6, k=5, base_d=1, dropout=0.1):
        super().__init__()
        self.inp = nn.Conv1d(in_ch, hidden, 1)
        self.blocks = nn.Sequential(*[
            TCNBlock(hidden, k, base_d * (2 ** i), dropout) 
            for i in range(layers)
        ])
        self.out = nn.Conv1d(hidden, hidden, 1)
    
    def forward(self, x):
        # x: [B, T, F] -> [B, F, T] for conv1d
        z = self.inp(x.transpose(1, 2))
        z = self.blocks(z)
        z = self.out(z)
        # Back to [B, T, F]
        return z.transpose(1, 2)

class SinePositionalEncoding(nn.Module):
    """Sinusoidal positional encoding"""
    def __init__(self, d_model, max_len=4096):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32) * 
            (-np.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div)
        pe[:, 1::2] = torch.cos(position * div)
        self.register_buffer('pe', pe)
    
    def forward(self, x):
        T = x.size(1)
        return x + self.pe[:T].unsqueeze(0)

# ====== Main Model Classes ======

class PriceTransformer(nn.Module):
    """Transformer-based price prediction model"""
    def __init__(self, input_size, d_model, n_heads, num_layers, num_classes, 
                 num_regression_outputs=1, out_steps=1, dropout=0.2, use_stem=True, 
                 use_vsn=False, stem_ch=128):
        super().__init__()
        # Handle both parameter names for compatibility
        out_steps = out_steps or num_regression_outputs or 1
        
        self.use_stem = use_stem
        self.use_vsn = use_vsn
        
        if use_stem:
            self.stem = ConvStem1D(input_size, stem_ch)
        else:
            self.stem = nn.Identity()
        
        if use_vsn:
            vsn_input = stem_ch if use_stem else input_size
            self.vsn = VariableSelection(vsn_input, d_model)
        else:
            self.vsn = nn.Identity()
        
        # Determine encoder input size
        if use_vsn:
            enc_in = d_model
        elif use_stem:
            enc_in = stem_ch
        else:
            enc_in = input_size
        
        self.inp = nn.Linear(enc_in, d_model)
        self.norm_in = nn.LayerNorm(d_model)
        self.pos = SinePositionalEncoding(d_model)
        
        # Transformer encoder
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            batch_first=True,
            activation='gelu',
            norm_first=True
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=num_layers)
        self.norm = nn.LayerNorm(d_model)
        self.pool = AttentionPooling(d_model)
        
        # Output heads
        hidden = d_model
        self.reg_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),
            nn.Linear(hidden // 2, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, out_steps)
        )
        
        self.cls_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),
            nn.Linear(hidden // 2, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, num_classes)
        )
        
        self.unc_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Linear(hidden // 2, out_steps)
        )
        
        self.conf_head = nn.Sequential(
            nn.Linear(hidden, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, 1),
            nn.Sigmoid()
        )
        
        # Quantile heads
        self.q10 = nn.Linear(hidden, 1)
        self.q50 = nn.Linear(hidden, 1)
        self.q90 = nn.Linear(hidden, 1)
    
    def forward(self, x):
        # Stem processing
        z = self.stem(x) if self.use_stem else x
        
        # Variable selection
        if isinstance(self.vsn, VariableSelection):
            z, _ = self.vsn(z)
        
        # Transformer processing
        z = self.inp(z)
        z = self.norm_in(z)
        z = self.pos(z)
        z = self.enc(z)
        z = self.norm(z)
        
        # Pooling and predictions
        h = self.pool(z)
        
        reg = self.reg_head(h)
        cls = self.cls_head(h)
        unc = torch.exp(self.unc_head(h))  # Ensure positive uncertainty
        conf = self.conf_head(h)
        
        q10 = self.q10(h)
        q50 = self.q50(h)
        q90 = self.q90(h)
        
        return reg, cls, unc, conf, (q10, q50, q90)

class AttentionLSTM(nn.Module):
    """LSTM with attention mechanism"""
    def __init__(self, input_size, hidden_size, num_layers, num_classes, 
                 num_regression_outputs=1, out_steps=1, dropout=0.2, use_stem=True, 
                 stem_ch=128):
        super().__init__()
        # Handle both parameter names for compatibility
        out_steps = out_steps or num_regression_outputs or 1
        
        self.use_stem = use_stem
        
        if use_stem:
            self.stem = ConvStem1D(input_size, stem_ch)
            lstm_in = stem_ch
        else:
            self.stem = nn.Identity()
            lstm_in = input_size
        
        self.lstm = nn.LSTM(
            lstm_in, hidden_size, 
            num_layers=num_layers, 
            batch_first=True, 
            dropout=dropout if num_layers > 1 else 0
        )
        
        self.mha = nn.MultiheadAttention(
            embed_dim=hidden_size, 
            num_heads=4, 
            batch_first=True
        )
        
        self.pool = AttentionPooling(hidden_size)
        
        # Output heads
        hidden = hidden_size
        self.reg_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),
            nn.Linear(hidden // 2, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, out_steps)
        )
        
        self.cls_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),
            nn.Linear(hidden // 2, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, num_classes)
        )
        
        self.unc_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Linear(hidden // 2, out_steps)
        )
        
        self.conf_head = nn.Sequential(
            nn.Linear(hidden, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, 1),
            nn.Sigmoid()
        )
        
        # Quantile heads
        self.q10 = nn.Linear(hidden, 1)
        self.q50 = nn.Linear(hidden, 1)
        self.q90 = nn.Linear(hidden, 1)
    
    def forward(self, x):
        z = self.stem(x) if self.use_stem else x
        z, _ = self.lstm(z)
        z, _ = self.mha(z, z, z)
        h = self.pool(z)
        
        reg = self.reg_head(h)
        cls = self.cls_head(h)
        unc = torch.exp(self.unc_head(h))
        conf = self.conf_head(h)
        
        q10 = self.q10(h)
        q50 = self.q50(h)
        q90 = self.q90(h)
        
        return reg, cls, unc, conf, (q10, q50, q90)

class TCNExpert(nn.Module):
    """Temporal Convolutional Network expert"""
    def __init__(self, input_size, hidden_size, num_layers, num_classes, 
                 num_regression_outputs=1, out_steps=1, dropout=0.1, use_stem=True, 
                 stem_ch=128):
        super().__init__()
        # Handle both parameter names for compatibility
        out_steps = out_steps or num_regression_outputs or 1
        
        self.use_stem = use_stem
        
        if use_stem:
            self.stem = ConvStem1D(input_size, stem_ch)
            tcn_in = stem_ch
        else:
            self.stem = nn.Identity()
            tcn_in = input_size
        
        self.tcn = TCNStack(
            tcn_in, hidden_size, 
            layers=num_layers, 
            k=5, base_d=1, 
            dropout=dropout
        )
        
        self.pool = AttentionPooling(hidden_size)
        
        # Output heads
        hidden = hidden_size
        self.reg_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),
            nn.Linear(hidden // 2, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, out_steps)
        )
        
        self.cls_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),
            nn.Linear(hidden // 2, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, num_classes)
        )
        
        self.unc_head = nn.Sequential(
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Linear(hidden // 2, out_steps)
        )
        
        self.conf_head = nn.Sequential(
            nn.Linear(hidden, hidden // 4),
            nn.GELU(),
            nn.Linear(hidden // 4, 1),
            nn.Sigmoid()
        )
        
        # Quantile heads
        self.q10 = nn.Linear(hidden, 1)
        self.q50 = nn.Linear(hidden, 1)
        self.q90 = nn.Linear(hidden, 1)
    
    def forward(self, x):
        z = self.stem(x) if self.use_stem else x
        z = self.tcn(z)
        h = self.pool(z)
        
        reg = self.reg_head(h)
        cls = self.cls_head(h)
        unc = torch.exp(self.unc_head(h))
        conf = self.conf_head(h)
        
        q10 = self.q10(h)
        q50 = self.q50(h)
        q90 = self.q90(h)
        
        return reg, cls, unc, conf, (q10, q50, q90)

# ====== Training Utilities ======

def pinball_loss(pred, target, q):
    """Quantile loss function"""
    e = target - pred
    return torch.maximum(q * e, (q - 1) * e).mean()

class TempScaler(nn.Module):
    """Temperature scaling for calibration"""
    def __init__(self):
        super().__init__()
        self.t = nn.Parameter(torch.ones(()))
    
    def forward(self, logits):
        return logits / self.t.clamp_min(1e-3)

class SeqDataset(Dataset):
    """Sequential dataset for time series"""
    def __init__(self, X, y_reg, y_cls, seq_len=128):
        self.X = np.asarray(X, np.float32)
        self.y_reg = np.asarray(y_reg, np.float32)
        self.y_cls = np.asarray(y_cls, np.int64)
        self.T = int(seq_len)
    
    def __len__(self):
        return max(0, len(self.X) - self.T)
    
    def __getitem__(self, i):
        x = self.X[i:i + self.T]
        r = self.y_reg[i + self.T - 1]
        c = int(self.y_cls[i + self.T - 1])
        
        return (
            torch.from_numpy(x).float(),
            torch.from_numpy(r).float(),
            torch.tensor(c, dtype=torch.long)
        )

def build_targets(df, horizon=1):
    """Build regression and classification targets"""
    ret = df["ret1"].shift(-horizon).fillna(0.0).values.astype(np.float32)
    atr = df["atr14"].values.astype(np.float32)
    
    # Normalized returns as regression target
    y_reg = (ret / (atr + 1e-12)).reshape(-1, 1)
    
    # Classification targets: down=0, neutral=1, up=2
    thr = 0.0
    y_cls = np.zeros_like(ret, dtype=np.int64)
    y_cls[ret > thr] = 2
    y_cls[ret < -thr] = 0
    y_cls[(ret >= -thr) & (ret <= thr)] = 1
    
    return y_reg, y_cls

def make_model(model_type, input_features, hidden_size, num_layers, num_classes, out_steps, device):
    """Factory function to create models"""
    mt = model_type.lower()
    
    if mt == "lstm":
        return AttentionLSTM(
            input_features, hidden_size, num_layers, num_classes, out_steps
        ).to(device)
    elif mt == "transformer":
        return PriceTransformer(
            input_features, hidden_size, 8, num_layers, num_classes, out_steps
        ).to(device)
    elif mt == "tcn":
        return TCNExpert(
            input_features, hidden_size, num_layers, num_classes, out_steps
        ).to(device)
    else:
        raise ValueError(f"Unknown model_type: {model_type}")

def train_one(model, train_loader, val_loader, device, epochs=5, lr=1e-3, 
              cls_w=0.5, qloss_w=0.3, log_every=1):
    """Train a single model"""
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    ce = nn.CrossEntropyLoss()
    
    best = {"val": 1e9, "state": None}
    
    for ep in range(1, epochs + 1):
        # Training
        model.train()
        tr_loss = 0.0
        tr_n = 0
        
        for xb, yr, yc in train_loader:
            xb, yr, yc = xb.to(device), yr.to(device), yc.to(device)
            
            reg, cls, unc, conf, (q10, q50, q90) = model(xb)
            
            # Loss components
            loss_reg = ((reg - yr).pow(2)).mean()
            loss_cls = ce(cls, yc)
            loss_q = (
                pinball_loss(q10, yr, 0.1) + 
                pinball_loss(q50, yr, 0.5) + 
                pinball_loss(q90, yr, 0.9)
            )
            
            loss = loss_reg + cls_w * loss_cls + qloss_w * loss_q
            
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            
            tr_loss += loss.item()
            tr_n += 1
        
        # Validation
        model.eval()
        va_loss = 0.0
        va_n = 0
        
        with torch.no_grad():
            for xb, yr, yc in val_loader:
                xb, yr, yc = xb.to(device), yr.to(device), yc.to(device)
                
                reg, cls, unc, conf, (q10, q50, q90) = model(xb)
                
                loss_reg = ((reg - yr).pow(2)).mean()
                loss_cls = ce(cls, yc)
                loss_q = (
                    pinball_loss(q10, yr, 0.1) + 
                    pinball_loss(q50, yr, 0.5) + 
                    pinball_loss(q90, yr, 0.9)
                )
                
                loss = loss_reg + cls_w * loss_cls + qloss_w * loss_q
                
                va_loss += loss.item()
                va_n += 1
        
        tr_avg = tr_loss / max(1, tr_n)
        va_avg = va_loss / max(1, va_n)
        
        if ep % log_every == 0:
            print(f"[epoch {ep:03d}] train={tr_avg:.5f}  val={va_avg:.5f}")
        
        if va_avg < best["val"]:
            best = {"val": va_avg, "state": model.state_dict().copy()}
    
    # Load best weights
    model.load_state_dict(best["state"])
    return model

def calibrate_temperature(model, val_loader, device):
    """Calibrate model temperature for better probability estimates"""
    scaler = TempScaler().to(device)
    opt = torch.optim.LBFGS(scaler.parameters(), lr=0.1, max_iter=50)
    ce = nn.CrossEntropyLoss()
    
    def _eval():
        loss = 0.0
        n = 0
        for xb, _, yc in val_loader:
            xb, yc = xb.to(device), yc.to(device)
            
            with torch.no_grad():
                _, logits, _, _, _ = model(xb)
            
            scaled = scaler(logits)
            loss = loss + ce(scaled, yc)
            n += 1
        
        loss = loss / max(1, n)
        loss.backward()
        return loss
    
    opt.step(_eval)
    
    return {"temp": float(scaler.t.detach().cpu().item())}

def save_artifacts(out_dir, artifacts):
    """Save training artifacts"""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    
    if "models" in artifacts:
        for name, state in artifacts["models"].items():
            torch.save(state, out / f"{name}.pt")
    
    if "scaler" in artifacts:
        joblib.dump(artifacts["scaler"], out / "scaler.joblib")
    
    if "temps" in artifacts:
        with open(out / "temps.json", "w") as f:
            json.dump(artifacts["temps"], f, indent=2)
    
    if "model_card" in artifacts:
        with open(out / "model_card.json", "w") as f:
            json.dump(artifacts["model_card"], f, indent=2)

def main():
    """Main training function"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", required=True)
    ap.add_argument("--symbol", required=True)
    ap.add_argument("--file", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--seq_len", type=int, default=128)
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--hidden", type=int, default=256)
    ap.add_argument("--layers", type=int, default=2)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--val_ratio", type=float, default=0.2)
    ap.add_argument("--model_type", default=os.getenv("MODEL_TYPE", "lstm"))
    ap.add_argument("--log_every", type=int, default=1)
    args = ap.parse_args()
    
    # Load and process data
    file_dict = {args.symbol: args.file}
    merged = load_and_align_data(file_dict, args.data_root)
    df, feature_cols = build_features(merged, primary_symbol=args.symbol)
    
    # Prepare features and targets
    X = df[feature_cols].values.astype("float32")
    y_reg, y_cls = build_targets(df, 1)
    
    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X).astype("float32")
    
    # Train/validation split
    N = len(X_scaled)
    split = int(N * (1 - args.val_ratio))
    
    if split <= args.seq_len + 5:
        raise RuntimeError("Not enough data after split.")
    
    X_tr, X_va = X_scaled[:split], X_scaled[split:]
    r_tr, r_va = y_reg[:split], y_reg[split:]
    c_tr, c_va = y_cls[:split], y_cls[split:]
    
    # Create datasets
    ds_tr = SeqDataset(X_tr, r_tr, c_tr, args.seq_len)
    ds_va = SeqDataset(X_va, r_va, c_va, args.seq_len)
    
    if len(ds_tr) == 0 or len(ds_va) == 0:
        raise RuntimeError("Empty dataset after windowing.")
    
    dl_tr = DataLoader(ds_tr, batch_size=args.batch, shuffle=True, drop_last=True)
    dl_va = DataLoader(ds_va, batch_size=args.batch, shuffle=False)
    
    # Training setup
    device = "cuda" if torch.cuda.is_available() else "cpu"
    input_features = X_scaled.shape[1]
    num_classes = 3
    out_steps = 1
    
    models = {}
    temps = {}
    
    mt = args.model_type.lower()
    
    if mt in ("lstm", "transformer", "tcn"):
        # Train single model
        m = make_model(mt, input_features, args.hidden, args.layers, 
                      num_classes, out_steps, device)
        m = train_one(m, dl_tr, dl_va, device, epochs=args.epochs, 
                     log_every=args.log_every)
        temps[mt] = calibrate_temperature(m, dl_va, device)
        models[mt] = m.state_dict()
        
    elif mt == "moe":
        # Train ensemble of experts
        for expert in ("lstm", "transformer", "tcn"):
            print(f"\nTraining {expert} expert...")
            m = make_model(expert, input_features, args.hidden, args.layers, 
                          num_classes, out_steps, device)
            m = train_one(m, dl_tr, dl_va, device, epochs=args.epochs, 
                         log_every=args.log_every)
            temps[expert] = calibrate_temperature(m, dl_va, device)
            models[expert] = m.state_dict()
    
    else:
        raise ValueError("MODEL_TYPE must be one of lstm/transformer/tcn/moe")
    
    # Save artifacts
    model_card = {
        "created": datetime.utcnow().isoformat() + "Z",
        "symbol": args.symbol,
        "feature_count": int(input_features),
        "seq_len": int(args.seq_len),
        "model_type": args.model_type,
        "experts": list(models.keys()),
        "feature_cols": feature_cols,
        "notes": "Enhanced training build with fixed compatibility."
    }
    
    save_artifacts(args.out_dir, {
        "models": models,
        "scaler": scaler,
        "temps": temps,
        "model_card": model_card
    })
    
    print(f"\nTraining completed. Artifacts saved to {args.out_dir}")

if __name__ == "__main__":
    main()
