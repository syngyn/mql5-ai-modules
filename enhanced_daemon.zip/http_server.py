#!/usr/bin/env python3
# http_server.py — v1.2.0 (fixed compatibility issues)

import os, json, inspect
from typing import Dict, List, Any, Optional
from pathlib import Path

import numpy as np
import joblib
import torch
from torch import nn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# ---------- Resolve MODEL_DIR ----------
MODEL_DIR = Path(os.environ.get("MODEL_DIR", "./models"))
if not MODEL_DIR.exists():
    raise RuntimeError(f"MODEL_DIR not found: {MODEL_DIR.resolve()}")

# ---------- Load model_card ----------
card_path = MODEL_DIR / "model_card.json"
if not card_path.exists():
    raise RuntimeError(f"model_card.json not found in {MODEL_DIR.resolve()}")
with open(card_path, "r") as f:
    MODEL_CARD = json.load(f)

FEATURE_COLS: List[str] = MODEL_CARD.get("feature_cols", [])
SEQ_LEN: int = int(MODEL_CARD.get("seq_len", 128))
MODEL_TYPE = MODEL_CARD.get("model_type", "moe")

# ---------- Import model classes (with proper fallback) ----------
try:
    from enhanced_train_model import AttentionLSTM, PriceTransformer, TCNExpert  # type: ignore
    print("[INFO] Using enhanced_train_model")
except ImportError:
    try:
        from enhanced_train_model_verbose import AttentionLSTM, PriceTransformer, TCNExpert  # type: ignore
        print("[INFO] Using enhanced_train_model_verbose")
    except ImportError:
        raise ImportError("Could not import model classes from either enhanced_train_model or enhanced_train_model_verbose")

# ---------- Temperature scaler (for logits calibration) ----------
class TempScaler(nn.Module):
    def __init__(self, t: float = 1.0):
        super().__init__()
        self.t = nn.Parameter(torch.tensor([t], dtype=torch.float32))
    
    def forward(self, logits):  # type: ignore
        return logits / self.t.clamp_min(1e-3)

# ---------- Constructor compatibility helpers ----------
def _get_constructor_params(ctor):
    """Get parameter names from constructor"""
    sig = inspect.signature(ctor)
    return set(sig.parameters.keys())

def _ctor_kwargs(ctor, base_kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Trim/rename kwargs to match the ctor signature (handles out_steps vs num_regression_outputs)."""
    params = _get_constructor_params(ctor)
    kw = dict(base_kwargs)

    # Handle regression head arg name differences for Transformer/TCN
    if "num_regression_outputs" in params and "out_steps" in kw:
        kw["num_regression_outputs"] = kw.pop("out_steps")
    elif "out_steps" in params and "num_regression_outputs" in kw:
        kw["out_steps"] = kw.pop("num_regression_outputs")

    # Drop any kwarg the ctor doesn't accept
    for k in list(kw.keys()):
        if k not in params:
            kw.pop(k)
    
    return kw

def _load_expert(name: str, input_features: int, hidden=256, layers=2, device="cpu") -> nn.Module:
    """Load and initialize an expert model"""
    name_l = name.lower()
    
    # Base parameters for all models
    base_params = {
        "input_size": input_features,
        "hidden_size": hidden,
        "num_layers": layers,
        "num_classes": 3,
        "out_steps": 1,
        "num_regression_outputs": 1  # Alternative parameter name
    }
    
    # Model-specific parameters
    if name_l == "lstm":
        ctor = AttentionLSTM
    elif name_l == "transformer":
        base_params.update({
            "d_model": hidden,
            "n_heads": 8
        })
        ctor = PriceTransformer
    elif name_l == "tcn":
        ctor = TCNExpert
    else:
        raise ValueError(f"Unknown expert: {name}")

    # Filter parameters to match constructor signature
    kwargs = _ctor_kwargs(ctor, base_params)
    
    try:
        m = ctor(**kwargs)
    except Exception as e:
        print(f"[ERROR] Failed to instantiate {name} with kwargs: {kwargs}")
        print(f"[ERROR] Constructor parameters: {_get_constructor_params(ctor)}")
        raise e

    # Load weights
    ckpt = MODEL_DIR / f"{name_l}.pt"
    if not ckpt.exists():
        raise RuntimeError(f"Missing model file: {ckpt.resolve()}")
    
    try:
        state = torch.load(ckpt, map_location="cpu")
        m.load_state_dict(state, strict=False)
        print(f"[INFO] Loaded weights for {name}")
    except Exception as e:
        print(f"[ERROR] Failed to load weights for {name}: {e}")
        raise
    
    m.eval()
    return m.to(device)

# ---------- Load scaler ----------
scaler_path = MODEL_DIR / "scaler.joblib"
if not scaler_path.exists():
    raise RuntimeError(f"scaler.joblib not found in {MODEL_DIR.resolve()}")
scaler = joblib.load(scaler_path)

# ---------- Load temperature(s) ----------
temps: Dict[str, TempScaler] = {}
temps_json = MODEL_DIR / "temps.json"
if temps_json.ex