# quick_test.py - Simple test to verify installation works
import sys

def test_package(package_name, display_name):
    """Test if a package can be imported"""
    try:
        module = __import__(package_name)
        version = getattr(module, '__version__', 'Unknown')
        print(f"[OK] {display_name}: {version}")
        return True
    except ImportError as e:
        print(f"[ERROR] {display_name}: {e}")
        return False

def main():
    print("Neural Network EA - Installation Test")
    print("=" * 45)
    print(f"Python version: {sys.version}")
    print("-" * 45)
    
    # Test essential packages
    packages = [
        ("tensorflow", "TensorFlow"),
        ("numpy", "NumPy"),
        ("pandas", "Pandas"), 
        ("sklearn", "Scikit-learn"),
        ("flask", "Flask"),
        ("MetaTrader5", "MetaTrader5"),
        ("ta", "Technical Analysis"),
        ("matplotlib", "Matplotlib")
    ]
    
    success_count = 0
    for package, name in packages:
        if test_package(package, name):
            success_count += 1
    
    print("-" * 45)
    
    # Test TensorFlow functionality
    try:
        import tensorflow as tf
        x = tf.constant([1, 2, 3])
        y = tf.constant([4, 5, 6])
        z = tf.add(x, y)
        print(f"[OK] TensorFlow operations: {z.numpy()}")
        success_count += 1
    except Exception as e:
        print(f"[ERROR] TensorFlow operations: {e}")
    
    print("-" * 45)
    print(f"Results: {success_count}/{len(packages)+1} components working")
    
    if success_count >= len(packages):
        print("[SUCCESS] Installation is working correctly!")
        print("\nNext steps:")
        print("1. python train_models.py --synthetic")
        print("2. python neural_api_service.py")
        return True
    else:
        print("[WARNING] Some components failed")
        print("Try reinstalling failed packages individually")
        return False

if __name__ == "__main__":
    main()
