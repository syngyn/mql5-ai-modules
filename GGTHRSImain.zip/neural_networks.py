# neural_networks.py - WORKING VERSION without TA library issues
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from sklearn.preprocessing import MinMaxScaler, RobustScaler
import joblib
import warnings
warnings.filterwarnings('ignore')

class ForexDataPreprocessor:
    """Handles data preprocessing and feature engineering for forex prediction"""
    
    def __init__(self):
        self.price_scaler = MinMaxScaler()
        self.feature_scaler = RobustScaler()
        self.lookback_window = 60
        
    def create_technical_features(self, df):
        """Create comprehensive technical analysis features - WORKING VERSION"""
        print("Creating technical indicators...")
        
        # Price-based features
        df['returns'] = df['close'].pct_change()
        df['log_returns'] = np.log(df['close'] / df['close'].shift(1)).fillna(0)
        
        # Simple moving averages
        df['sma_5'] = df['close'].rolling(window=5).mean()
        df['sma_20'] = df['close'].rolling(window=20).mean()
        df['sma_50'] = df['close'].rolling(window=50).mean()
        
        # Exponential moving averages
        df['ema_12'] = df['close'].ewm(span=12).mean()
        df['ema_26'] = df['close'].ewm(span=26).mean()
        
        # RSI calculation (manual - NO TA library)
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / (loss + 1e-8)  # Add small value to avoid division by zero
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # MACD (manual - NO TA library)
        df['macd'] = df['ema_12'] - df['ema_26']
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        # Bollinger Bands (manual - NO TA library)
        bb_period = 20
        bb_std = 2
        bb_ma = df['close'].rolling(window=bb_period).mean()
        bb_std_dev = df['close'].rolling(window=bb_period).std()
        df['bb_high'] = bb_ma + (bb_std_dev * bb_std)
        df['bb_low'] = bb_ma - (bb_std_dev * bb_std)
        df['bb_mid'] = bb_ma
        df['bb_width'] = (df['bb_high'] - df['bb_low']) / (df['bb_mid'] + 1e-8)
        df['bb_position'] = (df['close'] - df['bb_low']) / (df['bb_high'] - df['bb_low'] + 1e-8)
        
        # Average True Range (manual - NO TA library)
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        true_range = np.maximum(high_low, np.maximum(high_close, low_close))
        df['atr'] = true_range.rolling(window=14).mean()
        
        # Volatility
        df['volatility'] = df['returns'].rolling(window=20).std()
        
        # Volume indicators (manual - NO TA library)
        if 'volume' in df.columns and not df['volume'].isna().all():
            df['volume_sma'] = df['volume'].rolling(window=20).mean()
            df['volume_ratio'] = df['volume'] / (df['volume_sma'] + 1)
        else:
            df['volume_sma'] = 1000
            df['volume_ratio'] = 1.0
        
        # Time-based features
        try:
            if hasattr(df.index, 'hour'):
                df['hour'] = df.index.hour
                df['day_of_week'] = df.index.dayofweek
                df['day_of_month'] = df.index.day
            else:
                time_index = pd.to_datetime(df.index)
                df['hour'] = time_index.hour
                df['day_of_week'] = time_index.dayofweek
                df['day_of_month'] = time_index.day
        except:
            df['hour'] = 12
            df['day_of_week'] = 1
            df['day_of_month'] = 15
        
        # Cyclical encoding
        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['dow_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['dow_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        
        # Support and resistance levels
        df['resistance'] = df['high'].rolling(window=20).max()
        df['support'] = df['low'].rolling(window=20).min()
        range_val = df['resistance'] - df['support'] + 1e-8
        df['price_position'] = (df['close'] - df['support']) / range_val
        
        # Additional indicators
        df['price_change'] = df['close'] - df['open']
        df['price_change_pct'] = df['price_change'] / (df['open'] + 1e-8)
        df['high_low_pct'] = (df['high'] - df['low']) / (df['close'] + 1e-8)
        df['momentum'] = df['close'] / df['close'].shift(10) - 1
        df['rate_of_change'] = df['close'].pct_change(periods=10)
        
        print(f"Created {len([c for c in df.columns if c not in ['open', 'high', 'low', 'close', 'volume']])} technical indicators")
        return df
    
    def prepare_sequences(self, df, target_columns=['close'], sequence_length=60):
        """Prepare sequential data for neural networks"""
        print("Preparing sequential data...")
        
        # Select numeric columns only
        numeric_df = df.select_dtypes(include=[np.number])
        feature_cols = [col for col in numeric_df.columns if col not in target_columns]
        
        print(f"Using {len(feature_cols)} features")
        
        # Handle missing values
        numeric_df = numeric_df.fillna(method='ffill').fillna(method='bfill').fillna(0)
        
        # Scale features
        features_scaled = self.feature_scaler.fit_transform(numeric_df[feature_cols])
        targets_scaled = self.price_scaler.fit_transform(numeric_df[target_columns])
        
        # Create sequences
        X, y = [], []
        for i in range(sequence_length, len(features_scaled)):
            X.append(features_scaled[i-sequence_length:i])
            y.append(targets_scaled[i])
        
        return np.array(X), np.array(y), feature_cols
    
    def create_candlestick_images(self, df, image_size=(64, 64), sequence_length=60):
        """Convert OHLC data to candlestick chart images for CNN"""
        print("Creating candlestick images...")
        images = []
        
        for i in range(sequence_length, len(df)):
            seq_data = df.iloc[i-sequence_length:i]
            
            # Normalize prices
            price_min = seq_data[['high', 'low']].min().min()
            price_max = seq_data[['high', 'low']].max().max()
            price_range = price_max - price_min
            
            if price_range == 0:
                price_range = 1
            
            normalized_high = (seq_data['high'] - price_min) / price_range
            normalized_low = (seq_data['low'] - price_min) / price_range
            normalized_open = (seq_data['open'] - price_min) / price_range
            normalized_close = (seq_data['close'] - price_min) / price_range
            
            # Create image
            image = np.zeros(image_size)
            
            for j, (o, h, l, c) in enumerate(zip(normalized_open, normalized_high, 
                                               normalized_low, normalized_close)):
                if j >= sequence_length:
                    continue
                    
                x = min(int(j * image_size[1] / sequence_length), image_size[1]-1)
                
                body_top = min(int(max(o, c) * image_size[0]), image_size[0]-1)
                body_bottom = max(int(min(o, c) * image_size[0]), 0)
                wick_top = min(int(h * image_size[0]), image_size[0]-1)
                wick_bottom = max(int(l * image_size[0]), 0)
                
                try:
                    if c > o:  # Bullish
                        image[body_bottom:body_top+1, x] = 0.8
                    else:  # Bearish
                        image[body_bottom:body_top+1, x] = 0.3
                    
                    image[wick_bottom:wick_top+1, x] = 0.5
                except:
                    pass
                
            images.append(image)
        
        return np.array(images).reshape(-1, image_size[0], image_size[1], 1)

class SimplePredictor:
    """Simplified neural network predictor"""
    
    def __init__(self, input_shape, output_dim=1, model_type='lstm'):
        self.input_shape = input_shape
        self.output_dim = output_dim
        self.model_type = model_type
        self.model = None
        
    def build_model(self):
        """Build neural network model"""
        inputs = Input(shape=self.input_shape)
        
        if self.model_type == 'lstm':
            x = LSTM(64, return_sequences=True, dropout=0.2)(inputs)
            x = LSTM(32, dropout=0.2)(x)
        elif self.model_type == 'cnn' and len(self.input_shape) == 3:
            x = Conv2D(32, (3, 3), activation='relu', padding='same')(inputs)
            x = MaxPooling2D((2, 2))(x)
            x = Conv2D(64, (3, 3), activation='relu', padding='same')(x)
            x = GlobalAveragePooling2D()(x)
        else:
            x = Flatten()(inputs) if len(self.input_shape) > 1 else inputs
            x = Dense(128, activation='relu')(x)
            x = Dropout(0.2)(x)
            x = Dense(64, activation='relu')(x)
        
        x = Dense(32, activation='relu')(x)
        x = Dropout(0.2)(x)
        outputs = Dense(self.output_dim, activation='linear')(x)
        
        self.model = Model(inputs=inputs, outputs=outputs)
        self.model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']
        )
        
        return self.model
    
    def train(self, X_train, y_train, X_val, y_val, epochs=30):
        """Train the model"""
        callbacks = [
            EarlyStopping(patience=8, restore_best_weights=True),
            ReduceLROnPlateau(patience=4, factor=0.5, min_lr=1e-6)
        ]
        
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=32,
            callbacks=callbacks,
            verbose=1
        )
        
        return history
    
    def predict(self, X):
        """Make predictions"""
        return self.model.predict(X, verbose=0)

class EnsemblePredictor:
    """Simple ensemble of neural networks"""
    
    def __init__(self):
        self.lstm_model = None
        self.cnn_model = None
        self.weights = np.array([0.6, 0.4])
        
    def train_ensemble(self, X_seq, X_img, y, test_size=0.2):
        """Train ensemble models"""
        print("Training ensemble models...")
        
        # Split data
        split_idx = int(len(X_seq) * (1 - test_size))
        
        X_seq_train, X_seq_val = X_seq[:split_idx], X_seq[split_idx:]
        X_img_train, X_img_val = X_img[:split_idx], X_img[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        print(f"Training data: {len(X_seq_train)}, Validation: {len(X_seq_val)}")
        
        # Train LSTM
        print("Training LSTM model...")
        self.lstm_model = SimplePredictor(X_seq.shape[1:], model_type='lstm')
        self.lstm_model.build_model()
        self.lstm_model.train(X_seq_train, y_train, X_seq_val, y_val, epochs=20)
        
        # Train CNN
        print("Training CNN model...")
        self.cnn_model = SimplePredictor(X_img.shape[1:], model_type='cnn')
        self.cnn_model.build_model()
        self.cnn_model.train(X_img_train, y_train, X_img_val, y_val, epochs=20)
        
        print("Ensemble training completed!")
        return self
    
    def predict_with_confidence(self, X_seq, X_img):
        """Make ensemble predictions with confidence scores"""
        lstm_pred = self.lstm_model.predict(X_seq)
        cnn_pred = self.cnn_model.predict(X_img)
        
        ensemble_pred = (self.weights[0] * lstm_pred + self.weights[1] * cnn_pred)
        
        confidences = []
        for i in range(len(ensemble_pred)):
            pred_diff = abs(lstm_pred[i][0] - cnn_pred[i][0])
            pred_avg = abs(ensemble_pred[i][0])
            confidence = max(0.1, 1.0 - min(pred_diff / (pred_avg + 1e-8), 0.9))
            confidences.append(confidence)
        
        return ensemble_pred, np.array(confidences)
    
    def save_models(self, base_path="models/"):
        """Save trained models"""
        import os
        os.makedirs(base_path, exist_ok=True)
        
        try:
            if self.lstm_model and self.lstm_model.model:
                self.lstm_model.model.save(f"{base_path}lstm_model.h5")
                print(f"[OK] LSTM saved to {base_path}lstm_model.h5")
            
            if self.cnn_model and self.cnn_model.model:
                self.cnn_model.model.save(f"{base_path}cnn_model.h5")
                print(f"[OK] CNN saved to {base_path}cnn_model.h5")
            
            np.save(f"{base_path}ensemble_weights.npy", self.weights)
            print(f"[OK] Weights saved")
            
        except Exception as e:
            print(f"[ERROR] Failed to save: {e}")
    
    def load_models(self, base_path="models/"):
        """Load pre-trained models"""
        try:
            from tensorflow.keras.models import load_model
            
            lstm_path = f"{base_path}lstm_model.h5"
            cnn_path = f"{base_path}cnn_model.h5"
            
            if os.path.exists(lstm_path) and os.path.exists(cnn_path):
                self.lstm_model = SimplePredictor((60, 20), model_type='lstm')
                self.lstm_model.model = load_model(lstm_path)
                
                self.cnn_model = SimplePredictor((64, 64, 1), model_type='cnn')
                self.cnn_model.model = load_model(cnn_path)
                
                weights_path = f"{base_path}ensemble_weights.npy"
                if os.path.exists(weights_path):
                    self.weights = np.load(weights_path)
                
                return True
            return False
        except Exception as e:
            print(f"[ERROR] Load failed: {e}")
            return False
