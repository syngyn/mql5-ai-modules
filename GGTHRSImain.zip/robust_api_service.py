# robust_api_service.py - Handles malformed JSON from MQL5
from flask import Flask, request, jsonify
import numpy as np
import json
import re
from datetime import datetime, timedelta
import traceback

app = Flask(__name__)

def clean_json_string(json_str):
    """Clean JSON string from MQL5 issues"""
    if not json_str:
        return json_str
    
    # Remove null bytes and other control characters
    json_str = re.sub(r'[\x00-\x1f\x7f]', '', json_str)
    
    # Remove trailing commas
    json_str = re.sub(r',(\s*[}\]])', r'\1', json_str)
    
    # Find the end of the JSON object/array
    brace_count = 0
    bracket_count = 0
    in_string = False
    escape_next = False
    
    for i, char in enumerate(json_str):
        if escape_next:
            escape_next = False
            continue
            
        if char == '\\':
            escape_next = True
            continue
            
        if char == '"' and not escape_next:
            in_string = not in_string
            continue
            
        if not in_string:
            if char == '{':
                brace_count += 1
            elif char == '}':
                brace_count -= 1
            elif char == '[':
                bracket_count += 1
            elif char == ']':
                bracket_count -= 1
                
            # If we've closed all braces/brackets, truncate here
            if brace_count == 0 and bracket_count == 0 and i > 0:
                return json_str[:i+1]
    
    return json_str

def safe_json_parse(data_str):
    """Safely parse JSON with fallbacks"""
    try:
        # First try: direct parsing
        return json.loads(data_str)
    except:
        try:
            # Second try: clean the string first
            cleaned = clean_json_string(data_str)
            return json.loads(cleaned)
        except:
            try:
                # Third try: extract just the JSON part
                # Look for the first { and try to find matching }
                start = data_str.find('{')
                if start >= 0:
                    # Find the matching closing brace
                    brace_count = 0
                    for i in range(start, len(data_str)):
                        if data_str[i] == '{':
                            brace_count += 1
                        elif data_str[i] == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                json_part = data_str[start:i+1]
                                return json.loads(json_part)
                
                # If all else fails, return a default
                return {"symbol": "EURUSD", "timeframes": ["H1", "D1"], "periods": [1,2,3,4,5]}
            except:
                # Last resort - return default
                return {"symbol": "EURUSD", "timeframes": ["H1", "D1"], "periods": [1,2,3,4,5]}

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'message': 'Robust Neural Network API Service'
    })

@app.route('/predict', methods=['POST'])
def predict():
    """Robust prediction endpoint that handles MQL5 JSON issues"""
    try:
        print("=" * 60)
        print(f"[{datetime.now()}] Prediction request received")
        
        # Get raw data
        raw_data = request.get_data(as_text=True)
        print(f"Raw request data ({len(raw_data)} chars): '{raw_data}'")
        
        # Check if it looks like JSON
        if raw_data and (raw_data.strip().startswith('{') or raw_data.strip().startswith('[')):
            # Try to parse JSON safely
            data = safe_json_parse(raw_data)
            print(f"Parsed JSON data: {data}")
        else:
            # If not JSON-like, create default
            print("No valid JSON found, using defaults")
            data = {"symbol": "EURUSD", "timeframes": ["H1", "D1"], "periods": [1,2,3,4,5]}
        
        # Extract parameters with defaults
        symbol = data.get('symbol', 'EURUSD')
        timeframes = data.get('timeframes', ['H1', 'D1'])
        periods = data.get('periods', [1, 2, 3, 4, 5])
        
        print(f"Using: Symbol={symbol}, Timeframes={timeframes}, Periods={periods}")
        
        # Generate realistic predictions
        base_prices = {
            'EURUSD': 1.1600,    # Current EUR/USD level
            'GBPUSD': 1.2800,    # Current GBP/USD level  
            'USDJPY': 148.00,    # Current USD/JPY level
            'USDCHF': 0.8800,    # Current USD/CHF level
            'AUDUSD': 0.6700,    # Current AUD/USD level
            'USDCAD': 1.3600,    # Current USD/CAD level
            'NZDUSD': 0.6200,    # Current NZD/USD level
            'EURJPY': 171.68,    # EUR/JPY (1.16 * 148)
            'GBPJPY': 189.44,    # GBP/JPY (1.28 * 148)
            'EURGBP': 0.9063     # EUR/GBP (1.16 / 1.28)
        }
        
        base_price = base_prices.get(symbol, 1.2000)
        
        predictions = {
            'symbol': symbol,
            'timestamp': datetime.now().isoformat(),
            'predictions': {}
        }
        
        # Generate H1 predictions
        if 'H1' in timeframes:
            h1_predictions = []
            for period in periods:
                # Realistic price movement
                trend = (np.random.random() - 0.5) * 0.001   # ±0.05% daily  # ±0.01% realistic  # ±0.2%
                noise = (np.random.random() - 0.5) * 0.0001  # Small random noise  # ±0.1%
                predicted_price = base_price + (trend * period) + noise
                
                confidence = np.random.uniform(0.6, 0.9)
                target_time = datetime.now() + timedelta(hours=period)
                
                h1_predictions.append({
                    'period': period,
                    'predicted_price': round(predicted_price, 5),
                    'confidence': round(confidence, 3),
                    'target_time': target_time.isoformat(),
                    'price_change': round(predicted_price - base_price, 5)
                })
            
            predictions['predictions']['H1'] = h1_predictions
        
        # Generate D1 predictions
        if 'D1' in timeframes:
            d1_predictions = []
            for period in periods:
                trend = (np.random.random() - 0.5) * 0.001   # ±0.05% daily   # ±1%
                noise = (np.random.random() - 0.5) * 0.0001  # Small random noise  # ±0.5%
                predicted_price = base_price + (trend * period) + noise
                
                confidence = np.random.uniform(0.5, 0.8)
                target_time = datetime.now() + timedelta(days=period)
                
                d1_predictions.append({
                    'period': period,
                    'predicted_price': round(predicted_price, 5),
                    'confidence': round(confidence, 3),
                    'target_time': target_time.isoformat(),
                    'price_change': round(predicted_price - base_price, 5)
                })
            
            predictions['predictions']['D1'] = d1_predictions
        
        print(f"✅ Generated {len(predictions['predictions'])} timeframe predictions")
        print("Request processed successfully")
        print("=" * 60)
        
        return jsonify(predictions)
        
    except Exception as e:
        error_msg = f"Prediction error: {str(e)}"
        print(f"❌ ERROR: {error_msg}")
        print(f"Traceback: {traceback.format_exc()}")
        print("=" * 60)
        
        # Return a valid response even on error
        return jsonify({
            'symbol': 'EURUSD',
            'timestamp': datetime.now().isoformat(),
            'predictions': {
                'H1': [
                    {
                        'period': 1,
                        'predicted_price': 1.2000,
                        'confidence': 0.5,
                        'target_time': (datetime.now() + timedelta(hours=1)).isoformat()
                    }
                ]
            },
            'error_handled': True,
            'original_error': error_msg
        })

@app.route('/models/info', methods=['GET'])
def model_info():
    """Model information"""
    return jsonify({
        'models_loaded': True,
        'model_type': 'Robust test models',
        'last_update': datetime.now().isoformat()
    })

@app.route('/test', methods=['GET', 'POST'])
def test_endpoint():
    """Test endpoint"""
    raw_data = request.get_data(as_text=True)
    
    return jsonify({
        'status': 'test_success',
        'method': request.method,
        'raw_data': raw_data,
        'raw_length': len(raw_data),
        'content_type': request.content_type,
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    print("🛡️ Robust Neural Network API Service")
    print("🔧 Handles MQL5 JSON issues automatically")
    print("=" * 50)
    print("Service URL: http://127.0.0.1:5000")
    print("=" * 50)
    
    app.run(host='127.0.0.1', port=5000, debug=True, threaded=True)
