# fix_dependencies.py - FIXED Script to resolve TensorFlow dependency conflicts
import subprocess
import sys
import os
import venv
from pathlib import Path

def run_command(command, description, ignore_error=False):
    """Run a command and handle errors"""
    print(f"🔧 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, 
                              capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        if result.stdout.strip():
            print(f"   Output: {result.stdout.strip()}")
        return True
    except subprocess.CalledProcessError as e:
        if ignore_error:
            print(f"⚠️  {description} had warnings (continuing)")
            if e.stdout:
                print(f"   Output: {e.stdout}")
            return True
        else:
            print(f"❌ {description} failed:")
            print(f"   Error: {e.stderr}")
            if e.stdout:
                print(f"   Output: {e.stdout}")
            return False

def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    if version.major == 3 and version.minor >= 8:
        print(f"✅ Python {version.major}.{version.minor}.{version.micro} is compatible")
        return True
    else:
        print(f"❌ Python {version.major}.{version.minor}.{version.micro} is too old")
        print("Please upgrade to Python 3.8 or higher")
        return False

def create_clean_environment():
    """Create a clean virtual environment"""
    print("🚀 Creating clean virtual environment for Neural Network EA...")
    
    # Remove existing environment if it exists
    env_path = Path("neural_forex_env")
    if env_path.exists():
        print("🗑️  Removing existing virtual environment...")
        import shutil
        try:
            shutil.rmtree(env_path)
            print("✅ Old environment removed")
        except PermissionError:
            print("⚠️  Some files couldn't be deleted, continuing...")
    
    # Create new virtual environment
    print("📁 Creating new virtual environment...")
    try:
        venv.create("neural_forex_env", with_pip=True)
        print("✅ Virtual environment created successfully")
    except Exception as e:
        print(f"❌ Failed to create virtual environment: {e}")
        return None, None, None
    
    # Get activation script path
    if os.name == 'nt':  # Windows
        activate_script = "neural_forex_env\\Scripts\\activate"
        pip_path = "neural_forex_env\\Scripts\\pip"
        python_path = "neural_forex_env\\Scripts\\python"
    else:  # Linux/Mac
        activate_script = "neural_forex_env/bin/activate"
        pip_path = "neural_forex_env/bin/pip"
        python_path = "neural_forex_env/bin/python"
    
    return activate_script, pip_path, python_path

def install_compatible_packages(pip_path, python_path):
    """Install packages with compatible versions"""
    
    # Upgrade pip first - FIXED for Windows
    print("🔄 Upgrading pip...")
    if os.name == 'nt':  # Windows - use python -m pip
        upgrade_command = f'"{python_path}" -m pip install --upgrade pip'
    else:  # Linux/Mac
        upgrade_command = f'"{pip_path}" install --upgrade pip'
    
    if not run_command(upgrade_command, "Upgrading pip", ignore_error=True):
        print("⚠️  Pip upgrade had issues, but continuing...")
    
    print("📦 Installing compatible packages in specific order...")
    
    # Install core packages first (in specific order to avoid conflicts)
    core_packages = [
        ("numpy==1.24.3", "NumPy (TensorFlow compatible)"),
        ("protobuf==4.25.1", "Protobuf (TensorFlow compatible)"), 
        ("typing-extensions==4.5.0", "Typing extensions (TensorFlow compatible)"),
        ("tensorflow==2.15.0", "TensorFlow 2.15 (stable version)"),
        ("keras==2.15.0", "Keras (matching TensorFlow version)"),
        ("tensorboard==2.15.2", "TensorBoard (matching TensorFlow version)")
    ]
    
    for package, description in core_packages:
        command = f'"{python_path}" -m pip install {package}'
        if not run_command(command, f"Installing {description}", ignore_error=True):
            print(f"⚠️  Failed to install {package}, trying alternative method...")
            # Try without version pinning
            base_package = package.split('==')[0]
            alt_command = f'"{python_path}" -m pip install "{base_package}"'
            run_command(alt_command, f"Installing {base_package} (any version)", ignore_error=True)
    
    # Install remaining packages
    remaining_packages = [
        ("scikit-learn==1.3.2", "Scikit-learn"),
        ("pandas==2.1.4", "Pandas"), 
        ("scipy==1.11.4", "SciPy"),
        ("flask==3.0.0", "Flask web framework"),
        ("flask-cors==4.0.0", "Flask CORS"),
        ("requests==2.31.0", "HTTP requests library"),
        ("MetaTrader5==5.0.45", "MetaTrader 5 integration"),
        ("ta==0.10.2", "Technical analysis library"),
        ("matplotlib==3.8.2", "Plotting library"),
        ("seaborn==0.13.0", "Statistical plotting"),
        ("schedule==1.2.0", "Job scheduling"),
        ("python-dateutil==2.8.2", "Date utilities"),
        ("pytz==2023.3", "Timezone handling"),
        ("joblib==1.3.2", "Parallel computing"),
        ("ujson==5.8.0", "Fast JSON processing"),
        ("python-dotenv==1.0.0", "Environment variables"),
        ("psutil==5.9.6", "System monitoring")
    ]
    
    for package, description in remaining_packages:
        command = f'"{python_path}" -m pip install {package}'
        if not run_command(command, f"Installing {description}", ignore_error=True):
            print(f"⚠️  Failed to install {package}, trying base package...")
            base_package = package.split('==')[0]
            alt_command = f'"{python_path}" -m pip install "{base_package}"'
            run_command(alt_command, f"Installing {base_package} (any version)", ignore_error=True)
    
    return True

def test_installation(python_path):
    """Test if the installation works correctly"""
    print("🧪 Testing installation...")
    
    test_script = '''
import sys
print(f"Python version: {sys.version}")
print("-" * 50)

packages_to_test = [
    ("tensorflow", "TensorFlow"),
    ("numpy", "NumPy"), 
    ("pandas", "Pandas"),
    ("sklearn", "Scikit-learn"),
    ("flask", "Flask"),
    ("MetaTrader5", "MetaTrader5"),
    ("ta", "Technical Analysis"),
    ("matplotlib", "Matplotlib")
]

success_count = 0
for module_name, display_name in packages_to_test:
    try:
        module = __import__(module_name)
        version = getattr(module, '__version__', 'Unknown version')
        print(f"✅ {display_name}: {version}")
        success_count += 1
    except ImportError as e:
        print(f"❌ {display_name}: Import failed - {e}")

print("-" * 50)

# Test TensorFlow basic functionality
try:
    import tensorflow as tf
    x = tf.constant([1, 2, 3])
    y = tf.constant([4, 5, 6]) 
    z = tf.add(x, y)
    print(f"✅ TensorFlow operations test: {z.numpy()}")
    success_count += 1
except Exception as e:
    print(f"❌ TensorFlow operations failed: {e}")

print(f"\\n🎯 Test Results: {success_count}/{len(packages_to_test)+1} components working")
if success_count >= len(packages_to_test):
    print("✅ Installation appears to be working correctly!")
else:
    print("⚠️  Some components failed, but core functionality may still work")
'''
    
    # Write test script to temporary file
    test_file = "test_install_temp.py"
    with open(test_file, "w") as f:
        f.write(test_script)
    
    # Run test
    success = run_command(f'"{python_path}" {test_file}', "Running installation test", ignore_error=True)
    
    # Clean up
    try:
        os.remove(test_file)
    except:
        pass
    
    return success

def create_activation_script():
    """Create convenient activation scripts"""
    if os.name == 'nt':  # Windows
        with open("activate_env.bat", "w") as f:
            f.write("""@echo off
echo.
echo 🚀 Activating Neural Network EA Environment...
echo.
call neural_forex_env\\Scripts\\activate

echo ✅ Environment activated successfully!
echo.
echo 🎯 Available commands:
echo   python train_models.py --synthetic     (Train with demo data)
echo   python train_models.py                (Train with real data)  
echo   python neural_api_service.py          (Start API service)
echo   python monitoring_dashboard.py        (Start web dashboard)
echo.
echo 💡 To exit the environment, type: deactivate
echo.

cmd /k
""")
        print("✅ Created activate_env.bat for easy Windows activation")
    else:  # Linux/Mac
        with open("activate_env.sh", "w") as f:
            f.write("""#!/bin/bash
echo ""
echo "🚀 Activating Neural Network EA Environment..."
echo ""
source neural_forex_env/bin/activate

echo "✅ Environment activated successfully!"
echo ""
echo "🎯 Available commands:"
echo "  python train_models.py --synthetic     (Train with demo data)"
echo "  python train_models.py                (Train with real data)"
echo "  python neural_api_service.py          (Start API service)"
echo "  python monitoring_dashboard.py        (Start web dashboard)"
echo ""
echo "💡 To exit the environment, type: deactivate"
echo ""

exec bash
""")
        os.chmod("activate_env.sh", 0o755)
        print("✅ Created activate_env.sh for easy Linux/Mac activation")

def main():
    """Main function to fix dependency issues"""
    print("🔧 Neural Network EA - Dependency Conflict Resolver (Windows Fixed)")
    print("=" * 70)
    
    # Check Python version
    if not check_python_version():
        return False
    
    # Create clean environment
    activate_script, pip_path, python_path = create_clean_environment()
    
    if not python_path:
        print("❌ Failed to create virtual environment")
        return False
    
    # Install compatible packages
    if not install_compatible_packages(pip_path, python_path):
        print("❌ Failed to install packages")
        return False
    
    # Test installation
    if not test_installation(python_path):
        print("⚠️  Installation test had issues, but may still work")
    
    # Create activation scripts
    create_activation_script()
    
    print("\n" + "=" * 70)
    print("🎉 SETUP COMPLETED!")
    print("=" * 70)
    
    print("\n🚀 Next Steps:")
    print("1. Activate environment:")
    if os.name == 'nt':
        print("   Double-click: activate_env.bat")
        print("   OR run: neural_forex_env\\Scripts\\activate")
    else:
        print("   Run: ./activate_env.sh")
        print("   OR run: source neural_forex_env/bin/activate")
    
    print("\n2. Train models (choose one):")
    print("   python train_models.py --synthetic    # Demo data")
    print("   python train_models.py               # Real market data")
    
    print("\n3. Start services:")
    print("   python neural_api_service.py         # API service") 
    print("   python monitoring_dashboard.py       # Web dashboard")
    
    print("\n💡 Important Notes:")
    print("- Always activate environment before running scripts")
    print("- If some packages failed, try installing them individually")
    print("- The system should work even if a few optional packages failed")
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        if not success:
            print("\n❌ Setup failed. You can try:")
            print("1. Run the script again")
            print("2. Try manual installation steps")
            print("3. Check if you have admin rights") 
            input("\nPress Enter to exit...")
            sys.exit(1)
        else:
            input("\nPress Enter to exit...")
    except KeyboardInterrupt:
        print("\n\n🛑 Setup interrupted by user")
        input("Press Enter to exit...")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        input("Press Enter to exit...")
        sys.exit(1)