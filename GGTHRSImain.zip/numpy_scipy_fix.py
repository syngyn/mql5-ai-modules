# fix_numpy_scipy.py - Fix NumPy/SciPy compatibility issues
import subprocess
import sys
import os
import shutil
from pathlib import Path

def run_command(command, description):
    """Run a command and return success status"""
    print(f"[FIXING] {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, 
                              capture_output=True, text=True)
        print(f"[OK] {description} completed")
        return True
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] {description} failed: {e.stderr}")
        return False

def clear_python_cache():
    """Clear Python cache and compiled files"""
    print("[FIXING] Clearing Python cache...")
    
    # Clear __pycache__ directories
    cache_dirs = []
    for root, dirs, files in os.walk('.'):
        if '__pycache__' in dirs:
            cache_dirs.append(os.path.join(root, '__pycache__'))
    
    for cache_dir in cache_dirs:
        try:
            shutil.rmtree(cache_dir)
            print(f"[OK] Removed {cache_dir}")
        except:
            pass
    
    # Clear .pyc files
    pyc_files = []
    for root, dirs, files in os.walk('.'):
        for file in files:
            if file.endswith('.pyc'):
                pyc_files.append(os.path.join(root, file))
    
    for pyc_file in pyc_files:
        try:
            os.remove(pyc_file)
        except:
            pass
    
    print(f"[OK] Cleared {len(cache_dirs)} cache dirs and {len(pyc_files)} .pyc files")

def fix_numpy_scipy():
    """Fix NumPy/SciPy compatibility"""
    print("NumPy/SciPy Compatibility Fix")
    print("=" * 35)
    
    # Get Python path
    if os.name == 'nt':  # Windows
        python_path = "neural_forex_env\\Scripts\\python"
        pip_path = f'"{python_path}" -m pip'
    else:
        python_path = "neural_forex_env/bin/python"
        pip_path = f'"{python_path}" -m pip'
    
    # Step 1: Clear cache
    clear_python_cache()
    
    # Step 2: Uninstall problematic packages
    packages_to_remove = ['scipy', 'numpy', 'scikit-learn']
    for package in packages_to_remove:
        run_command(f"{pip_path} uninstall {package} -y", f"Uninstalling {package}")
    
    # Step 3: Install compatible versions in specific order
    print("[FIXING] Installing compatible NumPy/SciPy versions...")
    
    # Install numpy first (specific compatible version)
    if not run_command(f"{pip_path} install numpy==1.24.3", "Installing NumPy 1.24.3"):
        print("[ERROR] Failed to install NumPy")
        return False
    
    # Install scipy (compatible with numpy 1.24.3)
    if not run_command(f"{pip_path} install scipy==1.11.1", "Installing SciPy 1.11.1"):
        print("[ERROR] Failed to install SciPy")
        return False
    
    # Install scikit-learn (compatible with both)
    if not run_command(f"{pip_path} install scikit-learn==1.3.0", "Installing Scikit-learn 1.3.0"):
        print("[ERROR] Failed to install Scikit-learn")
        return False
    
    # Step 4: Test the fix
    print("[TESTING] Verifying the fix...")
    
    test_script = '''
import sys
print(f"Python: {sys.version}")

try:
    import numpy as np
    print(f"NumPy: {np.__version__} - OK")
except Exception as e:
    print(f"NumPy: ERROR - {e}")

try:
    import scipy
    print(f"SciPy: {scipy.__version__} - OK")
except Exception as e:
    print(f"SciPy: ERROR - {e}")

try:
    import sklearn
    print(f"Scikit-learn: {sklearn.__version__} - OK")
except Exception as e:
    print(f"Scikit-learn: ERROR - {e}")

# Test scipy functionality
try:
    from scipy import sparse
    print("SciPy sparse module: OK")
except Exception as e:
    print(f"SciPy sparse module: ERROR - {e}")

# Test sklearn functionality  
try:
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    print("Scikit-learn preprocessing: OK")
except Exception as e:
    print(f"Scikit-learn preprocessing: ERROR - {e}")

print("\\nTest completed!")
'''
    
    # Write and run test
    with open("test_numpy_scipy.py", "w") as f:
        f.write(test_script)
    
    success = run_command(f'"{python_path}" test_numpy_scipy.py', "Testing NumPy/SciPy")
    
    # Cleanup test file
    try:
        os.remove("test_numpy_scipy.py")
    except:
        pass
    
    if success:
        print("\n" + "=" * 35)
        print("[SUCCESS] NumPy/SciPy fix completed!")
        print("=" * 35)
        print("\nYou can now run:")
        print("1. python create_files.py")
        print("2. python train_models.py --synthetic")
        return True
    else:
        print("\n[ERROR] Fix failed. Try manual installation:")
        print("1. neural_forex_env\\\\Scripts\\\\activate")
        print("2. pip uninstall numpy scipy scikit-learn -y")
        print("3. pip install numpy==1.24.3")
        print("4. pip install scipy==1.11.1")
        print("5. pip install scikit-learn==1.3.0")
        return False

if __name__ == "__main__":
    try:
        success = fix_numpy_scipy()
        if success:
            print("\n[READY] Environment is now ready for training!")
        else:
            print("\n[FAILED] Please try manual fix steps above")
        input("\nPress Enter to exit...")
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        input("Press Enter to exit...")
