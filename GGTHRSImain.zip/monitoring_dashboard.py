# monitoring_dashboard.py - Real-time web dashboard for Neural Network EA
from flask import Flask, render_template, jsonify, request
import requests
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objs as go
import plotly.utils
import threading
import time
import os

app = Flask(__name__)
app.secret_key = 'neural_forex_dashboard_2024'

# Dashboard configuration
API_BASE_URL = "http://127.0.0.1:5000"
UPDATE_INTERVAL = 30  # seconds

# Global data storage
dashboard_data = {
    'system_status': {},
    'predictions': {},
    'accuracy_stats': {},
    'trading_stats': {},
    'last_update': None
}

class DataCollector:
    """Collects data from the neural network API service"""
    
    def __init__(self):
        self.running = False
        
    def get_system_status(self):
        """Get system health status"""
        try:
            response = requests.get(f"{API_BASE_URL}/health", timeout=5)
            if response.status_code == 200:
                return response.json()
            return {"status": "unhealthy", "error": "API not responding"}
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def get_model_info(self):
        """Get model information"""
        try:
            response = requests.get(f"{API_BASE_URL}/models/info", timeout=5)
            if response.status_code == 200:
                return response.json()
            return {}
        except:
            return {}
    
    def get_predictions(self, symbols=['EURUSD', 'GBPUSD', 'USDJPY']):
        """Get current predictions"""
        predictions = {}
        
        for symbol in symbols:
            try:
                payload = {
                    "symbol": symbol,
                    "timeframes": ["H1", "D1"],
                    "periods": [1, 2, 3, 4, 5]
                }
                response = requests.post(f"{API_BASE_URL}/predict", 
                                       json=payload, timeout=10)
                
                if response.status_code == 200:
                    predictions[symbol] = response.json()
                else:
                    predictions[symbol] = {"error": "Failed to get predictions"}
            except Exception as e:
                predictions[symbol] = {"error": str(e)}
        
        return predictions
    
    def get_accuracy_stats(self, symbols=['EURUSD', 'GBPUSD', 'USDJPY']):
        """Get accuracy statistics"""
        stats = {}
        
        for symbol in symbols:
            try:
                response = requests.get(f"{API_BASE_URL}/accuracy?symbol={symbol}", 
                                      timeout=5)
                
                if response.status_code == 200:
                    stats[symbol] = response.json()
                else:
                    stats[symbol] = {"error": "No data available"}
            except Exception as e:
                stats[symbol] = {"error": str(e)}
        
        return stats
    
    def update_dashboard_data(self):
        """Update all dashboard data"""
        try:
            dashboard_data['system_status'] = self.get_system_status()
            dashboard_data['model_info'] = self.get_model_info()
            dashboard_data['predictions'] = self.get_predictions()
            dashboard_data['accuracy_stats'] = self.get_accuracy_stats()
            dashboard_data['last_update'] = datetime.now().isoformat()
            
            print(f"Dashboard data updated at {dashboard_data['last_update']}")
            
        except Exception as e:
            print(f"Error updating dashboard data: {e}")
    
    def start_background_updates(self):
        """Start background data collection"""
        self.running = True
        
        def update_loop():
            while self.running:
                self.update_dashboard_data()
                time.sleep(UPDATE_INTERVAL)
        
        thread = threading.Thread(target=update_loop, daemon=True)
        thread.start()
        print(f"Background data collection started (interval: {UPDATE_INTERVAL}s)")
    
    def stop_background_updates(self):
        """Stop background data collection"""
        self.running = False

# Initialize data collector
collector = DataCollector()

@app.route('/')
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/api/status')
def api_status():
    """Get system status"""
    return jsonify(dashboard_data.get('system_status', {}))

@app.route('/api/predictions')
def api_predictions():
    """Get current predictions"""
    return jsonify(dashboard_data.get('predictions', {}))

@app.route('/api/accuracy')
def api_accuracy():
    """Get accuracy statistics"""
    return jsonify(dashboard_data.get('accuracy_stats', {}))

@app.route('/api/dashboard_data')
def api_dashboard_data():
    """Get all dashboard data"""
    return jsonify(dashboard_data)

@app.route('/api/charts/predictions')
def predictions_chart():
    """Generate predictions chart"""
    try:
        predictions = dashboard_data.get('predictions', {})
        
        if not predictions:
            return jsonify({"error": "No prediction data available"})
        
        traces = []
        
        for symbol, data in predictions.items():
            if 'error' in data:
                continue
                
            if 'predictions' in data and 'H1' in data['predictions']:
                hourly_preds = data['predictions']['H1']
                
                times = []
                prices = []
                confidences = []
                
                for pred in hourly_preds:
                    times.append(pred.get('target_time', ''))
                    prices.append(pred.get('predicted_price', 0))
                    confidences.append(pred.get('confidence', 0))
                
                # Price prediction trace
                traces.append(go.Scatter(
                    x=times,
                    y=prices,
                    mode='lines+markers',
                    name=f'{symbol} Price Pred',
                    line=dict(width=2)
                ))
                
                # Confidence trace (secondary y-axis)
                traces.append(go.Scatter(
                    x=times,
                    y=confidences,
                    mode='lines+markers',
                    name=f'{symbol} Confidence',
                    yaxis='y2',
                    line=dict(dash='dash')
                ))
        
        layout = go.Layout(
            title='Neural Network Predictions',
            xaxis=dict(title='Time'),
            yaxis=dict(title='Price', side='left'),
            yaxis2=dict(title='Confidence', side='right', overlaying='y'),
            hovermode='closest',
            showlegend=True,
            height=400
        )
        
        figure = go.Figure(data=traces, layout=layout)
        graphJSON = json.dumps(figure, cls=plotly.utils.PlotlyJSONEncoder)
        
        return graphJSON
        
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/api/charts/accuracy')
def accuracy_chart():
    """Generate accuracy chart"""
    try:
        accuracy_stats = dashboard_data.get('accuracy_stats', {})
        
        if not accuracy_stats:
            return jsonify({"error": "No accuracy data available"})
        
        symbols = []
        mean_accuracies = []
        recent_accuracies = []
        
        for symbol, stats in accuracy_stats.items():
            if 'error' in stats:
                continue
                
            symbols.append(symbol)
            mean_accuracies.append(stats.get('mean_accuracy', 0) * 100)
            recent_accuracies.append(stats.get('recent_accuracy', 0) * 100)
        
        traces = [
            go.Bar(name='Mean Accuracy', x=symbols, y=mean_accuracies),
            go.Bar(name='Recent Accuracy', x=symbols, y=recent_accuracies)
        ]
        
        layout = go.Layout(
            title='Model Accuracy by Symbol',
            xaxis=dict(title='Currency Pairs'),
            yaxis=dict(title='Accuracy (%)', range=[0, 100]),
            barmode='group',
            height=400
        )
        
        figure = go.Figure(data=traces, layout=layout)
        graphJSON = json.dumps(figure, cls=plotly.utils.PlotlyJSONEncoder)
        
        return graphJSON
        
    except Exception as e:
        return jsonify({"error": str(e)})

# HTML template for the dashboard
dashboard_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neural Network Forex EA - Dashboard</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            margin: 0 0 15px 0;
            color: #333;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .status-healthy { background-color: #4CAF50; }
        .status-warning { background-color: #FF9800; }
        .status-error { background-color: #F44336; }
        
        .chart-container {
            background: white;
            margin: 20px 0;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .last-update {
            text-align: center;
            color: #666;
            margin-top: 20px;
            font-size: 0.9em;
        }
        .prediction-table {
            width: 100%;
            border-collapse: collapse;
        }
        .prediction-table th,
        .prediction-table td {
            padding: 8px 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        .prediction-table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .confidence-high { color: #4CAF50; font-weight: bold; }
        .confidence-medium { color: #FF9800; font-weight: bold; }
        .confidence-low { color: #F44336; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 Neural Network Forex EA Dashboard</h1>
            <p>Real-time monitoring of LSTM + Transformer + CNN ensemble predictions</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>System Status</h3>
                <div id="system-status">Loading...</div>
            </div>
            
            <div class="stat-card">
                <h3>Model Information</h3>
                <div id="model-info">Loading...</div>
            </div>
            
            <div class="stat-card">
                <h3>Current Predictions</h3>
                <div id="current-predictions">Loading...</div>
            </div>
            
            <div class="stat-card">
                <h3>Accuracy Statistics</h3>
                <div id="accuracy-stats">Loading...</div>
            </div>
        </div>
        
        <div class="chart-container">
            <div id="predictions-chart"></div>
        </div>
        
        <div class="chart-container">
            <div id="accuracy-chart"></div>
        </div>
        
        <div class="last-update" id="last-update">
            Last updated: Never
        </div>
    </div>

    <script>
        let updateInterval;
        
        function updateDashboard() {
            // Update system status
            fetch('/api/status')
                .then(response => response.json())
                .then(data => updateSystemStatus(data))
                .catch(error => console.error('Error fetching status:', error));
            
            // Update predictions
            fetch('/api/predictions')
                .then(response => response.json())
                .then(data => updatePredictions(data))
                .catch(error => console.error('Error fetching predictions:', error));
            
            // Update accuracy stats
            fetch('/api/accuracy')
                .then(response => response.json())
                .then(data => updateAccuracyStats(data))
                .catch(error => console.error('Error fetching accuracy:', error));
            
            // Update charts
            updateCharts();
            
            // Update timestamp
            document.getElementById('last-update').textContent = 
                'Last updated: ' + new Date().toLocaleString();
        }
        
        function updateSystemStatus(data) {
            const statusElement = document.getElementById('system-status');
            const status = data.status || 'unknown';
            
            let statusClass = 'status-error';
            if (status === 'healthy') statusClass = 'status-healthy';
            else if (status === 'warning') statusClass = 'status-warning';
            
            statusElement.innerHTML = `
                <span class="status-indicator ${statusClass}"></span>
                <strong>Status:</strong> ${status}<br>
                ${data.models_loaded ? '✅ Models loaded' : '❌ Models not loaded'}<br>
                ${data.last_update ? 'Last model update: ' + new Date(data.last_update).toLocaleString() : 'Never updated'}
            `;
        }
        
        function updatePredictions(data) {
            const predElement = document.getElementById('current-predictions');
            
            if (Object.keys(data).length === 0) {
                predElement.innerHTML = 'No predictions available';
                return;
            }
            
            let html = '<table class="prediction-table"><tr><th>Symbol</th><th>1H Pred</th><th>Confidence</th></tr>';
            
            Object.keys(data).forEach(symbol => {
                const symbolData = data[symbol];
                if (symbolData.error) {
                    html += `<tr><td>${symbol}</td><td colspan="2">Error: ${symbolData.error}</td></tr>`;
                } else if (symbolData.predictions && symbolData.predictions.H1 && symbolData.predictions.H1[0]) {
                    const pred = symbolData.predictions.H1[0];
                    const confidence = (pred.confidence * 100).toFixed(1);
                    let confClass = 'confidence-low';
                    if (pred.confidence > 0.7) confClass = 'confidence-high';
                    else if (pred.confidence > 0.5) confClass = 'confidence-medium';
                    
                    html += `<tr><td>${symbol}</td><td>${pred.predicted_price.toFixed(5)}</td><td class="${confClass}">${confidence}%</td></tr>`;
                }
            });
            
            html += '</table>';
            predElement.innerHTML = html;
        }
        
        function updateAccuracyStats(data) {
            const accElement = document.getElementById('accuracy-stats');
            
            if (Object.keys(data).length === 0) {
                accElement.innerHTML = 'No accuracy data available';
                return;
            }
            
            let html = '';
            Object.keys(data).forEach(symbol => {
                const stats = data[symbol];
                if (stats.error) {
                    html += `<strong>${symbol}:</strong> ${stats.error}<br>`;
                } else {
                    const meanAcc = (stats.mean_accuracy * 100).toFixed(1);
                    const recentAcc = (stats.recent_accuracy * 100).toFixed(1);
                    html += `<strong>${symbol}:</strong> ${meanAcc}% (recent: ${recentAcc}%)<br>`;
                }
            });
            
            accElement.innerHTML = html;
        }
        
        function updateCharts() {
            // Update predictions chart
            fetch('/api/charts/predictions')
                .then(response => response.json())
                .then(data => {
                    if (!data.error) {
                        Plotly.newPlot('predictions-chart', data.data, data.layout);
                    }
                })
                .catch(error => console.error('Error updating predictions chart:', error));
            
            // Update accuracy chart
            fetch('/api/charts/accuracy')
                .then(response => response.json())
                .then(data => {
                    if (!data.error) {
                        Plotly.newPlot('accuracy-chart', data.data, data.layout);
                    }
                })
                .catch(error => console.error('Error updating accuracy chart:', error));
        }
        
        // Initial load
        updateDashboard();
        
        // Set up auto-refresh every 30 seconds
        updateInterval = setInterval(updateDashboard, 30000);
        
        // Update model info (less frequent)
        setInterval(() => {
            fetch('/api/dashboard_data')
                .then(response => response.json())
                .then(data => {
                    if (data.model_info) {
                        const modelElement = document.getElementById('model-info');
                        const info = data.model_info;
                        modelElement.innerHTML = `
                            Models loaded: ${info.models_loaded ? 'Yes' : 'No'}<br>
                            Accuracy records: ${info.accuracy_records || 0}<br>
                            Ensemble weights: ${info.ensemble_weights ? info.ensemble_weights.map(w => (w*100).toFixed(1) + '%').join(', ') : 'N/A'}
                        `;
                    }
                })
                .catch(error => console.error('Error fetching model info:', error));
        }, 60000); // Every minute
    </script>
</body>
</html>
"""

# Create templates directory and save HTML
def create_template():
    os.makedirs('templates', exist_ok=True)
    with open('templates/dashboard.html', 'w') as f:
        f.write(dashboard_html)

if __name__ == '__main__':
    # Create template file
    create_template()
    
    # Start data collection
    collector.start_background_updates()
    
    # Initial data load
    collector.update_dashboard_data()
    
    print("🖥️  Neural Network EA Dashboard starting...")
    print("📊 Dashboard URL: http://127.0.0.1:8080")
    print("🔄 Auto-refresh every 30 seconds")
    print("📡 Connects to API service on http://127.0.0.1:5000")
    
    try:
        # Run dashboard on different port to avoid conflict with API service
        app.run(host='127.0.0.1', port=8080, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\n🛑 Dashboard shutdown requested")
        collector.stop_background_updates()
        print("✅ Dashboard stopped")
