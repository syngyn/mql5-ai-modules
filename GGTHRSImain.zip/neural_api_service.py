# neural_api_service.py - Flask API for serving neural network predictions
from flask import Flask, request, jsonify
import numpy as np
import pandas as pd
import json
import logging
from datetime import datetime, timedelta
import MetaTrader5 as mt5
from neural_networks import EnsemblePredictor, ForexDataPreprocessor
import threading
import schedule
import time

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

class ForexPredictionService:
    """Service for managing forex predictions and model updates"""
    
    def __init__(self):
        self.ensemble = EnsemblePredictor()
        self.preprocessor = ForexDataPreprocessor()
        self.model_loaded = False
        self.last_model_update = None
        self.prediction_cache = {}
        self.accuracy_history = []
        
    def initialize_models(self):
        """Initialize and load trained models"""
        try:
            self.ensemble.load_models()
            self.model_loaded = True
            self.last_model_update = datetime.now()
            logger.info("Models loaded successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to load models: {e}")
            return False
    
    def get_mt5_data(self, symbol, timeframe, count=1000):
        """Fetch data from MetaTrader 5"""
        try:
            if not mt5.initialize():
                logger.error("Failed to initialize MT5")
                return None
            
            # Map timeframe
            tf_map = {
                'M1': mt5.TIMEFRAME_M1,
                'M5': mt5.TIMEFRAME_M5,
                'M15': mt5.TIMEFRAME_M15,
                'M30': mt5.TIMEFRAME_M30,
                'H1': mt5.TIMEFRAME_H1,
                'H4': mt5.TIMEFRAME_H4,
                'D1': mt5.TIMEFRAME_D1
            }
            
            rates = mt5.copy_rates_from_pos(symbol, tf_map.get(timeframe, mt5.TIMEFRAME_H1), 0, count)
            mt5.shutdown()
            
            if rates is None or len(rates) == 0:
                return None
                
            df = pd.DataFrame(rates)
            df['time'] = pd.to_datetime(df['time'], unit='s')
            df.set_index('time', inplace=True)
            
            # Rename columns to match expected format
            df = df.rename(columns={
                'open': 'open',
                'high': 'high', 
                'low': 'low',
                'close': 'close',
                'tick_volume': 'volume'
            })
            
            return df[['open', 'high', 'low', 'close', 'volume']]
            
        except Exception as e:
            logger.error(f"Error fetching MT5 data: {e}")
            return None
    
    def make_predictions(self, symbol, timeframes=['H1', 'D1'], prediction_periods=[1, 2, 3, 4, 5]):
        """Generate predictions for multiple timeframes and periods"""
        predictions = {}
        
        for tf in timeframes:
            try:
                # Get data
                df = self.get_mt5_data(symbol, tf, count=1000)
                if df is None:
                    continue
                
                # Add technical features
                df_features = self.preprocessor.create_technical_features(df)
                
                # Prepare data
                X_seq, _, _ = self.preprocessor.prepare_sequences(df_features)
                X_img = self.preprocessor.create_candlestick_images(df_features)
                
                if len(X_seq) == 0 or len(X_img) == 0:
                    continue
                
                # Get latest data point
                latest_seq = X_seq[-1:] 
                latest_img = X_img[-1:]
                
                # Generate predictions for each period
                tf_predictions = []
                
                for period in prediction_periods:
                    # Make prediction
                    pred, confidence = self.ensemble.predict_with_confidence(latest_seq, latest_img)
                    
                    # Calculate target time
                    current_price = df['close'].iloc[-1]
                    target_time = self._calculate_target_time(tf, period)
                    
                    # Inverse transform prediction
                    predicted_price = self.preprocessor.price_scaler.inverse_transform([[pred[0][0]]])[0][0]
                    
                    tf_predictions.append({
                        'period': period,
                        'predicted_price': float(predicted_price),
                        'current_price': float(current_price),
                        'confidence': float(confidence[0]),
                        'target_time': target_time.isoformat(),
                        'price_change': float(predicted_price - current_price),
                        'price_change_pct': float((predicted_price - current_price) / current_price * 100)
                    })
                
                predictions[tf] = tf_predictions
                
            except Exception as e:
                logger.error(f"Error making predictions for {tf}: {e}")
                continue
        
        return predictions
    
    def _calculate_target_time(self, timeframe, periods):
        """Calculate target time based on timeframe and periods"""
        now = datetime.now()
        
        if timeframe == 'M1':
            return now + timedelta(minutes=periods)
        elif timeframe == 'M5':
            return now + timedelta(minutes=periods * 5)
        elif timeframe == 'M15':
            return now + timedelta(minutes=periods * 15)
        elif timeframe == 'M30':
            return now + timedelta(minutes=periods * 30)
        elif timeframe == 'H1':
            return now + timedelta(hours=periods)
        elif timeframe == 'H4':
            return now + timedelta(hours=periods * 4)
        elif timeframe == 'D1':
            return now + timedelta(days=periods)
        else:
            return now + timedelta(hours=periods)
    
    def update_accuracy(self, symbol, timeframe, prediction_time, predicted_price, actual_price):
        """Update prediction accuracy tracking"""
        error = abs(predicted_price - actual_price) / actual_price
        accuracy = max(0, 1 - error)
        
        self.accuracy_history.append({
            'timestamp': datetime.now().isoformat(),
            'symbol': symbol,
            'timeframe': timeframe,
            'prediction_time': prediction_time,
            'predicted_price': predicted_price,
            'actual_price': actual_price,
            'accuracy': accuracy,
            'error_pct': error * 100
        })
        
        # Keep only last 1000 records
        if len(self.accuracy_history) > 1000:
            self.accuracy_history = self.accuracy_history[-1000:]
    
    def get_accuracy_stats(self, symbol=None, timeframe=None, days_back=30):
        """Get accuracy statistics"""
        cutoff_date = datetime.now() - timedelta(days=days_back)
        
        filtered_history = []
        for record in self.accuracy_history:
            record_date = datetime.fromisoformat(record['timestamp'])
            
            if record_date < cutoff_date:
                continue
            
            if symbol and record['symbol'] != symbol:
                continue
                
            if timeframe and record['timeframe'] != timeframe:
                continue
                
            filtered_history.append(record)
        
        if not filtered_history:
            return None
        
        accuracies = [r['accuracy'] for r in filtered_history]
        
        return {
            'count': len(filtered_history),
            'mean_accuracy': np.mean(accuracies),
            'std_accuracy': np.std(accuracies),
            'min_accuracy': np.min(accuracies),
            'max_accuracy': np.max(accuracies),
            'recent_accuracy': np.mean(accuracies[-10:]) if len(accuracies) >= 10 else np.mean(accuracies)
        }
    
    def retrain_models(self, symbol='EURUSD', lookback_days=365):
        """Retrain models with recent data"""
        try:
            logger.info(f"Starting model retraining for {symbol}")
            
            # Get extended historical data
            df = self.get_mt5_data(symbol, 'H1', count=lookback_days * 24)
            
            if df is None or len(df) < 1000:
                logger.error("Insufficient data for retraining")
                return False
            
            # Prepare data
            df_features = self.preprocessor.create_technical_features(df)
            X_seq, y, _ = self.preprocessor.prepare_sequences(df_features)
            X_img = self.preprocessor.create_candlestick_images(df_features)
            
            # Retrain ensemble
            self.ensemble.train_ensemble(X_seq, X_img, y)
            
            # Save updated models
            self.ensemble.save_models()
            
            self.last_model_update = datetime.now()
            logger.info("Model retraining completed successfully")
            
            return True
            
        except Exception as e:
            logger.error(f"Error during model retraining: {e}")
            return False

# Initialize service
prediction_service = ForexPredictionService()

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'models_loaded': prediction_service.model_loaded,
        'last_update': prediction_service.last_model_update.isoformat() if prediction_service.last_model_update else None
    })

@app.route('/predict', methods=['POST'])
def predict():
    """Main prediction endpoint"""
    try:
        data = request.json
        symbol = data.get('symbol', 'EURUSD')
        timeframes = data.get('timeframes', ['H1', 'D1'])
        periods = data.get('periods', [1, 2, 3, 4, 5])
        
        if not prediction_service.model_loaded:
            return jsonify({'error': 'Models not loaded'}), 500
        
        # Generate predictions
        predictions = prediction_service.make_predictions(symbol, timeframes, periods)
        
        if not predictions:
            return jsonify({'error': 'Failed to generate predictions'}), 500
        
        # Add metadata
        response = {
            'symbol': symbol,
            'timestamp': datetime.now().isoformat(),
            'predictions': predictions,
            'model_info': {
                'ensemble_weights': prediction_service.ensemble.weights.tolist(),
                'last_update': prediction_service.last_model_update.isoformat() if prediction_service.last_model_update else None
            }
        }
        
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"Error in predict endpoint: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/accuracy', methods=['GET', 'POST'])
def accuracy():
    """Accuracy tracking endpoint"""
    if request.method == 'POST':
        # Update accuracy with actual results
        data = request.json
        prediction_service.update_accuracy(
            symbol=data['symbol'],
            timeframe=data['timeframe'],
            prediction_time=data['prediction_time'],
            predicted_price=data['predicted_price'],
            actual_price=data['actual_price']
        )
        return jsonify({'status': 'updated'})
    
    else:
        # Get accuracy statistics
        symbol = request.args.get('symbol')
        timeframe = request.args.get('timeframe')
        days_back = int(request.args.get('days_back', 30))
        
        stats = prediction_service.get_accuracy_stats(symbol, timeframe, days_back)
        
        if stats is None:
            return jsonify({'error': 'No data available'}), 404
            
        return jsonify(stats)

@app.route('/retrain', methods=['POST'])
def retrain():
    """Model retraining endpoint"""
    try:
        data = request.json or {}
        symbol = data.get('symbol', 'EURUSD')
        lookback_days = data.get('lookback_days', 365)
        
        # Run retraining in background
        thread = threading.Thread(
            target=prediction_service.retrain_models,
            args=(symbol, lookback_days)
        )
        thread.start()
        
        return jsonify({'status': 'retraining_started'})
        
    except Exception as e:
        logger.error(f"Error in retrain endpoint: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/models/info', methods=['GET'])
def model_info():
    """Get model information"""
    return jsonify({
        'models_loaded': prediction_service.model_loaded,
        'last_update': prediction_service.last_model_update.isoformat() if prediction_service.last_model_update else None,
        'ensemble_weights': prediction_service.ensemble.weights.tolist() if prediction_service.model_loaded else None,
        'accuracy_records': len(prediction_service.accuracy_history)
    })

def scheduled_retraining():
    """Scheduled model retraining"""
    logger.info("Starting scheduled model retraining")
    success = prediction_service.retrain_models()
    if success:
        logger.info("Scheduled retraining completed successfully")
    else:
        logger.error("Scheduled retraining failed")

def start_scheduler():
    """Start the background scheduler"""
    # Schedule retraining every Sunday at 2 AM
    schedule.every().sunday.at("02:00").do(scheduled_retraining)
    
    while True:
        schedule.run_pending()
        time.sleep(60)  # Check every minute

if __name__ == '__main__':
    # Initialize models on startup
    print("Initializing neural network models...")
    if not prediction_service.initialize_models():
        print("Warning: Models not loaded. Please train models first.")
    
    # Start scheduler in background
    scheduler_thread = threading.Thread(target=start_scheduler, daemon=True)
    scheduler_thread.start()
    
    # Start Flask app
    app.run(host='127.0.0.1', port=5000, debug=False, threaded=True)
