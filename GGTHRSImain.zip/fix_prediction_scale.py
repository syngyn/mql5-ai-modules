# fix_prediction_scale.py - Make predictions realistic
import re

def fix_prediction_scale():
    """Fix the prediction scale in robust_api_service.py"""
    
    try:
        with open('robust_api_service.py', 'r', encoding='utf-8') as f:
            content = f.read()
    except:
        print("❌ robust_api_service.py not found")
        return False
    
    print("🔧 Fixing prediction scale to realistic forex movements...")
    
    # Find and replace the H1 prediction logic
    h1_old_pattern = r"trend = \(np\.random\.random\(\) - 0\.5\) \* 0\.00\d+"
    h1_new_trend = "trend = (np.random.random() - 0.5) * 0.0002  # ±0.01% realistic"
    
    content = re.sub(h1_old_pattern, h1_new_trend, content)
    
    # Find and replace the noise factor
    noise_old_pattern = r"noise = \(np\.random\.random\(\) - 0\.5\) \* 0\.00\d+"
    noise_new = "noise = (np.random.random() - 0.5) * 0.0001  # Small random noise"
    
    content = re.sub(noise_old_pattern, noise_new, content)
    
    # Fix D1 predictions too
    d1_old_pattern = r"trend = \(np\.random\.random\(\) - 0\.5\) \* 0\.0\d+"
    d1_new_trend = "trend = (np.random.random() - 0.5) * 0.001   # ±0.05% daily"
    
    content = re.sub(d1_old_pattern, d1_new_trend, content)
    
    # Update base prices to current realistic levels
    base_prices_section = '''        base_prices = {
            'EURUSD': 1.1600,    # Current EUR/USD level
            'GBPUSD': 1.2800,    # Current GBP/USD level  
            'USDJPY': 148.00,    # Current USD/JPY level
            'USDCHF': 0.8800,    # Current USD/CHF level
            'AUDUSD': 0.6700,    # Current AUD/USD level
            'USDCAD': 1.3600,    # Current USD/CAD level
            'NZDUSD': 0.6200,    # Current NZD/USD level
            'EURJPY': 171.68,    # EUR/JPY (1.16 * 148)
            'GBPJPY': 189.44,    # GBP/JPY (1.28 * 148)
            'EURGBP': 0.9063     # EUR/GBP (1.16 / 1.28)
        }'''
    
    # Replace base prices
    base_prices_pattern = r"base_prices = \{[^}]+\}"
    content = re.sub(base_prices_pattern, base_prices_section.strip(), content, flags=re.DOTALL)
    
    # Write the fixed file
    try:
        with open('robust_api_service.py', 'w', encoding='utf-8') as f:
            f.write(content)
        print("✅ Fixed robust_api_service.py with realistic prediction scales")
        return True
    except Exception as e:
        print(f"❌ Failed to write file: {e}")
        return False

def create_test_api_call():
    """Create a test script to verify predictions"""
    
    test_script = '''# test_predictions.py - Test the fixed prediction scale
import requests
import json

def test_predictions():
    """Test the prediction API"""
    
    url = "http://127.0.0.1:5000/predict"
    
    payload = {
        "symbol": "EURUSD",
        "timeframes": ["H1", "D1"],
        "periods": [1, 2, 3, 4, 5]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            
            print("🔮 Prediction Test Results:")
            print("=" * 40)
            
            if 'predictions' in data and 'H1' in data['predictions']:
                h1_preds = data['predictions']['H1']
                current_price = 1.1600  # Assumed current EURUSD
                
                print("📊 Hourly Predictions:")
                for pred in h1_preds[:3]:  # Show first 3
                    predicted = pred['predicted_price']
                    pips_change = (predicted - current_price) * 10000
                    print(f"  Period {pred['period']}: {predicted:.5f} ({pips_change:+.1f} pips) - Confidence: {pred['confidence']:.1%}")
                
                print("\\n✅ Expected: Small pip movements (±1 to ±20 pips)")
                if abs(pips_change) > 50:
                    print("⚠️  WARNING: Still showing large movements! May need manual fix.")
                else:
                    print("✅ SUCCESS: Realistic pip movements!")
                    
            else:
                print("❌ No H1 predictions in response")
                
        else:
            print(f"❌ API request failed: {response.status_code}")
            print(response.text)
            
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to API. Make sure robust_api_service.py is running!")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_predictions()
'''
    
    try:
        with open('test_predictions.py', 'w', encoding='utf-8') as f:
            f.write(test_script)
        print("✅ Created test_predictions.py")
        return True
    except Exception as e:
        print(f"❌ Failed to create test script: {e}")
        return False

def main():
    print("🎯 Fixing Prediction Scale for Realistic Forex Movements")
    print("=" * 55)
    print("Current issue: EURUSD 1.16 → 1.19 (300 pips in 1 hour)")
    print("Target fix: EURUSD 1.16 → 1.16045 (4.5 pips in 1 hour)")
    print("=" * 55)
    
    # Apply the fix
    api_fixed = fix_prediction_scale()
    test_created = create_test_api_call()
    
    if api_fixed:
        print("\\n✅ PREDICTION SCALE FIXED!")
        print("\\nNext steps:")
        print("1. Stop your current API service (Ctrl+C)")
        print("2. Restart: python robust_api_service.py")
        print("3. Test: python test_predictions.py")
        print("4. Check MT5 - should now show realistic movements:")
        print("   • EURUSD: 1.16000 → 1.16045 (±5 pips)")
        print("   • USDJPY: 148.00 → 148.05 (±5 pips)")
        
        if test_created:
            print("\\n🧪 Run 'python test_predictions.py' to verify the fix!")
    else:
        print("\\n❌ Fix failed - may need manual editing")
        print("\\nManual fix in robust_api_service.py:")
        print("Find: trend = (np.random.random() - 0.5) * 0.002")
        print("Replace: trend = (np.random.random() - 0.5) * 0.0002")
    
    return api_fixed

if __name__ == "__main__":
    success = main()
    input("\\nPress Enter to exit...")
