# debug_api_service.py - Simplified API service with better error handling
from flask import Flask, request, jsonify
import numpy as np
import json
from datetime import datetime, timedelta
import traceback
import os

app = Flask(__name__)

# Simple test data
test_predictions = {
    'EURUSD': {
        'base_price': 1.2000,
        'hourly_trend': 0.0001,
        'daily_trend': 0.0005
    },
    'GBPUSD': {
        'base_price': 1.3000,
        'hourly_trend': 0.0002,
        'daily_trend': 0.0004
    }
}

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    try:
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'message': 'Neural Network API Service is running'
        })
    except Exception as e:
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/predict', methods=['POST'])
def predict():
    """Prediction endpoint with comprehensive error handling"""
    try:
        print("=" * 50)
        print(f"[{datetime.now()}] Prediction request received")
        
        # Get request data
        if request.is_json:
            data = request.get_json()
            print(f"Request data: {data}")
        else:
            print("ERROR: Request is not JSON")
            return jsonify({'error': 'Request must be JSON'}), 400
        
        # Extract parameters
        symbol = data.get('symbol', 'EURUSD')
        timeframes = data.get('timeframes', ['H1', 'D1'])
        periods = data.get('periods', [1, 2, 3, 4, 5])
        
        print(f"Symbol: {symbol}, Timeframes: {timeframes}, Periods: {periods}")
        
        # Get base data for symbol
        if symbol in test_predictions:
            base_data = test_predictions[symbol]
        else:
            base_data = test_predictions['EURUSD']  # Default fallback
        
        base_price = base_data['base_price']
        hourly_trend = base_data['hourly_trend']
        daily_trend = base_data['daily_trend']
        
        # Generate predictions
        predictions = {
            'symbol': symbol,
            'timestamp': datetime.now().isoformat(),
            'predictions': {}
        }
        
        # Generate H1 predictions
        if 'H1' in timeframes:
            h1_predictions = []
            for i, period in enumerate(periods):
                # Simple prediction logic
                trend_factor = hourly_trend * period
                random_factor = (np.random.random() - 0.5) * 0.0005
                predicted_price = base_price + trend_factor + random_factor
                
                confidence = max(0.5, min(0.9, 0.7 + (np.random.random() - 0.5) * 0.3))
                
                target_time = datetime.now() + timedelta(hours=period)
                
                h1_predictions.append({
                    'period': period,
                    'predicted_price': round(predicted_price, 5),
                    'confidence': round(confidence, 3),
                    'target_time': target_time.isoformat(),
                    'price_change': round(predicted_price - base_price, 5),
                    'price_change_pct': round((predicted_price - base_price) / base_price * 100, 3)
                })
            
            predictions['predictions']['H1'] = h1_predictions
        
        # Generate D1 predictions  
        if 'D1' in timeframes:
            d1_predictions = []
            for i, period in enumerate(periods):
                trend_factor = daily_trend * period
                random_factor = (np.random.random() - 0.5) * 0.002
                predicted_price = base_price + trend_factor + random_factor
                
                confidence = max(0.4, min(0.8, 0.6 + (np.random.random() - 0.5) * 0.3))
                
                target_time = datetime.now() + timedelta(days=period)
                
                d1_predictions.append({
                    'period': period,
                    'predicted_price': round(predicted_price, 5),
                    'confidence': round(confidence, 3),
                    'target_time': target_time.isoformat(),
                    'price_change': round(predicted_price - base_price, 5),
                    'price_change_pct': round((predicted_price - base_price) / base_price * 100, 3)
                })
            
            predictions['predictions']['D1'] = d1_predictions
        
        print(f"Generated predictions: {len(predictions['predictions'])} timeframes")
        print("Request processed successfully")
        
        return jsonify(predictions)
        
    except Exception as e:
        error_msg = f"Prediction error: {str(e)}"
        print(f"ERROR: {error_msg}")
        print(f"Traceback: {traceback.format_exc()}")
        
        return jsonify({
            'error': error_msg,
            'traceback': traceback.format_exc(),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/models/info', methods=['GET'])
def model_info():
    """Get model information"""
    try:
        return jsonify({
            'models_loaded': True,
            'model_type': 'Demo/Test models',
            'last_update': datetime.now().isoformat(),
            'supported_symbols': list(test_predictions.keys())
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/test', methods=['GET', 'POST'])
def test_endpoint():
    """Test endpoint for debugging"""
    try:
        method = request.method
        headers = dict(request.headers)
        
        if request.is_json:
            data = request.get_json()
        else:
            data = "No JSON data"
        
        return jsonify({
            'status': 'test_success',
            'method': method,
            'headers': headers,
            'data': data,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("🚀 Debug Neural Network API Service")
    print("=" * 40)
    print("Available endpoints:")
    print("  GET  /health       - Health check")
    print("  POST /predict      - Get predictions")
    print("  GET  /models/info  - Model information")
    print("  GET/POST /test     - Test endpoint")
    print("=" * 40)
    print("Service URL: http://127.0.0.1:5000")
    print("Health check: http://127.0.0.1:5000/health")
    print("=" * 40)
    
    # Check if models directory exists
    if os.path.exists('models'):
        print("✅ Models directory found")
        model_files = [f for f in os.listdir('models') if f.endswith('.h5')]
        if model_files:
            print(f"✅ Model files: {model_files}")
        else:
            print("⚠️  No .h5 model files in models directory")
    else:
        print("⚠️  No models directory found")
    
    print("=" * 40)
    print("Starting server...")
    
    app.run(host='127.0.0.1', port=5000, debug=True, threaded=True)
