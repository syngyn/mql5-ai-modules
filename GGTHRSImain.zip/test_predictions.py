# test_predictions.py - Test the fixed prediction scale
import requests
import json

def test_predictions():
    """Test the prediction API"""
    
    url = "http://127.0.0.1:5000/predict"
    
    payload = {
        "symbol": "EURUSD",
        "timeframes": ["H1", "D1"],
        "periods": [1, 2, 3, 4, 5]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            
            print("🔮 Prediction Test Results:")
            print("=" * 40)
            
            if 'predictions' in data and 'H1' in data['predictions']:
                h1_preds = data['predictions']['H1']
                current_price = 1.1600  # Assumed current EURUSD
                
                print("📊 Hourly Predictions:")
                for pred in h1_preds[:3]:  # Show first 3
                    predicted = pred['predicted_price']
                    pips_change = (predicted - current_price) * 10000
                    print(f"  Period {pred['period']}: {predicted:.5f} ({pips_change:+.1f} pips) - Confidence: {pred['confidence']:.1%}")
                
                print("\n✅ Expected: Small pip movements (±1 to ±20 pips)")
                if abs(pips_change) > 50:
                    print("⚠️  WARNING: Still showing large movements! May need manual fix.")
                else:
                    print("✅ SUCCESS: Realistic pip movements!")
                    
            else:
                print("❌ No H1 predictions in response")
                
        else:
            print(f"❌ API request failed: {response.status_code}")
            print(response.text)
            
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to API. Make sure robust_api_service.py is running!")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_predictions()
