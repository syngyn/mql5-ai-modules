# train_models.py - Script to train all neural network models
import os
import sys
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Import our neural network modules
from neural_networks import EnsemblePredictor, ForexDataPreprocessor

class ModelTrainer:
    """Complete model training pipeline"""
    
    def __init__(self, symbols=['EURUSD', 'GBPUSD', 'USDJPY'], lookback_months=24):
        self.symbols = symbols
        self.lookback_months = lookback_months
        self.preprocessor = ForexDataPreprocessor()
        
    def setup_mt5_connection(self):
        """Initialize MT5 connection for data fetching"""
        if not mt5.initialize():
            print("❌ Failed to initialize MT5")
            return False
        
        print("✅ MT5 connection established")
        print(f"MT5 version: {mt5.version()}")
        
        # Check available symbols
        symbols = mt5.symbols_get()
        available_symbols = [s.name for s in symbols]
        
        for symbol in self.symbols:
            if symbol not in available_symbols:
                print(f"⚠️  Warning: {symbol} not available in MT5")
            else:
                print(f"✅ {symbol} available for training")
        
        return True
    
    def download_historical_data(self, symbol, timeframe=mt5.TIMEFRAME_H1):
        """Download historical data from MT5"""
        print(f"📥 Downloading {symbol} data...")
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.lookback_months * 30)
        
        # Download data
        rates = mt5.copy_rates_range(symbol, timeframe, start_date, end_date)
        
        if rates is None or len(rates) == 0:
            print(f"❌ No data available for {symbol}")
            return None
        
        # Convert to DataFrame
        df = pd.DataFrame(rates)
        df['time'] = pd.to_datetime(df['time'], unit='s')
        df.set_index('time', inplace=True)
        
        # Rename columns
        df = df.rename(columns={
            'open': 'open',
            'high': 'high',
            'low': 'low', 
            'close': 'close',
            'tick_volume': 'volume'
        })
        
        print(f"✅ Downloaded {len(df)} records for {symbol}")
        print(f"   Date range: {df.index[0]} to {df.index[-1]}")
        
        return df[['open', 'high', 'low', 'close', 'volume']]
    
    def train_symbol_models(self, symbol):
        """Train models for a specific symbol"""
        print(f"\n🚀 Training models for {symbol}")
        
        # Download data
        df = self.download_historical_data(symbol)
        if df is None:
            return False
        
        # Data validation
        if len(df) < 5000:
            print(f"⚠️  Warning: Limited data for {symbol} ({len(df)} records)")
            print("   Minimum 5000 records recommended for good training")
        
        # Add technical features
        print("🔧 Engineering features...")
        df_features = self.preprocessor.create_technical_features(df)
        
        # Remove rows with NaN values
        df_features = df_features.dropna()
        
        if len(df_features) < 1000:
            print(f"❌ Insufficient data after feature engineering: {len(df_features)} records")
            return False
        
        print(f"✅ Feature engineering complete: {len(df_features)} valid records")
        
        # Prepare sequential data for LSTM/Transformer
        print("📊 Preparing sequential data...")
        X_seq, y, feature_cols = self.preprocessor.prepare_sequences(df_features)
        
        # Prepare image data for CNN
        print("🖼️  Preparing image data...")
        X_img = self.preprocessor.create_candlestick_images(df_features)
        
        if len(X_seq) == 0 or len(X_img) == 0:
            print("❌ Failed to prepare training data")
            return False
        
        print(f"✅ Data preparation complete:")
        print(f"   Sequential data: {X_seq.shape}")
        print(f"   Image data: {X_img.shape}")
        print(f"   Target data: {y.shape}")
        print(f"   Features: {len(feature_cols)}")
        
        # Train ensemble models
        print("🎯 Training ensemble models...")
        ensemble = EnsemblePredictor()
        
        try:
            ensemble.train_ensemble(X_seq, X_img, y, test_size=0.2)
            
            # Save models
            model_path = f"models/{symbol}/"
            os.makedirs(model_path, exist_ok=True)
            ensemble.save_models(model_path)
            
            print(f"✅ Models trained and saved for {symbol}")
            
            # Test predictions
            print("🔮 Testing predictions...")
            test_seq = X_seq[-5:]
            test_img = X_img[-5:]
            predictions, confidences = ensemble.predict_with_confidence(test_seq, test_img)
            
            print("Sample predictions:")
            for i, (pred, conf) in enumerate(zip(predictions[-3:], confidences[-3:])):
                print(f"   Test {i+1}: {pred[0]:.5f} (confidence: {conf:.3f})")
            
            return True
            
        except Exception as e:
            print(f"❌ Training failed for {symbol}: {e}")
            return False
    
    def train_all_models(self):
        """Train models for all symbols"""
        print("🎯 Starting Neural Network Model Training")
        print("=" * 50)
        
        # Setup MT5 connection
        if not self.setup_mt5_connection():
            return False
        
        successful_trainings = []
        failed_trainings = []
        
        for symbol in self.symbols:
            success = self.train_symbol_models(symbol)
            
            if success:
                successful_trainings.append(symbol)
            else:
                failed_trainings.append(symbol)
        
        # Shutdown MT5
        mt5.shutdown()
        
        # Print summary
        print("\n" + "=" * 50)
        print("🏁 Training Summary")
        print("=" * 50)
        
        if successful_trainings:
            print(f"✅ Successfully trained: {', '.join(successful_trainings)}")
        
        if failed_trainings:
            print(f"❌ Failed to train: {', '.join(failed_trainings)}")
        
        print(f"\nTotal: {len(successful_trainings)}/{len(self.symbols)} symbols completed")
        
        if successful_trainings:
            print("\n🎉 Training completed! You can now start the API service.")
            return True
        else:
            print("\n💥 No models were successfully trained. Please check the errors above.")
            return False
    
    def create_default_models(self):
        """Create default models with synthetic data if MT5 data unavailable"""
        print("🔧 Creating default models with synthetic data...")
        
        # Generate synthetic forex data
        np.random.seed(42)
        dates = pd.date_range('2022-01-01', periods=15000, freq='H')
        
        # Create realistic forex price movements
        returns = np.random.normal(0, 0.0001, 15000)  # Small random returns
        price_base = 1.2000
        prices = price_base + np.cumsum(returns)
        
        # Create OHLC data
        df = pd.DataFrame({
            'open': prices + np.random.normal(0, 0.00005, 15000),
            'high': prices + np.abs(np.random.normal(0, 0.0001, 15000)),
            'low': prices - np.abs(np.random.normal(0, 0.0001, 15000)),
            'close': prices,
            'volume': np.random.randint(100, 1000, 15000)
        }, index=dates)
        
        # Ensure OHLC relationships are correct
        df['high'] = df[['open', 'high', 'close']].max(axis=1)
        df['low'] = df[['open', 'low', 'close']].min(axis=1)
        
        print(f"✅ Created synthetic data: {len(df)} records")
        
        # Train models with synthetic data
        symbol = 'EURUSD'  # Default symbol
        
        df_features = self.preprocessor.create_technical_features(df)
        df_features = df_features.dropna()
        
        X_seq, y, _ = self.preprocessor.prepare_sequences(df_features)
        X_img = self.preprocessor.create_candlestick_images(df_features)
        
        ensemble = EnsemblePredictor()
        ensemble.train_ensemble(X_seq, X_img, y, test_size=0.2)
        
        # Save default models
        os.makedirs("models/", exist_ok=True)
        ensemble.save_models("models/")
        
        print("✅ Default models created and saved")
        print("⚠️  Note: These are trained on synthetic data. Train with real data for better performance.")
        
        return True

def main():
    """Main training function"""
    print("🤖 Neural Network Forex Predictor - Model Training")
    print("=" * 55)
    
    # Parse command line arguments
    symbols = ['EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'AUDUSD']
    lookback_months = 12
    use_synthetic = False
    
    if len(sys.argv) > 1:
        if '--synthetic' in sys.argv:
            use_synthetic = True
        if '--symbols' in sys.argv:
            idx = sys.argv.index('--symbols')
            if idx + 1 < len(sys.argv):
                symbols = sys.argv[idx + 1].split(',')
    
    trainer = ModelTrainer(symbols=symbols, lookback_months=lookback_months)
    
    if use_synthetic:
        print("🔧 Training with synthetic data...")
        success = trainer.create_default_models()
    else:
        print("📊 Training with real market data...")
        success = trainer.train_all_models()
    
    if success:
        print("\n🎯 Next steps:")
        print("1. Run: python neural_api_service.py")
        print("2. Compile the DLL (NeuralNetworkDLL.dll)")  
        print("3. Start your MQL5 Expert Advisor")
        print("4. Monitor the predictions and accuracy!")
    else:
        print("\n💡 Try running with --synthetic flag for demo models:")
        print("   python train_models.py --synthetic")

if __name__ == "__main__":
    main()
