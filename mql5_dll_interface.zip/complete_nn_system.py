# neural_networks.py - Complete Neural Network Implementation
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from sklearn.preprocessing import MinMaxScaler, RobustScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error
import joblib
import ta  # Technical Analysis library
import warnings
warnings.filterwarnings('ignore')

class ForexDataPreprocessor:
    """Handles data preprocessing and feature engineering for forex prediction"""
    
    def __init__(self):
        self.price_scaler = MinMaxScaler()
        self.feature_scaler = RobustScaler()
        self.lookback_window = 60
        
    def create_technical_features(self, df):
        """Create comprehensive technical analysis features"""
        # Price-based features
        df['returns'] = df['close'].pct_change()
        df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
        
        # Moving averages
        df['sma_5'] = ta.trend.sma_indicator(df['close'], window=5)
        df['sma_20'] = ta.trend.sma_indicator(df['close'], window=20)
        df['sma_50'] = ta.trend.sma_indicator(df['close'], window=50)
        df['ema_12'] = ta.trend.ema_indicator(df['close'], window=12)
        df['ema_26'] = ta.trend.ema_indicator(df['close'], window=26)
        
        # Momentum indicators
        df['rsi'] = ta.momentum.rsi(df['close'], window=14)
        df['stoch_k'] = ta.momentum.stoch(df['high'], df['low'], df['close'])
        df['stoch_d'] = ta.momentum.stoch_signal(df['high'], df['low'], df['close'])
        
        # MACD
        df['macd'] = ta.trend.macd_diff(df['close'])
        df['macd_signal'] = ta.trend.macd_signal(df['close'])
        df['macd_hist'] = ta.trend.macd(df['close']) - ta.trend.macd_signal(df['close'])
        
        # Bollinger Bands
        df['bb_high'] = ta.volatility.bollinger_hband(df['close'])
        df['bb_low'] = ta.volatility.bollinger_lband(df['close'])
        df['bb_mid'] = ta.volatility.bollinger_mavg(df['close'])
        df['bb_width'] = (df['bb_high'] - df['bb_low']) / df['bb_mid']
        df['bb_position'] = (df['close'] - df['bb_low']) / (df['bb_high'] - df['bb_low'])
        
        # Volatility
        df['atr'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'])
        df['volatility'] = df['returns'].rolling(window=20).std()
        
        # Volume indicators (if available)
        if 'volume' in df.columns:
            df['volume_sma'] = ta.volume.volume_sma(df['close'], df['volume'])
            df['volume_ratio'] = df['volume'] / df['volume'].rolling(window=20).mean()
        
        # Time-based features
        df['hour'] = pd.to_datetime(df.index).hour
        df['day_of_week'] = pd.to_datetime(df.index).dayofweek
        df['day_of_month'] = pd.to_datetime(df.index).day
        
        # Cyclical encoding for time features
        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['dow_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['dow_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        
        # Support and resistance levels
        df['resistance'] = df['high'].rolling(window=20).max()
        df['support'] = df['low'].rolling(window=20).min()
        df['price_position'] = (df['close'] - df['support']) / (df['resistance'] - df['support'])
        
        return df
    
    def prepare_sequences(self, df, target_columns=['close'], sequence_length=60):
        """Prepare sequential data for neural networks"""
        # Select feature columns (exclude target and non-numeric columns)
        feature_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        feature_cols = [col for col in feature_cols if col not in target_columns]
        
        # Handle missing values
        df = df.fillna(method='ffill').fillna(method='bfill')
        
        # Scale features
        features_scaled = self.feature_scaler.fit_transform(df[feature_cols])
        targets_scaled = self.price_scaler.fit_transform(df[target_columns])
        
        # Create sequences
        X, y = [], []
        for i in range(sequence_length, len(features_scaled)):
            X.append(features_scaled[i-sequence_length:i])
            y.append(targets_scaled[i])
        
        return np.array(X), np.array(y), feature_cols
    
    def create_candlestick_images(self, df, image_size=(64, 64), sequence_length=60):
        """Convert OHLC data to candlestick chart images for CNN"""
        images = []
        
        for i in range(sequence_length, len(df)):
            # Get sequence data
            seq_data = df.iloc[i-sequence_length:i]
            
            # Normalize prices for visualization
            price_range = seq_data[['high', 'low']].max().max() - seq_data[['high', 'low']].min().min()
            normalized_high = (seq_data['high'] - seq_data['low'].min()) / price_range
            normalized_low = (seq_data['low'] - seq_data['low'].min()) / price_range
            normalized_open = (seq_data['open'] - seq_data['low'].min()) / price_range
            normalized_close = (seq_data['close'] - seq_data['low'].min()) / price_range
            
            # Create simple candlestick representation
            image = np.zeros(image_size)
            
            for j, (o, h, l, c) in enumerate(zip(normalized_open, normalized_high, 
                                               normalized_low, normalized_close)):
                x = int(j * image_size[1] / sequence_length)
                
                # Draw candlestick body
                body_top = int(max(o, c) * image_size[0])
                body_bottom = int(min(o, c) * image_size[0])
                wick_top = int(h * image_size[0])
                wick_bottom = int(l * image_size[0])
                
                # Fill body (green for bullish, red for bearish)
                if c > o:  # Bullish
                    image[body_bottom:body_top, x] = 0.8
                else:  # Bearish
                    image[body_bottom:body_top, x] = 0.3
                
                # Draw wicks
                image[wick_bottom:wick_top, x] = 0.5
                
            images.append(image)
        
        return np.array(images).reshape(-1, image_size[0], image_size[1], 1)


class LSTMPredictor:
    """LSTM-based neural network for time series prediction"""
    
    def __init__(self, input_shape, output_dim=1):
        self.input_shape = input_shape
        self.output_dim = output_dim
        self.model = None
        
    def build_model(self):
        """Build LSTM architecture"""
        inputs = Input(shape=self.input_shape)
        
        # LSTM layers with dropout
        x = LSTM(128, return_sequences=True, dropout=0.2, recurrent_dropout=0.2)(inputs)
        x = LayerNormalization()(x)
        x = LSTM(64, return_sequences=True, dropout=0.2, recurrent_dropout=0.2)(x)
        x = LayerNormalization()(x)
        x = LSTM(32, dropout=0.2, recurrent_dropout=0.2)(x)
        
        # Dense layers
        x = Dense(64, activation='relu')(x)
        x = Dropout(0.3)(x)
        x = Dense(32, activation='relu')(x)
        x = Dropout(0.2)(x)
        
        # Output layer
        outputs = Dense(self.output_dim, activation='linear')(x)
        
        self.model = Model(inputs=inputs, outputs=outputs)
        self.model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='huber',
            metrics=['mae']
        )
        
        return self.model
    
    def train(self, X_train, y_train, X_val, y_val, epochs=100):
        """Train the LSTM model"""
        callbacks = [
            EarlyStopping(patience=15, restore_best_weights=True),
            ReduceLROnPlateau(patience=8, factor=0.5, min_lr=1e-7)
        ]
        
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=32,
            callbacks=callbacks,
            verbose=1
        )
        
        return history
    
    def predict(self, X):
        """Make predictions"""
        return self.model.predict(X)


class TransformerPredictor:
    """Transformer-based neural network for time series prediction"""
    
    def __init__(self, input_shape, d_model=128, num_heads=8, num_layers=4, output_dim=1):
        self.input_shape = input_shape
        self.d_model = d_model
        self.num_heads = num_heads
        self.num_layers = num_layers
        self.output_dim = output_dim
        self.model = None
    
    def positional_encoding(self, length, depth):
        """Create positional encoding for transformer"""
        depth = depth // 2
        positions = np.arange(length)[:, np.newaxis]
        depths = np.arange(depth)[np.newaxis, :] / depth
        
        angle_rates = 1 / (10000**depths)
        angle_rads = positions * angle_rates
        
        pos_encoding = np.concatenate([
            np.sin(angle_rads), np.cos(angle_rads)
        ], axis=-1)
        
        return tf.cast(pos_encoding, dtype=tf.float32)
    
    def build_model(self):
        """Build Transformer architecture"""
        inputs = Input(shape=self.input_shape)
        
        # Project to d_model dimensions
        x = Dense(self.d_model)(inputs)
        
        # Add positional encoding
        pos_encoding = self.positional_encoding(self.input_shape[0], self.d_model)
        x = x + pos_encoding
        
        # Transformer layers
        for _ in range(self.num_layers):
            # Multi-head attention
            attn_output = MultiHeadAttention(
                num_heads=self.num_heads, 
                key_dim=self.d_model//self.num_heads
            )(x, x)
            x1 = LayerNormalization()(x + attn_output)
            
            # Feed forward
            ff_output = Dense(self.d_model * 2, activation='relu')(x1)
            ff_output = Dense(self.d_model)(ff_output)
            x = LayerNormalization()(x1 + ff_output)
        
        # Global average pooling
        x = GlobalAveragePooling1D()(x)
        
        # Final layers
        x = Dense(64, activation='relu')(x)
        x = Dropout(0.3)(x)
        x = Dense(32, activation='relu')(x)
        x = Dropout(0.2)(x)
        
        outputs = Dense(self.output_dim, activation='linear')(x)
        
        self.model = Model(inputs=inputs, outputs=outputs)
        self.model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='huber',
            metrics=['mae']
        )
        
        return self.model
    
    def train(self, X_train, y_train, X_val, y_val, epochs=100):
        """Train the Transformer model"""
        callbacks = [
            EarlyStopping(patience=15, restore_best_weights=True),
            ReduceLROnPlateau(patience=8, factor=0.5, min_lr=1e-7)
        ]
        
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=16,
            callbacks=callbacks,
            verbose=1
        )
        
        return history
    
    def predict(self, X):
        """Make predictions"""
        return self.model.predict(X)


class CNNPredictor:
    """CNN-based neural network for pattern recognition in price charts"""
    
    def __init__(self, input_shape, output_dim=1):
        self.input_shape = input_shape
        self.output_dim = output_dim
        self.model = None
    
    def build_model(self):
        """Build CNN architecture for candlestick pattern recognition"""
        inputs = Input(shape=self.input_shape)
        
        # Convolutional layers
        x = Conv2D(32, (3, 3), activation='relu', padding='same')(inputs)
        x = BatchNormalization()(x)
        x = MaxPooling2D((2, 2))(x)
        
        x = Conv2D(64, (3, 3), activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = MaxPooling2D((2, 2))(x)
        
        x = Conv2D(128, (3, 3), activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = MaxPooling2D((2, 2))(x)
        
        x = Conv2D(256, (3, 3), activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = GlobalAveragePooling2D()(x)
        
        # Dense layers
        x = Dense(128, activation='relu')(x)
        x = Dropout(0.3)(x)
        x = Dense(64, activation='relu')(x)
        x = Dropout(0.2)(x)
        
        outputs = Dense(self.output_dim, activation='linear')(x)
        
        self.model = Model(inputs=inputs, outputs=outputs)
        self.model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='huber',
            metrics=['mae']
        )
        
        return self.model
    
    def train(self, X_train, y_train, X_val, y_val, epochs=100):
        """Train the CNN model"""
        callbacks = [
            EarlyStopping(patience=15, restore_best_weights=True),
            ReduceLROnPlateau(patience=8, factor=0.5, min_lr=1e-7)
        ]
        
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=16,
            callbacks=callbacks,
            verbose=1
        )
        
        return history
    
    def predict(self, X):
        """Make predictions"""
        return self.model.predict(X)


class EnsemblePredictor:
    """Ensemble combining LSTM, Transformer, and CNN predictions"""
    
    def __init__(self):
        self.lstm_model = None
        self.transformer_model = None
        self.cnn_model = None
        self.weights = np.array([0.4, 0.35, 0.25])  # LSTM, Transformer, CNN
        self.confidence_model = None
        
    def train_ensemble(self, X_seq, X_img, y, test_size=0.2):
        """Train all three models"""
        # Split data
        split_idx = int(len(X_seq) * (1 - test_size))
        
        X_seq_train, X_seq_val = X_seq[:split_idx], X_seq[split_idx:]
        X_img_train, X_img_val = X_img[:split_idx], X_img[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        # Train LSTM
        print("Training LSTM...")
        self.lstm_model = LSTMPredictor(X_seq.shape[1:])
        self.lstm_model.build_model()
        self.lstm_model.train(X_seq_train, y_train, X_seq_val, y_val)
        
        # Train Transformer
        print("Training Transformer...")
        self.transformer_model = TransformerPredictor(X_seq.shape[1:])
        self.transformer_model.build_model()
        self.transformer_model.train(X_seq_train, y_train, X_seq_val, y_val)
        
        # Train CNN
        print("Training CNN...")
        self.cnn_model = CNNPredictor(X_img.shape[1:])
        self.cnn_model.build_model()
        self.cnn_model.train(X_img_train, y_train, X_img_val, y_val)
        
        # Train confidence estimation model
        self._train_confidence_model(X_seq_val, X_img_val, y_val)
        
        return self
    
    def _train_confidence_model(self, X_seq_val, X_img_val, y_val):
        """Train a model to estimate prediction confidence"""
        # Get predictions from all models
        lstm_pred = self.lstm_model.predict(X_seq_val)
        transformer_pred = self.transformer_model.predict(X_seq_val)
        cnn_pred = self.cnn_model.predict(X_img_val)
        
        # Calculate prediction agreement as features for confidence
        features = []
        confidences = []
        
        for i in range(len(lstm_pred)):
            # Calculate prediction variance as confidence indicator
            preds = [lstm_pred[i][0], transformer_pred[i][0], cnn_pred[i][0]]
            pred_mean = np.mean(preds)
            pred_std = np.std(preds)
            
            # Calculate actual error
            actual_error = abs(y_val[i][0] - pred_mean)
            confidence = max(0.1, 1.0 - (actual_error / abs(y_val[i][0])))
            
            features.append([pred_mean, pred_std, *preds])
            confidences.append(confidence)
        
        # Simple confidence model
        from sklearn.ensemble import RandomForestRegressor
        self.confidence_model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.confidence_model.fit(np.array(features), np.array(confidences))
    
    def predict_with_confidence(self, X_seq, X_img):
        """Make ensemble predictions with confidence scores"""
        # Get individual predictions
        lstm_pred = self.lstm_model.predict(X_seq)
        transformer_pred = self.transformer_model.predict(X_seq)
        cnn_pred = self.cnn_model.predict(X_img)
        
        # Ensemble prediction
        ensemble_pred = (self.weights[0] * lstm_pred + 
                        self.weights[1] * transformer_pred + 
                        self.weights[2] * cnn_pred)
        
        # Estimate confidence
        confidences = []
        for i in range(len(ensemble_pred)):
            preds = [lstm_pred[i][0], transformer_pred[i][0], cnn_pred[i][0]]
            pred_mean = ensemble_pred[i][0]
            pred_std = np.std(preds)
            
            if self.confidence_model:
                confidence_features = [[pred_mean, pred_std, *preds]]
                confidence = self.confidence_model.predict(confidence_features)[0]
            else:
                # Simple confidence based on prediction agreement
                confidence = max(0.1, 1.0 - min(pred_std / abs(pred_mean), 0.9))
            
            confidences.append(confidence)
        
        return ensemble_pred, np.array(confidences)
    
    def save_models(self, base_path="models/"):
        """Save all trained models"""
        import os
        os.makedirs(base_path, exist_ok=True)
        
        self.lstm_model.model.save(f"{base_path}lstm_model.h5")
        self.transformer_model.model.save(f"{base_path}transformer_model.h5")
        self.cnn_model.model.save(f"{base_path}cnn_model.h5")
        
        if self.confidence_model:
            joblib.dump(self.confidence_model, f"{base_path}confidence_model.pkl")
        
        # Save ensemble weights
        np.save(f"{base_path}ensemble_weights.npy", self.weights)
    
    def load_models(self, base_path="models/"):
        """Load pre-trained models"""
        from tensorflow.keras.models import load_model
        
        # Create model instances
        self.lstm_model = LSTMPredictor((60, 50))  # Adjust input shape as needed
        self.transformer_model = TransformerPredictor((60, 50))
        self.cnn_model = CNNPredictor((64, 64, 1))
        
        # Load trained models
        self.lstm_model.model = load_model(f"{base_path}lstm_model.h5")
        self.transformer_model.model = load_model(f"{base_path}transformer_model.h5")
        self.cnn_model.model = load_model(f"{base_path}cnn_model.h5")
        
        # Load confidence model
        try:
            self.confidence_model = joblib.load(f"{base_path}confidence_model.pkl")
        except:
            self.confidence_model = None
        
        # Load ensemble weights
        try:
            self.weights = np.load(f"{base_path}ensemble_weights.npy")
        except:
            self.weights = np.array([0.4, 0.35, 0.25])


def train_complete_system():
    """Example of how to train the complete system"""
    # Load your forex data (replace with your data source)
    # df = pd.read_csv('EURUSD_H1.csv')  # Your data
    
    # For demonstration, create sample data
    np.random.seed(42)
    dates = pd.date_range('2020-01-01', periods=10000, freq='H')
    df = pd.DataFrame({
        'open': np.random.randn(10000).cumsum() + 1.2000,
        'high': np.random.randn(10000).cumsum() + 1.2010,
        'low': np.random.randn(10000).cumsum() + 1.1990,
        'close': np.random.randn(10000).cumsum() + 1.2000,
        'volume': np.random.randint(100, 1000, 10000)
    }, index=dates)
    
    # Ensure OHLC relationships are correct
    df['high'] = df[['open', 'high', 'close']].max(axis=1) + 0.001
    df['low'] = df[['open', 'low', 'close']].min(axis=1) - 0.001
    
    # Initialize preprocessor
    preprocessor = ForexDataPreprocessor()
    
    # Add technical features
    df_features = preprocessor.create_technical_features(df)
    
    # Prepare sequential data
    X_seq, y, feature_cols = preprocessor.prepare_sequences(df_features)
    
    # Prepare image data for CNN
    X_img = preprocessor.create_candlestick_images(df_features)
    
    print(f"Sequential data shape: {X_seq.shape}")
    print(f"Image data shape: {X_img.shape}")
    print(f"Target shape: {y.shape}")
    print(f"Number of features: {len(feature_cols)}")
    
    # Train ensemble
    ensemble = EnsemblePredictor()
    ensemble.train_ensemble(X_seq, X_img, y)
    
    # Save models
    ensemble.save_models()
    
    # Test prediction
    test_seq = X_seq[-10:]
    test_img = X_img[-10:]
    predictions, confidences = ensemble.predict_with_confidence(test_seq, test_img)
    
    print("Sample predictions:")
    for i, (pred, conf) in enumerate(zip(predictions[-5:], confidences[-5:])):
        print(f"Prediction {i+1}: {pred[0]:.5f}, Confidence: {conf:.3f}")
    
    return ensemble, preprocessor


if __name__ == "__main__":
    # Train the complete system
    ensemble, preprocessor = train_complete_system()
    print("Training completed!")
