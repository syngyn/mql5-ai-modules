# setup_and_start.py - Complete setup script for Neural Network EA
import os
import sys
import subprocess
import json
from pathlib import Path

def check_dependencies():
    """Check if all required Python packages are installed"""
    required_packages = [
        'tensorflow>=2.10.0',
        'pandas>=1.5.0',
        'numpy>=1.21.0',
        'scikit-learn>=1.1.0',
        'flask>=2.0.0',
        'MetaTrader5>=5.0.35',
        'ta>=0.10.2',
        'schedule>=1.1.0',
        'requests>=2.28.0'
    ]
    
    missing_packages = []
    
    print("🔍 Checking Python dependencies...")
    
    for package in required_packages:
        try:
            package_name = package.split('>=')[0]
            __import__(package_name)
            print(f"✅ {package_name}")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package_name}")
    
    if missing_packages:
        print(f"\n📦 Missing packages: {', '.join(missing_packages)}")
        print("\nInstalling missing packages...")
        
        for package in missing_packages:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", package])
                print(f"✅ Installed {package}")
            except subprocess.CalledProcessError:
                print(f"❌ Failed to install {package}")
                return False
    
    print("✅ All dependencies are installed!")
    return True

def create_project_structure():
    """Create necessary directories and files"""
    print("📁 Creating project structure...")
    
    directories = [
        'models',
        'data',
        'logs',
        'config'
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")
    
    # Create configuration file
    config = {
        "api_settings": {
            "host": "127.0.0.1",
            "port": 5000,
            "debug": False
        },
        "model_settings": {
            "retrain_interval_days": 7,
            "prediction_update_interval_minutes": 5,
            "confidence_threshold": 0.65,
            "lookback_months": 12
        },
        "trading_settings": {
            "default_symbols": ["EURUSD", "GBPUSD", "USDJPY"],
            "max_positions": 1,
            "risk_per_trade": 0.02
        }
    }
    
    with open('config/settings.json', 'w') as f:
        json.dump(config, f, indent=2)
    
    print("✅ Created configuration file")

def create_batch_files():
    """Create convenient batch files for Windows"""
    if os.name == 'nt':  # Windows
        # Training batch file
        train_bat = """@echo off
echo Starting Neural Network Model Training...
python train_models.py
pause
"""
        with open('train_models.bat', 'w') as f:
            f.write(train_bat)
        
        # API service batch file
        api_bat = """@echo off
echo Starting Neural Network API Service...
python neural_api_service.py
pause
"""
        with open('start_api_service.bat', 'w') as f:
            f.write(api_bat)
        
        print("✅ Created Windows batch files")

def display_setup_instructions():
    """Display complete setup instructions"""
    instructions = """
🤖 NEURAL NETWORK FOREX EA - COMPLETE SETUP GUIDE
================================================================

📋 SYSTEM REQUIREMENTS:
   • Python 3.8 or higher
   • MetaTrader 5 terminal
   • Visual Studio (for DLL compilation)
   • Minimum 8GB RAM recommended

🔧 SETUP STEPS:

1. INSTALL METATRADER 5:
   • Download from https://www.metatrader5.com/
   • Install and set up your trading account
   • Enable algorithmic trading (Tools → Options → Expert Advisors)

2. TRAIN THE NEURAL NETWORKS:
   Windows: Double-click train_models.bat
   Command: python train_models.py
   
   Options:
   • --synthetic: Use synthetic data for demo
   • --symbols EURUSD,GBPUSD: Specify symbols to train

3. COMPILE THE DLL (Windows + Visual Studio):
   • Open NeuralNetworkDLL.cpp in Visual Studio
   • Install jsoncpp library (vcpkg install jsoncpp)
   • Build as Release x64 DLL
   • Copy NeuralNetworkDLL.dll to MT5's Libraries folder

4. START THE API SERVICE:
   Windows: Double-click start_api_service.bat
   Command: python neural_api_service.py

5. INSTALL THE MQL5 EXPERT ADVISOR:
   • Copy NeuralNetworkEA.mq5 to MT5's Experts folder
   • Compile in MetaEditor
   • Attach to chart with your desired settings

⚙️  CONFIGURATION:
   • Edit config/settings.json for custom settings
   • Adjust confidence thresholds and risk parameters
   • Configure symbols and timeframes

📊 MONITORING:
   • API Health: http://127.0.0.1:5000/health
   • Model Info: http://127.0.0.1:5000/models/info
   • Accuracy Stats: http://127.0.0.1:5000/accuracy

🔄 MAINTENANCE:
   • Models retrain automatically every 7 days
   • Monitor accuracy through the API endpoints
   • Update training data regularly for best performance

⚠️  IMPORTANT NOTES:
   • Start with demo account first
   • Monitor performance closely
   • Machine learning predictions are not guaranteed
   • Use proper risk management always

📞 TROUBLESHOOTING:
   • Check Python service is running on port 5000
   • Verify DLL is in correct MT5 folder
   • Ensure firewall allows local connections
   • Check MT5 logs for error messages

================================================================
"""
    print(instructions)

def run_quick_test():
    """Run a quick test to verify everything works"""
    print("🧪 Running quick system test...")
    
    try:
        # Test imports
        import tensorflow as tf
        import pandas as pd
        import numpy as np
        print("✅ Core libraries import successfully")
        
        # Test TensorFlow
        print(f"✅ TensorFlow version: {tf.__version__}")
        
        # Test if GPU is available
        if tf.config.list_physical_devices('GPU'):
            print("✅ GPU detected - training will be faster")
        else:
            print("ℹ️  CPU only - training will be slower but functional")
        
        # Try to import our modules
        try:
            from neural_networks import EnsemblePredictor, ForexDataPreprocessor
            print("✅ Neural network modules imported successfully")
        except ImportError as e:
            print(f"❌ Failed to import neural network modules: {e}")
            return False
        
        # Test MetaTrader5 connection
        try:
            import MetaTrader5 as mt5
            if mt5.initialize():
                print("✅ MT5 connection test successful")
                mt5.shutdown()
            else:
                print("⚠️  MT5 connection failed - ensure MT5 is installed and running")
        except ImportError:
            print("❌ MetaTrader5 package not found")
            return False
        
        print("✅ All tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ System test failed: {e}")
        return False

def main():
    """Main setup function"""
    print("🚀 Neural Network Forex EA Setup")
    print("=" * 40)
    
    # Check dependencies
    if not check_dependencies():
        print("❌ Dependency check failed. Please install missing packages manually.")
        return
    
    # Create project structure
    create_project_structure()
    
    # Create batch files for Windows
    create_batch_files()
    
    # Run system test
    if not run_quick_test():
        print("⚠️  System test failed. Some components may not work correctly.")
    
    # Display instructions
    display_setup_instructions()
    
    # Ask user what to do next
    print("🎯 What would you like to do?")
    print("1. Train models with real data")
    print("2. Train models with synthetic data (demo)")
    print("3. Just start API service (models must exist)")
    print("4. Exit and setup manually")
    
    try:
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            print("Starting model training with real data...")
            import train_models
            trainer = train_models.ModelTrainer()
            trainer.train_all_models()
            
        elif choice == '2':
            print("Starting model training with synthetic data...")
            import train_models
            trainer = train_models.ModelTrainer()
            trainer.create_default_models()
            
        elif choice == '3':
            print("Starting API service...")
            import neural_api_service
            # This will start the Flask app
            
        elif choice == '4':
            print("Setup complete. Follow the instructions above.")
            
        else:
            print("Invalid choice. Setup complete. Follow the instructions above.")
            
    except KeyboardInterrupt:
        print("\n\nSetup interrupted by user.")
    except Exception as e:
        print(f"\nError: {e}")
        print("Please follow the manual setup instructions above.")

if __name__ == "__main__":
    main()
