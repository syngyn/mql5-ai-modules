# neural_service.py
import tensorflow as tf
import numpy as np
from flask import Flask, request, jsonify
import joblib

class ForexPredictor:
    def __init__(self):
        self.lstm_model = tf.keras.models.load_model('lstm_model.h5')
        self.transformer_model = tf.keras.models.load_model('transformer_model.h5')
        self.cnn_model = tf.keras.models.load_model('cnn_model.h5')
        self.scaler = joblib.load('feature_scaler.pkl')
    
    def predict(self, features):
        scaled_features = self.scaler.transform(features)
        
        lstm_pred = self.lstm_model.predict(scaled_features)
        transformer_pred = self.transformer_model.predict(scaled_features)
        cnn_pred = self.cnn_model.predict(scaled_features)
        
        # Ensemble prediction with dynamic weights
        ensemble_pred = (0.4 * lstm_pred + 
                        0.35 * transformer_pred + 
                        0.25 * cnn_pred)
        
        return ensemble_pred

app = Flask(__name__)
predictor = ForexPredictor()

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    features = np.array(data['features']).reshape(1, -1)
    prediction = predictor.predict(features)
    return jsonify({'prediction': prediction.tolist()})