#!/usr/bin/env python3
# samformer_infer.py
# Inference runner for the MQL5 EA. Polls a requests folder and writes responses atomically.

import os, json, time, math, threading, traceback
from typing import Dict, Any, List, Optional

# ---- Config ----
USE_TORCH = False  # Set True if you actually load a SAMformer checkpoint
CHECKPOINT_PATH = ""  # path to your trained model checkpoint (if any)

# Folders (match EA)
# Common files root example:
#   %APPDATA%\MetaQuotes\Terminal\Common\Files\SAMformer\{requests,responses}
BASE_FOLDER = os.path.join(os.path.expanduser("~"),
                           "AppData","Roaming","MetaQuotes","Terminal","Common","Files","SAMformer")
REQ_DIR = os.path.join(BASE_FOLDER, "requests")
RSP_DIR = os.path.join(BASE_FOLDER, "responses")

POLL_INTERVAL_SEC = 0.20

# ---- Optional Torch model (SAMformer-like stub) ----
if USE_TORCH:
    import torch
    import torch.nn as nn

    class TinySAMFormerLike(nn.Module):
        """
        Minimal 'SAMformer-ish' forecaster stub.
        Input: sequence of close (and optionally OHLCV) -> predict 3-step deltas
        This is a lightweight placeholder unless you load a real checkpoint.
        """
        def __init__(self, in_features: int = 1, d_model: int = 64, nhead: int = 4, nlayers: int = 2):
            super().__init__()
            self.enc = nn.Linear(in_features, d_model)
            encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, batch_first=True)
            self.tr = nn.TransformerEncoder(encoder_layer, num_layers=nlayers)
            self.head = nn.Sequential(
                nn.AdaptiveAvgPool1d(8),  # squeeze time
                # We'll flatten in forward
            )
            self.fc = nn.Linear(d_model*8, 3)  # predict 3 deltas

        def forward(self, x):  # x: (B, T, C)
            x = self.enc(x)              # (B,T,d_model)
            x = self.tr(x)               # (B,T,d_model)
            # pool over time: swap to (B,d_model,T)
            x = x.transpose(1,2)         # (B,d_model,T)
            x = self.head(x)             # (B,d_model,8)
            x = x.reshape(x.size(0), -1) # (B,d_model*8)
            out = self.fc(x)             # (B,3)
            return out

    _MODEL: Optional[nn.Module] = None

    def load_model(in_features: int) -> nn.Module:
        global _MODEL
        if _MODEL is None:
            model = TinySAMFormerLike(in_features=in_features)
            if CHECKPOINT_PATH and os.path.isfile(CHECKPOINT_PATH):
                state = torch.load(CHECKPOINT_PATH, map_location="cpu")
                model.load_state_dict(state)
            model.eval()
            _MODEL = model
        return _MODEL

# ---- Utils ----
def ensure_dirs():
    os.makedirs(REQ_DIR, exist_ok=True)
    os.makedirs(RSP_DIR, exist_ok=True)

def atomic_write_json(path: str, payload: Dict[str, Any]) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, path)

def robust_read_json(path: str) -> Optional[Dict[str, Any]]:
    # Avoid partial reads: small retry on JSONDecodeError
    for _ in range(3):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError:
            time.sleep(0.05)
        except Exception:
            break
    return None

def ema(values: List[float], period: int = 20) -> float:
    if not values:
        return 0.0
    alpha = 2.0 / (period + 1.0)
    s = values[0]
    for v in values[1:]:
        s = alpha * v + (1 - alpha) * s
    return s

def linreg_slope(y: List[float]) -> float:
    # x=0..N-1
    N = len(y)
    if N < 2:
        return 0.0
    sx = (N - 1) * N / 2.0
    sxx = (N - 1) * N * (2 * N - 1) / 6.0
    sy = sum(y)
    sxy = sum(i * v for i, v in enumerate(y))
    denom = (N * sxx - sx * sx)
    if denom == 0:
        return 0.0
    return (N * sxy - sx * sy) / denom

def baseline_forecast(close_series: List[float], horizon: int = 3) -> List[float]:
    # EMA + slope projection (like EA)
    if not close_series:
        return [0.0] * horizon
    N = min(60, len(close_series))
    tail = close_series[-N:]
    em = ema(tail, period=20)
    slope = linreg_slope(tail)
    # project absolute prices by adding slope steps to EMA anchor
    return [em + slope * (i + 1) for i in range(horizon)]

def infer_with_model(features: Dict[str, Any]) -> List[float]:
    """
    If USE_TORCH: run TinySAMFormerLike on the provided sequence and return 3-step **absolute price** preds.
    Else: baseline.
    """
    close = features.get("close", [])
    if not close:
        return [0.0, 0.0, 0.0]

    if not USE_TORCH:
        return baseline_forecast(close, horizon=3)

    import numpy as np
    # Build input (T,C)
    if features.get("features") == "ohlcv":
        o = features.get("open", [])
        h = features.get("high", [])
        l = features.get("low", [])
        v = features.get("volume", [])
        # Stack OHLCV; lengths should match close
        T = min(len(close), len(o), len(h), len(l), len(v))
        if T < 10:  # too short
            return baseline_forecast(close, horizon=3)
        data = np.stack([o[-T:], h[-T:], l[-T:], close[-T:], v[-T:]], axis=1)  # (T,5)
    else:
        data = [[x] for x in close]  # (T,1)
        T = len(data)
        if T < 10:
            return baseline_forecast(close, horizon=3)

    # Simple normalization around last close
    last_close = float(close[-1])
    if last_close == 0:
        return baseline_forecast(close, horizon=3)
    arr = ( ( (data if isinstance(data, list) else data) ) )
    arr = np.array(arr, dtype=float) / last_close  # scale to ~1.0
    x = arr[None, ...]  # (1,T,C)

    import torch
    x = torch.tensor(x, dtype=torch.float32)
    model = load_model(in_features=x.shape[-1])
    with torch.no_grad():
        deltas = model(x).cpu().numpy().reshape(-1)  # 3 deltas (scaled)
    # Convert back to absolute prices
    preds = [last_close * (1.0 + float(d)) for d in deltas[:3]]
    return preds

def make_confidence(preds: List[float], close_last: float) -> List[float]:
    # Heuristic: larger move -> lower conf; cap in [0.5,0.9]
    if close_last <= 0:
        return [0.6, 0.6, 0.6]
    confs = []
    for i, p in enumerate(preds):
        rel = abs(p - close_last) / close_last
        c = 0.9 - min(rel * 3.0, 0.4)  # 0.9 down to 0.5
        confs.append(round(max(0.5, min(0.9, c)), 2))
    return confs

def handle_request(req_path: str):
    payload = robust_read_json(req_path)
    if payload is None:
        # Give up on this file; EA will timeout and fallback
        return

    symbol = payload.get("symbol", "UNKNOWN")
    timeframe = payload.get("timeframe", "D1")
    horizon = int(payload.get("horizon", 3))
    lookback = int(payload.get("lookback", 0))
    features = payload  # contains close, maybe ohlcv arrays

    # Predict
    preds = infer_with_model(features)
    close_arr = features.get("close", [])
    last_close = float(close_arr[-1]) if close_arr else 0.0
    conf = make_confidence(preds, last_close)

    # response file path
    req_name = os.path.basename(req_path)               # request_...json
    rsp_name = req_name.replace("request_", "response_")
    rsp_path = os.path.join(RSP_DIR, rsp_name)

    # Write atomically
    out = {"preds": [float(preds[0]), float(preds[1]), float(preds[2])],
           "conf":  [float(conf[0]),  float(conf[1]),  float(conf[2])]}
    atomic_write_json(rsp_path, out)

    # Cleanup request after successful response to reduce clutter
    try:
        os.remove(req_path)
    except Exception:
        pass

def main():
    ensure_dirs()
    print(f"[samformer_infer] Watching:\n  REQ: {REQ_DIR}\n  RSP: {RSP_DIR}\n  Torch: {USE_TORCH}")
    seen = set()
    while True:
        try:
            files = [f for f in os.listdir(REQ_DIR) if f.startswith("request_") and f.endswith(".json")]
            # Process oldest first to keep ordering reasonable
            files.sort(key=lambda x: os.path.getmtime(os.path.join(REQ_DIR, x)))
            for fname in files:
                fpath = os.path.join(REQ_DIR, fname)
                # Double-check file is not still being written: size stable across a short delay
                try:
                    s1 = os.path.getsize(fpath)
                    time.sleep(0.02)
                    s2 = os.path.getsize(fpath)
                    if s1 != s2:
                        continue
                except FileNotFoundError:
                    continue
                handle_request(fpath)
        except Exception as e:
            print("[samformer_infer] ERROR:", e)
            traceback.print_exc()
        time.sleep(POLL_INTERVAL_SEC)

if __name__ == "__main__":
    main()