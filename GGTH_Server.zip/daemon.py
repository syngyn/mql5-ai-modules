import os
import json
import time
import sys
import numpy as np
import torch
import joblib
from train import LSTMModel, Config
from utils import generate_probabilities, generate_confidence

# --- GLOBAL VARIABLES & CONFIG ---
cfg = Config()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = None
feature_scaler = None
label_scaler = None

# ==============================================================================
# === STEP 1: SET THE ABSOLUTE PATH TO YOUR COMMUNICATION FOLDER ===
# This path MUST match the one you will set in the MQL5 EA's inputs.
# Use double backslashes `\\` or a raw string `r"..."`.
TERMINAL_COMMON_FILES = r"C:\Users\jason\Desktop\python_backend"
# ==============================================================================


# --- HELPER FUNCTIONS ---

def verify_paths_and_permissions(path):
    """Checks if the path exists and is writable."""
    print(f"[INFO] Verifying communication folder: {path}")
    if not os.path.isdir(path):
        print(f"[FATAL] The specified folder does not exist: '{path}'")
        print("   - Please create this folder manually and try again.")
        return False
    
    # Test write permissions
    try:
        test_file_path = os.path.join(path, f"daemon_permission_test_{int(time.time())}.tmp")
        with open(test_file_path, 'w') as f:
            f.write("test")
        os.remove(test_file_path)
        print("[SUCCESS] Path is valid and write permissions are confirmed.")
        return True
    except Exception as e:
        print(f"[FATAL] Permission error in communication folder: {e}")
        print("   - Please try running this script as an Administrator.")
        return False

def load_models_and_scalers():
    global model, feature_scaler, label_scaler
    print("\n[INFO] Attempting to load models and scalers...")
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(script_dir, cfg.MODEL_PATH)
        feature_scaler_path = os.path.join(script_dir, cfg.FEATURE_SCALER_PATH)
        label_scaler_path = os.path.join(script_dir, cfg.LABEL_SCALER_PATH)

        for path in [model_path, feature_scaler_path, label_scaler_path]:
            if not os.path.exists(path):
                print(f"[FATAL] Required file not found: {path}")
                print("   - Please run 'python train.py' to generate model files.")
                return False

        model = LSTMModel(input_dim=cfg.FEATURE_COUNT, hidden_dim=100, output_dim=cfg.PREDICTION_STEPS, n_layers=2)
        model.load_state_dict(torch.load(model_path, map_location=device))
        model.to(device)
        model.eval()
        print(f"[DEBUG] Model '{cfg.MODEL_PATH}' loaded successfully.")
        
        feature_scaler = joblib.load(feature_scaler_path)
        print(f"[DEBUG] Feature scaler '{cfg.FEATURE_SCALER_PATH}' loaded successfully.")

        label_scaler = joblib.load(label_scaler_path)
        print(f"[DEBUG] Label scaler '{cfg.LABEL_SCALER_PATH}' loaded successfully.")
        
        print("[SUCCESS] All models and scalers loaded.")
        return True
    except Exception as e:
        print(f"[FATAL] An error occurred while loading models: {e}")
        import traceback
        traceback.print_exc()
        return False

def process_request(request_data):
    try:
        features_flat = request_data.get('features', [])
        current_price = request_data.get('current_price', 0)
        atr_val = request_data.get('atr', 0)
        if not features_flat or len(features_flat) != (cfg.SEQ_LEN * cfg.FEATURE_COUNT):
            return {"status": "error", "message": "Invalid or missing features array."}

        features_np = np.array(features_flat).reshape(cfg.SEQ_LEN, cfg.FEATURE_COUNT)
        features_scaled = feature_scaler.transform(features_np)
        features_tensor = torch.tensor([features_scaled], dtype=torch.float32).to(device)
        
        with torch.no_grad():
            prediction_scaled = model(features_tensor).cpu().numpy()
        
        predicted_prices = label_scaler.inverse_transform(prediction_scaled)[0]
        buy_prob, sell_prob = generate_probabilities(predicted_prices, current_price)
        confidence = generate_confidence(predicted_prices, atr_val)

        return {"status": "success", "predicted_prices": predicted_prices.tolist(), "confidence_score": confidence, "buy_probability": buy_prob, "sell_probability": sell_prob}
    except Exception as e:
        print(f"[ERROR] inside process_request: {e}")
        import traceback
        traceback.print_exc()
        return {"status": "error", "message": f"Daemon processing error: {e}"}

def watch_for_requests():
    print(f"\n[INFO] DAEMON IS RUNNING. Watching for requests in:")
    print(f"   >> {TERMINAL_COMMON_FILES}")
    processed_requests = set()
    while True:
        try:
            request_files = [f for f in os.listdir(TERMINAL_COMMON_FILES) if f.startswith('request_') and f.endswith('.json')]

            for filename in request_files:
                if filename in processed_requests: continue
                
                request_path = os.path.join(TERMINAL_COMMON_FILES, filename)
                response_path = os.path.join(TERMINAL_COMMON_FILES, filename.replace('request_', 'response_'))
                print(f"\n[INFO] Processing new request: {filename}")
                
                request_data = None
                for _ in range(5):
                    try:
                        with open(request_path, 'r') as f:
                            request_data = json.load(f)
                        break
                    except (IOError, json.JSONDecodeError) as e:
                        time.sleep(0.1)
                
                if not request_data:
                    print(f"[ERROR] Failed to read request file {filename} after retries. Deleting.")
                    try: os.remove(request_path)
                    except: pass
                    processed_requests.add(filename)
                    continue

                response_data = process_request(request_data)
                
                with open(response_path, 'w') as f:
                    json.dump(response_data, f, indent=2)
                
                print(f"[SUCCESS] Response sent for {request_data.get('request_id', 'N/A')}")
                
                try: 
                    os.remove(request_path)
                except OSError as e: print(f"[WARNING] Could not remove request file: {e}")
                
                processed_requests.add(filename)

            if len(processed_requests) > 200: processed_requests.clear()
            time.sleep(0.2)
        except Exception as e:
            print(f"[FATAL] An unexpected error occurred in the main watch loop: {e}")
            time.sleep(5)

if __name__ == "__main__":
    if not verify_paths_and_permissions(TERMINAL_COMMON_FILES):
        print("\n--- DAEMON SHUTDOWN DUE TO PATH/PERMISSION ERRORS ---")
        input("Press Enter to exit...")
        sys.exit(1)

    if not load_models_and_scalers():
        print("\n--- DAEMON SHUTDOWN DUE TO MODEL LOADING ERRORS ---")
        input("Press Enter to exit...")
        sys.exit(1)
        
    watch_for_requests()