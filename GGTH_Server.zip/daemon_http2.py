# daemon_http.py - FIXED VERSION (eliminates PyTorch warning)

import os
import sys
import json
import logging
import traceback
import numpy as np
import torch
import joblib
from datetime import datetime
from flask import Flask, request, jsonify
import warnings

# Suppress the PyTorch warning you're seeing
warnings.filterwarnings('ignore', category=UserWarning, message='.*Creating a tensor from a list.*')

# Import your model and config
try:
    from train import LSTMModel, Config
except ImportError as e:
    print(f"❌ Error importing train modules: {e}")
    print("Make sure train.py is in the same directory as daemon_http.py")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class PredictionDaemon:
    def __init__(self):
        self.config = Config()
        self.device = torch.device("cpu")  # Use CPU for daemon
        self.model = None
        self.feature_scaler = None
        self.label_scaler = None
        self.model_loaded = False
        
        # Load model and scalers
        self.load_model()
    
    def load_model(self):
        """Load the trained model and scalers"""
        try:
            logger.info("Loading model and scalers...")
            
            # Check if files exist
            if not os.path.exists(self.config.MODEL_PATH):
                raise FileNotFoundError(f"Model file not found: {self.config.MODEL_PATH}")
            if not os.path.exists(self.config.FEATURE_SCALER_PATH):
                raise FileNotFoundError(f"Feature scaler not found: {self.config.FEATURE_SCALER_PATH}")
            if not os.path.exists(self.config.LABEL_SCALER_PATH):
                raise FileNotFoundError(f"Label scaler not found: {self.config.LABEL_SCALER_PATH}")
            
            # Load model
            self.model = LSTMModel(
                input_dim=self.config.FEATURE_COUNT,
                hidden_dim=100,
                output_dim=self.config.PREDICTION_STEPS,
                n_layers=2
            )
            self.model.load_state_dict(torch.load(self.config.MODEL_PATH, map_location=self.device))
            self.model.to(self.device)
            self.model.eval()
            
            # Load scalers
            self.feature_scaler = joblib.load(self.config.FEATURE_SCALER_PATH)
            self.label_scaler = joblib.load(self.config.LABEL_SCALER_PATH)
            
            self.model_loaded = True
            logger.info("✅ Model and scalers loaded successfully!")
            
        except Exception as e:
            logger.error(f"❌ Error loading model: {e}")
            logger.error(traceback.format_exc())
            self.model_loaded = False
    
    def predict(self, features, current_price, atr_value):
        """
        FIXED: Generate predictions with optimized tensor creation
        """
        if not self.model_loaded:
            raise RuntimeError("Model not loaded")
        
        try:
            # Validate input
            expected_feature_count = self.config.FEATURE_COUNT * self.config.SEQ_LEN
            if len(features) != expected_feature_count:
                raise ValueError(f"Expected {expected_feature_count} features, got {len(features)}")
            
            # Reshape features to sequence format
            feature_sequence = np.array(features).reshape(self.config.SEQ_LEN, self.config.FEATURE_COUNT)
            
            # Scale features
            features_scaled = self.feature_scaler.transform(feature_sequence)
            
            # FIXED: Convert to numpy array first to avoid PyTorch warning
            features_array = np.array([features_scaled], dtype=np.float32)
            
            # FIXED: Use torch.from_numpy instead of torch.tensor for better performance
            features_tensor = torch.from_numpy(features_array).to(self.device)
            
            # Generate prediction
            with torch.no_grad():
                prediction_scaled = self.model(features_tensor).cpu().numpy()
            
            # Inverse transform the prediction
            predicted_price_diffs = self.label_scaler.inverse_transform(prediction_scaled)[0]
            predicted_prices = current_price + predicted_price_diffs
            
            # Generate classification probabilities
            buy_prob, sell_prob = self.generate_probabilities(predicted_prices, current_price)
            
            # Generate confidence score
            confidence = self.generate_confidence(predicted_prices, atr_value)
            
            return {
                'predicted_prices': predicted_prices.tolist(),
                'buy_probability': float(buy_prob),
                'sell_probability': float(sell_prob),
                'confidence_score': float(confidence)
            }
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            logger.error(traceback.format_exc())
            raise
    
    def generate_probabilities(self, predicted_prices, current_price):
        """Generate buy/sell probabilities based on predicted prices"""
        
        # Count bullish vs bearish predictions
        bullish_count = sum(1 for price in predicted_prices if price > current_price)
        bearish_count = sum(1 for price in predicted_prices if price < current_price)
        total_predictions = len(predicted_prices)
        
        # Calculate basic probabilities
        bullish_ratio = bullish_count / total_predictions
        bearish_ratio = bearish_count / total_predictions
        
        # Apply some smoothing and ensure probabilities are reasonable
        buy_prob = max(0.1, min(0.8, bullish_ratio * 0.8 + 0.1))
        sell_prob = max(0.1, min(0.8, bearish_ratio * 0.8 + 0.1))
        
        # Normalize to ensure they don't exceed 1.0
        total_prob = buy_prob + sell_prob
        if total_prob > 1.0:
            buy_prob /= total_prob
            sell_prob /= total_prob
        
        return buy_prob, sell_prob
    
    def generate_confidence(self, predicted_prices, atr_value):
        """Generate confidence score based on prediction consistency"""
        
        if len(predicted_prices) == 0:
            return 0.5
        
        # Calculate the spread of predictions
        price_range = max(predicted_prices) - min(predicted_prices)
        
        # Normalize by ATR (volatility)
        if atr_value > 0:
            normalized_spread = price_range / atr_value
        else:
            normalized_spread = price_range / (np.mean(predicted_prices) * 0.001)  # Fallback
        
        # Convert to confidence (lower spread = higher confidence)
        # Using inverse relationship with bounds
        confidence = 1.0 / (1.0 + normalized_spread * 2.0)
        
        # Ensure reasonable bounds
        confidence = max(0.3, min(0.95, confidence))
        
        return confidence

# Create Flask app
app = Flask(__name__)
daemon = PredictionDaemon()

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    status = {
        'status': 'healthy' if daemon.model_loaded else 'unhealthy',
        'model_loaded': daemon.model_loaded,
        'timestamp': datetime.now().isoformat(),
        'version': '3.0.0'
    }
    
    return jsonify(status), 200 if daemon.model_loaded else 503

@app.route('/predict', methods=['POST'])
def predict():
    """Main prediction endpoint"""
    try:
        # Check if model is loaded
        if not daemon.model_loaded:
            return jsonify({
                'status': 'error',
                'message': 'Model not loaded'
            }), 503
        
        # Parse request
        data = request.json
        if not data:
            return jsonify({
                'status': 'error',
                'message': 'No JSON data provided'
            }), 400
        
        # Extract required fields
        required_fields = ['features', 'current_price', 'atr']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'status': 'error',
                    'message': f'Missing required field: {field}'
                }), 400
        
        features = data['features']
        current_price = float(data['current_price'])
        atr_value = float(data['atr'])
        request_id = data.get('request_id', 'unknown')
        
        # Log request
        logger.info(f"Prediction request {request_id}: {len(features)} features, price={current_price:.5f}")
        
        # Generate prediction
        result = daemon.predict(features, current_price, atr_value)
        
        # Add metadata
        result['status'] = 'success'
        result['request_id'] = request_id
        result['timestamp'] = datetime.now().isoformat()
        
        logger.info(f"Prediction completed {request_id}: confidence={result['confidence_score']:.3f}")
        
        return jsonify(result), 200
        
    except ValueError as e:
        logger.error(f"Validation error: {e}")
        return jsonify({
            'status': 'error',
            'message': f'Validation error: {str(e)}'
        }), 400
        
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        logger.error(traceback.format_exc())
        return jsonify({
            'status': 'error',
            'message': f'Internal error: {str(e)}'
        }), 500

@app.route('/stats', methods=['GET'])
def get_stats():
    """Get daemon statistics"""
    return jsonify({
        'model_loaded': daemon.model_loaded,
        'config': {
            'feature_count': daemon.config.FEATURE_COUNT,
            'seq_len': daemon.config.SEQ_LEN,
            'prediction_steps': daemon.config.PREDICTION_STEPS
        },
        'device': str(daemon.device),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/reload', methods=['POST'])
def reload_model():
    """Reload the model and scalers"""
    try:
        daemon.load_model()
        return jsonify({
            'status': 'success',
            'message': 'Model reloaded successfully',
            'model_loaded': daemon.model_loaded
        })
    except Exception as e:
        logger.error(f"Model reload error: {e}")
        return jsonify({
            'status': 'error',
            'message': f'Failed to reload model: {str(e)}'
        }), 500

if __name__ == '__main__':
    print("🚀 GGTH HTTP Prediction Daemon v3.0.0")
    print("=" * 50)
    
    if daemon.model_loaded:
        print("✅ Model loaded successfully!")
        print(f"📊 Feature count: {daemon.config.FEATURE_COUNT}")
        print(f"📈 Prediction steps: {daemon.config.PREDICTION_STEPS}")
        print(f"🧠 Device: {daemon.device}")
    else:
        print("❌ Model failed to load - check file paths")
        print("🔧 The daemon will still start but won't make predictions")
    
    print("\n🌐 Starting HTTP server...")
    print("📍 Health check: http://127.0.0.1:8888/health")
    print("🎯 Prediction endpoint: http://127.0.0.1:8888/predict")
    print("📊 Stats endpoint: http://127.0.0.1:8888/stats")
    print("\n🛑 Press Ctrl+C to stop")
    print("=" * 50)
    
    try:
        # Run the Flask app
        app.run(
            host='127.0.0.1',
            port=8888,
            debug=False,  # Set to False for production
            threaded=True,
            use_reloader=False
        )
    except KeyboardInterrupt:
        print("\n👋 Daemon stopped by user")
    except Exception as e:
        print(f"\n❌ Daemon error: {e}")
        logger.error(f"Daemon startup error: {e}")
        logger.error(traceback.format_exc())